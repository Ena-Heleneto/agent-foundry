import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import process from 'node:process'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

/**
 * 默认测试真实挂载脚本；仅直接运行本文件时接受产物目录，避免误读测试运行器的文件列表。
 */
const scriptDir = !process.execArgv.includes('--test') && process.argv[2]
  ? path.resolve(process.argv[2])
  : fileURLToPath(new URL('../script/register-commands/', import.meta.url))

/**
 * 在独立目录验证四指令输入、参数转发和失败传播；模拟 CLI 不作为官方验收证据。
 * @param {string} runtime shell 名称。
 * @param {string} extension 脚本后缀。
 */
function verifyMount(runtime, extension) {
  /**
   * 本测试唯一临时目录，所有写入仅限此目录。
   */
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'register-commands-test-'))
  try {
    /**
     * 模拟已经初始化的 Codex 项目。
     */
    const project = path.join(root, 'project with spaces')
    /**
     * 已安装的通用技能目录。
     */
    const skills = path.join(root, 'installed skills')
    fs.mkdirSync(path.join(project, '.specify'), { recursive: true })
    fs.writeFileSync(path.join(project, '.specify/init-options.json'), JSON.stringify({ ai: 'codex', ai_skills: true, speckit_version: '1.2.6' }))
    fs.writeFileSync(path.join(project, '.specify/unknown.txt'), '用户配置')
    /**
     * 四份技能统一交付，每项都必须进入官方安装输入。
     */
    const modes = ['tutor', 'pair', 'direct', 'increment']
    /**
     * 当前写入安装输入的模式标识。
     */
    for (const mode of modes) {
      fs.mkdirSync(path.join(skills, `task-${mode}`), { recursive: true })
      fs.writeFileSync(path.join(skills, `task-${mode}/SKILL.md`), `---\nname: task-${mode}\ndescription: 测试\n---\n\n# 正文\n保持正文\n`)
    }
    /**
     * 模拟 CLI 保存实际接收的参数和临时输入，以非零退出验证错误传播。
     */
    const cli = path.join(root, runtime === 'pwsh' || process.platform === 'win32' ? 'fake-specify.ps1' : 'fake-specify')
    fs.writeFileSync(cli, cli.endsWith('.ps1')
      ? `$arguments = @($args)
$source = $arguments[[Array]::IndexOf($arguments, '--dev') + 1]
$manifest = Get-Content -Raw -LiteralPath (Join-Path $source 'extension.yml') | ConvertFrom-Json
@{ args = $arguments; manifest = $manifest } | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath 'call.json' -Encoding utf8NoBOM
exit 7
`
      : `#!/usr/bin/env node
const fs = require('node:fs');
const path = require('node:path');
const args = process.argv.slice(2);
const source = args[args.indexOf('--dev') + 1];
const manifest = JSON.parse(fs.readFileSync(path.join(source, 'extension.yml'), 'utf8'));
fs.writeFileSync('call.json', JSON.stringify({ args, manifest }));
process.exit(7);
`)
    fs.chmodSync(cli, 0o755)
    /**
     * 阻断自有脚本对 Python 的调用；外部 CLI 替身使用 Node，不代表 Specify 无 Python 依赖。
     */
    const blocked = path.join(root, 'blocked-interpreters')
    fs.mkdirSync(blocked)
    /**
     * 两种常见 Python 命令都应与自有挂载实现无关。
     */
    for (const executable of ['python', 'python3']) {
      fs.writeFileSync(path.join(blocked, `${executable}${process.platform === 'win32' ? '.cmd' : ''}`), process.platform === 'win32' ? '@exit /b 99\r\n' : '#!/bin/sh\nexit 99\n', { mode: 0o755 })
    }
    /**
     * 执行真实 shell 入口，避免只验证共享核心而漏掉参数转发。
     * @param {string[]} args 本次参数。
     * @param {Record<string, string | undefined>} environment 本次版本环境覆盖。
     * @returns {import('node:child_process').SpawnSyncReturns<string>} 实际进程结果。
     */
    function run(args, environment = {}) {
      return spawnSync(runtime, [...(runtime === 'pwsh' ? ['-NoProfile', '-File'] : []), path.join(scriptDir, `register-commands.${extension}`), ...args], {
        encoding: 'utf8',
        env: { ...process.env, PATH: `${blocked}${path.delimiter}${process.env.PATH}`, FOUNDRY_SPECIFY_VERSION: '1.2.6', ...environment },
      })
    }
    /**
     * 目标与来源都显式传入，路径包含空格以验证转发。
     */
    const args = ['--project', project, '--skills-dir', skills, '--cli', cli]
    assert.equal(run(['--help']).status, 0)
    assert.notEqual(run([...args, '--mode', 'invalid']).status, 0)
    assert.equal(fs.existsSync(path.join(project, 'call.json')), false)
    /**
     * CLI 失败必须向上传播，不得误报安装成功。
     */
    const failed = run(args)
    assert.equal(failed.status, 7)
    assert.match(failed.stderr, /官方挂载失败/)
    /**
     * 每次都提交完整四项并强制重装，由官方处理安装状态。
     */
    const call = JSON.parse(fs.readFileSync(path.join(project, 'call.json'), 'utf8'))
    assert.deepEqual(call.args.slice(0, 3), ['extension', 'add', '--dev'])
    assert.equal(call.args.at(-1), '--force')
    assert.equal(call.manifest.extension.id, 'modes')
    assert.deepEqual(call.manifest.provides.commands.map(item => item.name), [
      'speckit.modes.tutor',
      'speckit.modes.pair',
      'speckit.modes.direct',
      'speckit.modes.increment',
    ])
    assert.equal(fs.readFileSync(path.join(project, '.specify/unknown.txt'), 'utf8'), '用户配置')
    assert.equal(fs.existsSync(call.args[3]), false)
    assert.equal(call.manifest.requires.speckit_version, '==1.2.6')
    assert.equal(run(args, { FOUNDRY_SPECIFY_VERSION: '1.2.7' }).status, 7)
    assert.equal(JSON.parse(fs.readFileSync(path.join(project, 'call.json'), 'utf8')).manifest.requires.speckit_version, '==1.2.7')
    assert.notEqual(run(args, { FOUNDRY_SPECIFY_VERSION: '1.2.6"invalid' }).status, 0)
    fs.unlinkSync(path.join(project, 'call.json'))
    fs.unlinkSync(path.join(skills, 'task-increment/SKILL.md'))
    assert.notEqual(run(args).status, 0)
    assert.equal(fs.existsSync(path.join(project, 'call.json')), false)
  }
  finally {
    fs.rmSync(root, { recursive: true, force: true })
  }
}

test('Bash 四指令输入、强制重装及失败传播', { skip: process.platform === 'win32' }, () => verifyMount('bash', 'sh'))
test('PowerShell 同一接口', { skip: spawnSync('pwsh', ['-NoProfile', '-Command', '$PSVersionTable.PSVersion']).error?.code === 'ENOENT' }, () => verifyMount('pwsh', 'ps1'))

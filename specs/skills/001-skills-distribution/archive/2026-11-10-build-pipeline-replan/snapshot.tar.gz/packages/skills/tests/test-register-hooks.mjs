import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import process from 'node:process'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { parse } from 'yaml'

/**
 * 包根只用于定位被测脚本和输入；所有安装目标均由测试创建。
 */
const packageRoot = fileURLToPath(new URL('../', import.meta.url))
/**
 * 官方验证仅使用调用方提供的固定 CLI，不在测试中下载工具。
 */
const officialCli = process.env.FOUNDRY_SPECIFY_CLI
/**
 * 安装顺序使同事件中的门禁先于产物与随行说明。
 */
const hookIds = ['artifact-issue-description', 'artifact-pr-description', 'mvu-gate', 'artifact-business-flow', 'artifact-logic-flow', 'explainer-doc-sync', 'artifact-project-description']

/**
 * 独立交付测试从 dist 技能目录取配置，普通测试从源码技能目录取配置。
 */
const skillsSource = !process.execArgv.includes('--test') && process.argv[3]
  ? path.resolve(process.argv[3])
  : path.join(packageRoot, 'src/skills/workflow')

/**
 * 创建含空格路径的项目与已安装技能源，配置与技能一起复制。
 * @returns {{ root: string, project: string, skills: string, env: NodeJS.ProcessEnv }} 本测试独占的环境。
 */
function fixture() {
  /**
   * 测试退出时只清理本次拥有的临时根。
   */
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'foundry-hooks-'))
  /**
   * 路径带空格，以验证参数不会被 shell 字符串拆分。
   */
  const project = path.join(root, 'project with spaces')
  /**
   * 模拟已经由 skills 安装的来源目录。
   */
  const skills = path.join(root, 'installed skills')
  fs.mkdirSync(path.join(project, '.specify'), { recursive: true })
  fs.writeFileSync(path.join(project, '.specify/init-options.json'), JSON.stringify({ ai: 'codex', ai_skills: true, speckit_version: '1.2.6' }))
  /**
   * 每个来源都含正文及附件，以验证完整复制。
   */
  for (const id of hookIds) {
    fs.mkdirSync(path.join(skills, id, 'references'), { recursive: true })
    fs.writeFileSync(path.join(skills, id, 'SKILL.md'), `---\nname: ${id}\ndescription: 测试\n---\n正文\n`)
    fs.writeFileSync(path.join(skills, id, 'references/note.txt'), '附件')
    fs.copyFileSync(path.join(skillsSource, id, 'speckit-hooks.json'), path.join(skills, id, 'speckit-hooks.json'))
  }
  return { root, project, skills, env: { ...process.env, HOME: path.join(root, 'user'), CODEX_HOME: path.join(root, 'user/.codex'), FOUNDRY_SPECIFY_VERSION: '1.2.6' } }
}

/**
 * 检查真实子进程结果，启动错误不能被误记为业务返回码。
 * @param {string} executable 可执行程序。
 * @param {string[]} args 参数数组。
 * @param {ReturnType<typeof fixture>} context 隔离环境。
 * @returns {import('node:child_process').SpawnSyncReturns<string>} 真实执行结果。
 */
function run(executable, args, context) {
  /**
   * 不使用 shell 拼接，子进程只能在临时项目中运行。
   */
  const result = spawnSync(executable, args, { cwd: context.project, env: context.env, encoding: 'utf8', timeout: 60000, maxBuffer: 4 * 1024 * 1024 })
  assert.ifError(result.error)
  assert.equal(result.signal, null, result.stderr)
  return result
}

test('官方 hooks-only 重装覆盖受管字段与旧事件，无额外命令入口', { skip: !officialCli }, () => {
  /**
   * 真实官方 CLI 的独立试验现场。
   */
  const context = fixture()
  try {
    assert.match(run(officialCli, ['--version'], context).stdout, /specify 1\.2\.6\b/u)
    /**
     * 原有手写配置模拟当前迁移现场，不预建该扩展的 registry。
     */
    const configFile = path.join(context.project, '.specify/extensions.yml')
    fs.writeFileSync(configFile, JSON.stringify({
      hooks: {
        before_plan: [{ extension: 'mvu-gate', command: 'mvu-gate', enabled: false, condition: 'manual', custom_field: 'stale' }, { extension: 'other', command: 'keep', enabled: false }],
        after_tasks: [{ extension: 'mvu-gate', command: 'old-command' }],
      },
      settings: { auto_execute_hooks: false },
      custom: 'keep',
    }))
    /**
     * 只含 hooks 的临时输入，用于先验证官方替换行为。
     */
    const input = path.join(context.root, 'input')
    fs.mkdirSync(input)
    /**
     * 两次来源不同，每次重装都必须更新配置。
     */
    for (const prompt of ['first', 'updated']) {
      fs.writeFileSync(path.join(input, 'extension.yml'), JSON.stringify({
        schema_version: '1.0',
        extension: { id: 'mvu-gate', name: 'MVU Gate', version: '1.0.0', description: '门禁测试' },
        requires: { speckit_version: '==1.2.6' },
        provides: {},
        hooks: { before_plan: { command: 'mvu-gate', prompt, optional: false } },
      }))
      /**
       * 真正调用官方 CLI，由其修改临时项目受管配置。
       */
      const result = run(officialCli, ['extension', 'add', '--dev', input, '--force'], context)
      assert.equal(result.status, 0, result.stdout + result.stderr)
      /**
       * YAML 只在测试中解析，不进入运行脚本。
       */
      const config = parse(fs.readFileSync(configFile, 'utf8'))
      assert.deepEqual(config.hooks.before_plan.filter(item => item.extension === 'mvu-gate'), [{ extension: 'mvu-gate', command: 'mvu-gate', enabled: true, optional: false, priority: 10, prompt, description: '', condition: null }])
      assert.equal(config.hooks.after_tasks, undefined)
      assert.equal(config.hooks.before_plan.find(item => item.extension === 'other').enabled, false)
      assert.equal(config.settings.auto_execute_hooks, false)
      assert.equal(config.custom, 'keep')
    }
    assert.equal(fs.existsSync(path.join(context.project, '.agents/skills/speckit-mvu-gate')), false)
  }
  finally {
    fs.rmSync(context.root, { recursive: true, force: true })
  }
})

/**
 * 允许构建测试把被测入口切换到脱离仓库的交付副本。
 */
const scriptRoot = !process.execArgv.includes('--test') && process.argv[2]
  ? path.resolve(process.argv[2])
  : path.join(packageRoot, 'script/register-hooks')

test('原生 hooks 安装全量重装、复制附件、失败停止并清理临时输入', { skip: process.platform === 'win32' }, () => {
  /**
   * 用模拟 CLI 观察实际平台脚本交给官方的完整输入。
   */
  const context = fixture()
  try {
    /**
     * 模拟程序只记录调用，不实现官方 YAML 行为。
     */
    const cli = path.join(context.root, 'record-cli')
    /**
     * 逐行记录方便观察失败时已执行的安装数量。
     */
    const log = path.join(context.root, 'calls.jsonl')
    context.env.HOOK_TEST_LOG = log
    fs.writeFileSync(cli, `#!${process.execPath}
/**
 * 测试 CLI 记录文件所需模块。
 */
const fs = require('node:fs')
/**
 * 测试 CLI 定位临时输入。
 */
const path = require('node:path')
/**
 * 平台脚本传入的真实临时目录。
 */
const input = process.argv[5]
/**
 * 测试只读观察临时声明。
 */
const manifest = JSON.parse(fs.readFileSync(path.join(input, 'extension.yml'), 'utf8'))
fs.appendFileSync(process.env.HOOK_TEST_LOG, JSON.stringify({ args: process.argv.slice(2), input, manifest, attachment: fs.readFileSync(path.join(input, 'skills', manifest.extension.id, 'references/note.txt'), 'utf8') }) + '\\n')
process.exit(process.env.HOOK_TEST_FAIL === manifest.extension.id ? 7 : 0)
`)
    fs.chmodSync(cli, 0o755)
    /**
     * 直接运行 Bash 平台入口，验证完整安装和失败传播。
     */
    for (const executable of ['bash']) {
      /**
       * 用户选择的目标与已安装技能目录，均含空格。
       */
      const args = [path.join(scriptRoot, 'register-hooks.sh'), '--project', context.project, '--skills-dir', context.skills, '--cli', cli]
      fs.writeFileSync(log, '')
      /**
       * 两次成功调用应各有七条记录，不因已安装而跳过。
       */
      for (const pass of [1, 2]) {
        fs.writeFileSync(path.join(context.skills, hookIds[0], 'references/note.txt'), `附件${pass}`)
        /**
         * 修改已安装技能的配置，验证安装器没有读脚本内的固定副本。
         */
        const hookConfig = path.join(context.skills, hookIds[0], 'speckit-hooks.json')
        /**
         * 事件和身份固定，只改变本轮期望传给官方的提示。
         */
        const hooks = JSON.parse(fs.readFileSync(hookConfig, 'utf8'))
        hooks.after_specify[0].prompt = `本次来源${pass}`
        fs.writeFileSync(hookConfig, JSON.stringify(hooks))
        /**
         * 真正运行 Bash 平台安装器。
         */
        const result = run(executable, args, context)
        assert.equal(result.status, 0, result.stdout + result.stderr)
      }
      /**
       * 检查交付给官方的集合、强制覆盖参数和清理结果。
       */
      const calls = fs.readFileSync(log, 'utf8').trim().split('\n').map(line => JSON.parse(line))
      assert.deepEqual(calls.map(call => call.manifest.extension.id), [...hookIds, ...hookIds])
      assert.equal(calls[0].attachment, '附件1')
      assert.equal(calls[7].attachment, '附件2')
      assert.equal(calls[0].manifest.hooks.after_specify[0].prompt, '本次来源1')
      assert.equal(calls[7].manifest.hooks.after_specify[0].prompt, '本次来源2')
      /**
       * 所有输入均仅声明 hooks，不引入额外命令。
       */
      for (const call of calls) {
        assert.deepEqual(call.args, ['extension', 'add', '--dev', call.input, '--force'])
        assert.deepEqual(call.manifest.provides, {})
        assert.ok(Object.keys(call.manifest.hooks).length)
        assert.equal(fs.existsSync(call.input), false)
      }
      fs.writeFileSync(log, '')
      context.env.HOOK_TEST_FAIL = hookIds[1]
      assert.equal(run(executable, args, context).status, 7)
      /**
       * 第二项失败后不得进入第三项，失败输入也应清理。
       */
      const failed = fs.readFileSync(log, 'utf8').trim().split('\n').map(line => JSON.parse(line))
      assert.equal(failed.length, 2)
      assert.equal(fs.existsSync(failed[1].input), false)
      delete context.env.HOOK_TEST_FAIL
      fs.writeFileSync(log, '')
      fs.renameSync(path.join(context.skills, hookIds[6], 'SKILL.md'), path.join(context.skills, hookIds[6], 'saved.md'))
      assert.notEqual(run(executable, args, context).status, 0)
      assert.equal(fs.readFileSync(log, 'utf8'), '')
      fs.renameSync(path.join(context.skills, hookIds[6], 'saved.md'), path.join(context.skills, hookIds[6], 'SKILL.md'))
      fs.renameSync(path.join(context.skills, hookIds[6], 'speckit-hooks.json'), path.join(context.skills, hookIds[6], 'saved.json'))
      assert.notEqual(run(executable, args, context).status, 0)
      assert.equal(fs.readFileSync(log, 'utf8'), '')
      fs.renameSync(path.join(context.skills, hookIds[6], 'saved.json'), path.join(context.skills, hookIds[6], 'speckit-hooks.json'))
    }
  }
  finally { fs.rmSync(context.root, { recursive: true, force: true }) }
})

test('真实平台脚本两次安装七项 hooks 后仍只有五个协作指令', { skip: !officialCli || process.platform === 'win32' }, () => {
  /**
   * 全链路在独立项目中执行，不修改工作区登记。
   */
  const context = fixture()
  try {
    /**
     * 每轮直接调用实际 Bash 平台脚本。
     */
    for (const pass of [1, 2]) {
      /**
       * 完整安装七项，官方负责配置覆盖与登记。
       */
      const result = run('bash', [path.join(scriptRoot, 'register-hooks.sh'), '--project', context.project, '--skills-dir', context.skills, '--cli', officialCli], context)
      assert.equal(result.status, 0, result.stdout + result.stderr)
      /**
       * 验证定义的十二项 hooks 未因重跑增加重复项。
       */
      const config = parse(fs.readFileSync(path.join(context.project, '.specify/extensions.yml'), 'utf8'))
      assert.equal(Object.values(config.hooks).flat().length, 12)
      assert.equal(config.hooks.before_plan[0].enabled, true)
      assert.equal(config.hooks.before_plan[0].condition, null)
      assert.deepEqual(config.hooks.after_plan.map(entry => [entry.extension, entry.priority]), [['mvu-gate', 10], ['artifact-business-flow', 20]])
      assert.deepEqual(config.hooks.before_implement.map(entry => [entry.extension, entry.priority]), [['mvu-gate', 10], ['explainer-doc-sync', 20]])
      if (pass === 1) {
        config.hooks.before_plan[0].enabled = false
        config.hooks.before_plan[0].condition = 'manual'
        config.hooks.before_plan[0].custom_field = 'stale'
        fs.writeFileSync(path.join(context.project, '.specify/extensions.yml'), JSON.stringify(config))
      }
      else { assert.equal(config.hooks.before_plan[0].custom_field, undefined) }
    }
    /**
     * 五个命令来源与 hooks 技能共用同一已安装技能根。
     */
    for (const mode of ['tutor', 'pair', 'review', 'explore', 'guide']) {
      fs.mkdirSync(path.join(context.skills, `task-${mode}`))
      fs.writeFileSync(path.join(context.skills, `task-${mode}/SKILL.md`), `---\nname: task-${mode}\ndescription: 测试\n---\n正文\n`)
    }
    /**
     * hooks 完成后调用既有五指令安装，验证入口集合。
     */
    const commands = run('bash', [path.join(scriptRoot, '../register-commands/register-commands.sh'), '--project', context.project, '--skills-dir', context.skills, '--cli', officialCli], context)
    assert.equal(commands.status, 0, commands.stdout + commands.stderr)
    assert.deepEqual(fs.readdirSync(path.join(context.project, '.agents/skills')).sort(), ['explore', 'guide', 'pair', 'review', 'tutor'].map(mode => `speckit-modes-${mode}`))
  }
  finally { fs.rmSync(context.root, { recursive: true, force: true }) }
})

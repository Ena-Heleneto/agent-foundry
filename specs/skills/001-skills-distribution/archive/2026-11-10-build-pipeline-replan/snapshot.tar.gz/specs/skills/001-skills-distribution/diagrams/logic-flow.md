# 任务逻辑图：Increment、实施准备消费与可迁移流水线

日期：2026-11-10。来源：[tasks.md](../tasks.md) 的当前有效 Task、显式依赖和并行标记，以及实际读取的 [mvu.md](../mvu.md)。本图由 speckit-tasks 的 artifact-logic-flow 后置 hook 刷新，包含51项有效任务与86条内部依赖边；11项原完成事实只作历史范围显示，不由本图更新工程状态。T053暂停、T054/T057撤回和旧做法不进入当前执行图。

箭头表示前项原验收满足后才能推进依赖步骤；阶段按用户故事聚合，正文位置不是跨故事的强制执行顺序。跨图灰色节点是同一原任务的引用，未必已完成；外部虚线框是实际前置条件，不能用文档存在或其他Spec任务勾选代替。保留原Task身份，不按本轮顺序重编号。

## Phase 1：Setup，消费基线与工程接线

原记录及位置：[T001](../tasks.md#t001)、[T002](../tasks.md#t002)。

```mermaid
flowchart TD
    T001["T001 记录现有消费者、环境与文件基线（已完成的原范围）"]
    T002["T002 接入MVU测试入口与构建工具声明（已完成的原范围）"]
    T001 --> T002
    classDef previous fill:#eeeeee,stroke:#999999
    classDef done fill:#e6f4ea,stroke:#44794b
    class T001,T002 done
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 2：Foundational，已验共享骨架

原记录及位置：[T003](../tasks.md#t003)、[T004](../tasks.md#t004)、[T005](../tasks.md#t005)、[T041](../tasks.md#t041)、[T051](../tasks.md#t051)、[T007](../tasks.md#t007)。

```mermaid
flowchart TD
    T002["T002 跨阶段前置 见原任务"]
    T003["T003 验证MVU-A：官方发现、投影与路径（已完成的原范围）"]
    T002 --> T003
    T004["T004 验证MVU-B：下载与逐项提交（本轮仅 Linux）（已完成的原范围）"]
    T003 --> T004
    T005["T005 验证MVU-C：独立第二步与实际文件核验（已完成的原范围）"]
    T003 --> T005
    T004 --> T005
    T041["T041 实现并验证唯一 Node 入口（已完成的原范围）"]
    T004 --> T041
    T005 --> T041
    T051["T051 验证可独立消费的内容导出骨架（已完成的原范围）"]
    T003 --> T051
    T004 --> T051
    T041 --> T051
    T007["T007 验证MVU-E：Git精确排除边界（已完成的原范围）"]
    T004 --> T007
    classDef previous fill:#eeeeee,stroke:#999999
    class T002 previous
    classDef done fill:#e6f4ea,stroke:#44794b
    class T003,T004,T005,T041,T051,T007 done
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 3：US7，技能检查与发布流水线（P1）

原记录及位置：[T055](../tasks.md#t055)、[T056](../tasks.md#t056)、[T058](../tasks.md#t058)、[T059](../tasks.md#t059)、[T060](../tasks.md#t060)、[T061](../tasks.md#t061)、[T062](../tasks.md#t062)。

```mermaid
flowchart TD
    T002["T002 跨阶段前置 见原任务"]
    T037["T037 跨阶段前置 见原任务"]
    T051["T051 跨阶段前置 见原任务"]
    PROJECT_MIGRATION["用户已授权并完成直接源码迁移"]
    PUBLISH_AUTH["维护者对实际候选和目标明确授权"]
    REAL_PLATFORM["独立仓库及真实平台只读条件就绪"]
    T055["T055 验证同源候选及身份替换拒绝"]
    T002 --> T055
    T051 --> T055
    T056["T056 验证隔离 Git 发布的授权、竞争和中断恢复"]
    T055 --> T056
    T058["T058 接通两种布局的工程驱动与完整候选门禁"]
    T055 --> T058
    T056 --> T058
    T059["T059 交付只读检查和迁后手动发布的 Actions 配置"]
    T058 --> T059
    T060["T060 验收可迁移流水线与当前版本本地交付"]
    T037 --> T060
    T059 --> T060
    T061["T061 核验迁后工程与真实平台候选前置"]
    T060 --> T061
    PROJECT_MIGRATION --> T061
    REAL_PLATFORM --> T061
    T062["T062 在获授权的独立仓库首次发布并核对固定来源"]
    T061 --> T062
    PUBLISH_AUTH --> T062
    classDef previous fill:#eeeeee,stroke:#999999
    class T002,T037,T051 previous
    classDef external fill:#fff7db,stroke:#9b7115,stroke-dasharray: 5 5
    class PROJECT_MIGRATION,PUBLISH_AUTH,REAL_PLATFORM external
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 4：US1，按需取得完整技能（P1，内容 MVP）

原记录及位置：[T009](../tasks.md#t009)、[T010](../tasks.md#t010)、[T011](../tasks.md#t011)、[T012](../tasks.md#t012)、[T013](../tasks.md#t013)、[T014](../tasks.md#t014)、[T015](../tasks.md#t015)。

```mermaid
flowchart TD
    T003["T003 跨阶段前置 见原任务"]
    T051["T051 跨阶段前置 见原任务"]
    MAIN_CONTRACT["主线当前消费契约实际移交"]
    MAIN_SOURCE["主线当前同版正文 附件与注册器实际移交"]
    T009["T009 补齐官方交付的契约与错误输入测试（已完成的原范围）"]
    T003 --> T009
    T051 --> T009
    T010["T010 [P] 定义发布与技能模型和构建期校验（已完成的原范围）"]
    T009 --> T010
    T011["T011 [P] 固化79个agent路径和scope适配（已完成的原范围）"]
    T009 --> T011
    T012["T012 将完整目录、投影和清单接入正式构建"]
    T010 --> T012
    T011 --> T012
    MAIN_SOURCE --> T012
    MAIN_CONTRACT --> T012
    T013["T013 实现官方安装前只读选择和冲突检查"]
    T012 --> T013
    T014["T014 交付官方四粒度说明和两步入口边界"]
    T013 --> T014
    T015["T015 验收官方完整目录交付MVP"]
    T014 --> T015
    classDef previous fill:#eeeeee,stroke:#999999
    class T003,T051 previous
    classDef done fill:#e6f4ea,stroke:#44794b
    class T009,T010,T011 done
    classDef external fill:#fff7db,stroke:#9b7115,stroke-dasharray: 5 5
    class MAIN_CONTRACT,MAIN_SOURCE external
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 5：US2，下载安装与恢复（P1）

原记录及位置：[T016](../tasks.md#t016)、[T017](../tasks.md#t017)、[T018](../tasks.md#t018)、[T019](../tasks.md#t019)、[T020](../tasks.md#t020)、[T021](../tasks.md#t021)。

```mermaid
flowchart TD
    T015["T015 跨阶段前置 见原任务"]
    T016["T016 补齐下载入口、冲突与恢复测试"]
    T015 --> T016
    T017["T017 完善同版本材料下载和完整性校验"]
    T016 --> T017
    T018["T018 实现归属收据与安全逐技能提交"]
    T017 --> T018
    T019["T019 交付Bash与PowerShell安装四件套"]
    T018 --> T019
    T020["T020 实现阶段报告、退出码与续接提示"]
    T019 --> T020
    T021["T021 验收双入口内容等价与安装恢复"]
    T020 --> T021
    classDef previous fill:#eeeeee,stroke:#999999
    class T015 previous
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 6：US3，所选 hooks、Increment 与旧入口迁移（P1）

原记录及位置：[T006](../tasks.md#t006)、[T022](../tasks.md#t022)、[T023](../tasks.md#t023)、[T024](../tasks.md#t024)、[T025](../tasks.md#t025)、[T026](../tasks.md#t026)、[T027](../tasks.md#t027)、[T028](../tasks.md#t028)。

```mermaid
flowchart TD
    T005["T005 跨阶段前置 见原任务"]
    T021["T021 跨阶段前置 见原任务"]
    T041["T041 跨阶段前置 见原任务"]
    MAIN_CONTRACT["主线当前消费契约实际移交"]
    MAIN_SOURCE["主线当前同版正文 附件与注册器实际移交"]
    T006["T006 验证 MVU-D：仅 Increment、实施准备加载及旧入口受管迁移"]
    T005 --> T006
    T041 --> T006
    MAIN_SOURCE --> T006
    MAIN_CONTRACT --> T006
    T022["T022 补齐挂载范围、前置条件及原生冲突测试"]
    T021 --> T022
    T006 --> T022
    T023["T023 实现本次集合与统一挂载环境核验"]
    T022 --> T023
    T024["T024 对齐所选准备/分析/结案映射与 Increment 输入"]
    T022 --> T024
    T023 --> T024
    T025["T025 完善独立 hook 平台安装及官方重装"]
    T023 --> T025
    T024 --> T025
    T026["T026 消费仅 Increment 的双平台注册器并验证旧入口迁移"]
    T025 --> T026
    T027["T027 接通公共入口、官方第二步与curl自动挂载"]
    T026 --> T027
    T028["T028 验收三平台 Increment、准备加载及迁移消费"]
    T027 --> T028
    classDef previous fill:#eeeeee,stroke:#999999
    class T005,T021,T041 previous
    classDef external fill:#fff7db,stroke:#9b7115,stroke-dasharray: 5 5
    class MAIN_CONTRACT,MAIN_SOURCE external
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 7：US5，可追溯版本与真实使用者（P1）

原记录及位置：[T029](../tasks.md#t029)、[T030](../tasks.md#t030)、[T031](../tasks.md#t031)、[T032](../tasks.md#t032)。

```mermaid
flowchart TD
    T027["T027 跨阶段前置 见原任务"]
    T037["T037 跨阶段前置 见原任务"]
    T062["T062 跨阶段前置 见原任务"]
    INDEPENDENT_USER["未参与开发的真实独立使用者"]
    T029["T029 补齐发布可复现与搬离源码的验收测试"]
    T027 --> T029
    T030["T030 [P] 完善发布前校验和完整迁移产物"]
    T029 --> T030
    T031["T031 [P] 完善维护者迁移与外部使用文档"]
    T029 --> T031
    T032["T032 在真实公开来源完成独立使用者验收"]
    T030 --> T032
    T031 --> T032
    T037 --> T032
    T062 --> T032
    INDEPENDENT_USER --> T032
    classDef previous fill:#eeeeee,stroke:#999999
    class T027,T037,T062 previous
    classDef external fill:#fff7db,stroke:#9b7115,stroke-dasharray: 5 5
    class INDEPENDENT_USER external
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 8：US4，可选精确隐匿（P2）

原记录及位置：[T033](../tasks.md#t033)、[T034](../tasks.md#t034)、[T035](../tasks.md#t035)、[T036](../tasks.md#t036)。

```mermaid
flowchart TD
    T007["T007 跨阶段前置 见原任务"]
    T028["T028 跨阶段前置 见原任务"]
    T031["T031 跨阶段前置 见原任务"]
    T033["T033 补齐精确隐匿与范围限制测试"]
    T028 --> T033
    T007 --> T033
    T034["T034 实现精确exclude写入与效果核验"]
    T033 --> T034
    T035["T035 接入安装前后隐匿结果与限制说明"]
    T031 --> T035
    T034 --> T035
    T036["T036 验收Git隐匿的独立用户流程"]
    T035 --> T036
    classDef previous fill:#eeeeee,stroke:#999999
    class T007,T028,T031 previous
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 9：US6，真实 Increment 规划与反馈（P1，交付优先后置）

原记录及位置：[T052](../tasks.md#t052)。

```mermaid
flowchart TD
    MAIN_INCREMENT["主线当前Increment与同一分析能力移交"]
    USER_FEEDBACK["可真实反馈的分发业务目标与用户参与"]
    T052["T052 验收真实 Increment 规划、反馈及分析刷新"]
    MAIN_INCREMENT --> T052
    USER_FEEDBACK --> T052
    classDef previous fill:#eeeeee,stroke:#999999
    classDef external fill:#fff7db,stroke:#9b7115,stroke-dasharray: 5 5
    class MAIN_INCREMENT,USER_FEEDBACK external
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## Phase 10：Polish，完整消费、全矩阵与唯一末尾收尾

原记录及位置：[T063](../tasks.md#t063)、[T008](../tasks.md#t008)、[T037](../tasks.md#t037)、[T038](../tasks.md#t038)、[T039](../tasks.md#t039)、[T040](../tasks.md#t040)。

```mermaid
flowchart TD
    T003["T003 跨阶段前置 见原任务"]
    T004["T004 跨阶段前置 见原任务"]
    T006["T006 跨阶段前置 见原任务"]
    T007["T007 跨阶段前置 见原任务"]
    T012["T012 跨阶段前置 见原任务"]
    T021["T021 跨阶段前置 见原任务"]
    T027["T027 跨阶段前置 见原任务"]
    T028["T028 跨阶段前置 见原任务"]
    T030["T030 跨阶段前置 见原任务"]
    T031["T031 跨阶段前置 见原任务"]
    T032["T032 跨阶段前置 见原任务"]
    T036["T036 跨阶段前置 见原任务"]
    T052["T052 跨阶段前置 见原任务"]
    T059["T059 跨阶段前置 见原任务"]
    T060["T060 跨阶段前置 见原任务"]
    T062["T062 跨阶段前置 见原任务"]
    T063["T063 实现完整矩阵测试入口与发布前本地覆盖"]
    T021 --> T063
    T028 --> T063
    T030 --> T063
    T036 --> T063
    T059 --> T063
    T008["T008 验证MVU-F：单次构建独立交付与范围内消费"]
    T003 --> T008
    T004 --> T008
    T006 --> T008
    T007 --> T008
    T012 --> T008
    T027 --> T008
    T037["T037 运行完整工程检查和原消费者回归"]
    T008 --> T037
    T030 --> T037
    T031 --> T037
    T036 --> T037
    T059 --> T037
    T063 --> T037
    T038["T038 完成三平台全agent矩阵及真实远端复验"]
    T032 --> T038
    T037 --> T038
    T062 --> T038
    T039["T039 同步最终文档、接口示例与图表"]
    T038 --> T039
    T040["T040 汇总交付证据、清理开发遗留并核对结案边界"]
    T039 --> T040
    T052 --> T040
    T060 --> T040
    T062 --> T040
    classDef previous fill:#eeeeee,stroke:#999999
    class T003,T004,T006,T007,T012,T021,T027,T028,T030,T031,T032,T036,T052,T059,T060,T062 previous
```

检查点：按原Task的范围、信号和外部条件验收；未通过只阻断实际依赖下游，缺平台/正式来源/真实用户均不计通过。

## 推荐执行顺序

当前来源未移交时，可从已满足 T002/T051 的 T055 验候选边界，再 T056 验本次自有临时 bare Git 的授权/竞争/故障，沿同一骨架接 T058/T059。它不要求真实远端，也不产生完整正式候选。US1仍是内容MVP：正式同版获准来源就绪后完成T012～T015，再按显式依赖完善下载安装。

挂载先完成T006的D-MOUNT/D-PREP风险验证，再T022～T028对齐仅Increment、所选准备/分析/结案hooks、未知内容保护和两入口/工作区接线。D-CHAIN由T027实际组合并由T028补平台/宿主证据。发布材料从T027后准备；T030/T031按固定输入快照可分文件并行，挂载最终验收不因此跳过。

隐匿和完整消费者按原依赖推进；T063先实现并核对同源码/文件身份的完整本地矩阵，T037据此固定完整本地候选，T060判断当前版本本地交付。用户直接迁移源码且真实条件就绪后，T061在新仓库新身份上重建检查，经精确授权T062首次发布，T032/T038/T039分别验真实独立使用者、远端全集/真实旧版恢复及最终文档。

T052依据当前Spec/业务描述、真实反馈及主线移交独立验Increment，不要求Task定位参数，也不等待全矩阵/发布；T053及三暂停模式的学习/报告/角色专项移出本期。有效执行序列最后仍为T040，按T039/T052/T060/T062及全部原结案条件收尾。首次缺真实旧公开版本时，T038对应恢复条件仍未验，不能因本地模拟通过提前完成T040，也不为造样本自动另发版本。

## 并行与恢复说明

- `[P]`仅来自原Task标记。T010/T011为已完成历史组，不重复实施；T030/T031在各自前置满足、固定输入快照且文件不竞争时并行，共享构建/记录串行。
- T023/T024共享mount-entry且有依赖，不能并行。安装双平台及pipeline共用测试/配置也不能只因语言或文件数不同就并发写同一输出；各故事的机会见tasks并行示例。
- 旧入口更新前发现未知附件/用户维护文件/归属不明时，受影响官方调用前停止并报告，其他独立工作可继续；不自动搬移或删除用户文件。
- 原始/实际安装投影逐文件验摘要，官方生成入口按其允许的元数据转换、有效正文及附件可读性验；完整宿主加载不等于主线讨论/逐Task门禁通过。
- 候选或交付字节变化后的重验是恢复流程，不画作DAG反向依赖：回原模块/T037，迁后按T061/T062新身份及明确授权复验适用远端结果；已公开同版不覆盖。

## 检查与实现位置

任务生成阶段曾按当时格式核对51节点、86条内部依赖、必要外部前置、无环、八栏目与原完成事实保护。本次按宪章7.0.0将40项未完成任务改为轻量结构并保存旧规划参考，原目标、依赖、整体验收、完成事实和本图节点/连线保留；逐Task实施方案须在真实讨论认可后独立保存。这些属于文档和任务质量核查。本轮10张阶段图均已通过Mermaid 12.3.0与本地无头Chrome实际渲染；渲染结果不能代替产品或平台测试。

实现位置沿packages/skills/script/内部双平台模块、build/distribution、build/ci及tests/distribution/，工作区接线位于scripts/dev/nuxt-prepare/，流水线位于根.github/workflows/skills-{check,release}.yml；均按各原Task实际实现/验收状态理解。综合分析skill尚未正式交付时不另造分析生成器或伪称已刷新。

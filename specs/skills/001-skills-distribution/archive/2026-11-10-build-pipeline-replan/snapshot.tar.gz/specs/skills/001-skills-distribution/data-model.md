# 数据模型：可追溯分发与阶段结果

## 本轮 MCP 派生清单

`dist/mcp/manifest.json` 是构建输出，不是源配置；唯一输入为 src/mcp 技能与 references 文本。顶层字段为 version（固定 1）和 skills（稳定按名称排序）。条目字段、分类路径与附件名以 [MCP 清单契约](contracts/distribution.md) 为准。不含 generatedAt；空源输出空数组。下面 release.json 已接入开发构建，完整发布仍待原验收，不能替代或反向维护本轮 MCP 清单；旧根 manifest 已取消。

不引入数据库或任务状态系统。发布目录保存技能和脚本的版本清单；运行时报告安装事实；本包拥有的安装收据仅用于文件归属和幂等，不承载 Spec Kit 工程任务状态。

## 发布版本 Release

| 字段           | 约束及用途                                                                                                 |
| -------------- | ---------------------------------------------------------------------------------------------------------- |
| schemaVersion  | 首版 1；不支持的格式拒绝执行                                                                               |
| version        | 明确 SemVer；首个构建沿用包版本 0.1.0；同版本内容不得重发替换                                              |
| sourceRevision | 生成该内容的源码提交；不包含用户身份或凭据                                                                 |
| tools          | skills=latest、specify=1.2.6、唯一入口 Node ≥22.20.0 与平台 shell 下限；官方 skills 另记 npm 基线          |
| files          | 每项相对路径、字节数、SHA-256；覆盖实际适配脚本及技能，不包含静态 Agent 表或独立来源声明；不含固定扩展声明 |
| skills         | 发布 Skill 数组；按同版获准来源确定，不固定历史数量                                                        |
| projections    | identity 与 eve-frontmatter-v1 的实际安装文件摘要                                                          |
| adapters       | 在线数据读取器及挂载脚本的路径和摘要                                                                       |

`release.json.files` 声明公开安装选择，不等于当前 dist 的全部文件；安装候选集合为 files 加 release.json 自身，项目源码由用户直接迁移，不生成独立工程包或索引。当前 MCP 清单位于 dist/mcp/manifest.json 且无 generatedAt，旧根 manifest/index 不再生成；MCP 线上内容及其流水线选择另行定义。`release.json` 不把自身摘要写进自身；报告保存其原始字节摘要 catalogDigest。公开来源由调用方给不可变提交根 URL，避免目录提交号与清单互相引用。来源 commit 与 sourceRevision 可以不同，分别记录。HTTPS 与同源摘要提供传输/内容一致性，不宣称独立签名认证。开发期间的未发布构建仅用于阶段验证，不作为固定发布版本交付；T037在所有本地能力与完整发布校验通过后固定 Foundry 候选，项目迁入新仓库改变 sourceRevision 后必须重建重验。候选之后的内容变化使旧摘要及相关验收失效，已公开同版本不可替换。承载来源的公开commit不回填进清单或发布README；README参数化接收RELEASE_SOURCE，实际来源与展开命令存于发布根外的验收资料。

## 源码直接迁移边界

skill、MCP、构建、脚本、必要测试和 CI 源码由用户直接移入公开仓库；工程依赖与配置在新仓库维护，不提供 ProjectBundle 数据模型、自动导出器或工程摘要。迁移说明记录所需材料与调整项即可，不能把 node_modules、凭据、Foundry 业务应用或个人画像一并公开。

源码仓库与安装候选仍有不同边界：公开仓库可维护多种源码，供技能安装的候选只含 release.json.files 加清单自身。迁后用新源码 SHA、实际配置与依赖快照重新检查，不能将旧 Foundry 候选视为新身份通过。

## 安装候选 ReleaseCandidate（计划）

payload 仅含 Release 白名单和 release.json；候选索引、依赖/检查证据、artifact 元数据位于 payload 外。

| 字段                              | 约束                                                                                                    |
| --------------------------------- | ------------------------------------------------------------------------------------------------------- |
| repository/sourceRevision/version | 检查运行的实际仓库、完整源码 SHA、自有 SemVer；与清单严格一致                                           |
| runId/runAttempt/artifactId       | 精确定位可信默认分支成功检查，拒绝最新同名选择或其他 run/attempt 冒用                                   |
| catalogDigest                     | release.json 原始字节 SHA-256                                                                           |
| payloadFiles/candidateDigest      | 所有公开文件（含 release.json）的排序路径、bytes、SHA-256；稳定计算候选摘要，完整集合与实际文件双向相等 |
| dependencySnapshot/checks         | 来源依赖快照与必需检查结果；必需 failed/not-run/缺环境 skip 阻止发布，允许的不适用项有理由              |
| createdAt/expiresAt               | 仅 CI 证据元数据，计划 14 天且服从平台限制；不进入 Release 字节以免破坏构建可复现                       |
| purpose                           | development/isolated/ready；不能通过改标记把缺项或开发样本变成可发布候选                                |

候选变更任何公开字节或身份字段即失效；真实发布前自算摘要和核对可信运行结果，不仅信任 artifact 内自报字段或下载器警告。候选归档过期或不可取得时重新准备并取得新授权。

## 发布请求与结果 PublishRequest / Publication（计划）

请求包含 executionMode、当前仓库/事件/ref/actor、version、sourceRevision、runId/runAttempt/artifactId、catalogDigest、candidateDigest 和预配目标。模式为 isolated/standalone；isolated 只接测试拥有的本地 bare Git，standalone 还要求迁后根工程、默认分支 workflow_dispatch 和当前仓库目标。凭据由执行平台注入，不作为请求文件、日志或候选字段。

Publication 保存 tag=`skills-v<version>`、repository、publishedRevision、rawRoot、officialSkillsRoot、候选身份及是否复用。rawRoot 是 raw.githubusercontent.com 下同一完整发布 SHA 的文件根，officialSkillsRoot 是 github.com 下同仓库同 SHA 的 tree/skills 目录 URL；分类和单技能继续追加目录。两 URL 按 repository/publishedRevision 强制绑定，不把 raw 目录当成官方安装来源。源码 SHA 与发布 SHA 分别保存；发布提交树严格等于 payload，无源码父树，不包含 CI 记录、项目源码或多版本目录。已有 tag 全部字节相同则复用原 SHA，不同拒绝覆盖；同版并发依靠新 tag 无 force 创建裁决，concurrency 只作辅助。发布 ref 已创建而远端核验失败时，不能把 Publication 改写为未发生。

## 流水线运行记录 PipelineRun（计划）

字段为 schemaVersion、executionMode、trigger、repository/sourceRevision、toolchain、candidate、authorization（无秘密）、publication、stages、coverageLimits、retry。阶段为 check/candidate/publish/remote-verify，各自 success/failed/skipped/not-run 并附 reasonCode；总体 success/partial/failed 仅概括本次请求，不承载 Task checkbox。

流转为检查 → 候选准备 → 授权核对 → 发布 → 远端核验。当前 Foundry 请求终止于隔离演练，真实 publish/remote-verify 标记等待迁移的 not-run，不把本地演练结果当真实阶段 success。迁后检查不通过则发布未运行；发布已写而远端核验失败为 partial，保留固定 ref、旧完整版本和续接条件。日志/运行 URL 由 CI 平台保存，不新建跨仓库状态服务；字段定义的完整调用规则见 [pipeline 契约](contracts/pipeline.md)。

### T010 正式字段格式与校验边界

类型和校验分别位于 `packages/skills/build/distribution/models.ts` 与 `validate.ts`。`ReleaseFile` 为 `{ path, bytes, sha256 }`；`files` 保存交付根相对路径，拒绝路径逃逸、重复、大小写冲突、文件/目录相互占用以及固定扩展声明和清单自身摘要。`tools.skills` 声明 latest，实际版本由每次调用在线解析并记录在报告 upstream；其余工具仍采用 Specify 1.2.6 及已确认 Node/shell 下限，npm 单独记录实际验证基线。版本使用 ASCII SemVer；源码提交使用完整 40 位 Git SHA。

`projections` 的两个键固定为 `identity` 和 `eve-frontmatter-v1`，每个键下按技能声明名保存 `ProjectedFile[]`。每项的 `path` 是技能内安装相对路径，`sourcePath` 是交付文件表中的来源，`bytes` 与 `sha256` 必须匹配同一来源字节。技能的 `installedFilesByProjection` 只列对应安装相对路径，摘要集中在顶层投影表；两种投影都必须覆盖本技能完整来源文件集合。Eve 只允许各层 `SKILL.md` 按官方规则转换，普通附件保持原始字节。`adapters` 使用同样的文件摘要结构，引用同一 `files`，必须包含 script/install-skills/read-agents.mjs 及平台脚本，不自行维护另一套字节事实。

`parseRelease`、`parseReleaseJson` 校验完整结构及跨字段引用，不修改输入、不写目录、不自动补依赖；缺少公开依赖直接报错。`assertReleaseUnchanged` 对同版本不同清单拒绝覆盖。可选 `development` 仅说明候选用途，结构校验通过不代表 README/许可证、完整同版技能集合、全部平台或公开发布验收通过，这些仍由后续原任务判断。T012 通用默认构建已经接入正式模型；T051 最小开发清单只保留历史证据，完整同版来源验收仍未完成。

## 技能 Skill

字段：`name`（frontmatter 唯一身份）、`category`（coding/frontend/workflow）、`directory`、`sourceFiles`、`installedFilesByProjection`、`requiresSkills`、`projectPrerequisites`、`mountMappingIds`。

递归覆盖正文、references、scripts、assets 等实际必需文件；声明 hooks 的技能还包含与 SKILL.md 同目录的 speckit-hooks.json，纳入 sourceFiles、投影后的完整文件集及摘要核验。附件路径必须在本技能内；禁止源符号链接、大小写折叠冲突和遍历路径。技能间依赖须已公开且被用户显式选择；Increment 不依赖三个暂停模式，适用准备 hook 的附件属于同一技能，不作为额外安装选择；项目材料依赖与技能依赖区分。Eve 投影的正文语义和必要元数据须与官方安装等价；不能仅忽略差异。

## 安装请求与结果

`InstallRequest` 包含 entry（official-check/curl/mount）、version、source、selector、agent、scope、cwd、mountProject、hidden、noMount。selector 为 all/category/names 三选一；name 数组去重后仍保留稳定顺序。一次调用只接受一个目标 agent；官方 CLI 自身的多 agent 能力不受此限制。

`Selection` 由版本清单解析，记录请求名、来源分类、依赖检查及投影，不从历史目录推导。`VerifiedSkill` 关联选择项，保存实际入口与解析后路径、完整文件集、摘要、版本证据、安装或复用原因。未知同名目录即使内容碰巧相同也不能由 curl 自动取得所有权；官方第二步可显式只读核验其与所选发布内容等价，报告“本次核验通过”，不声称证明了安装时间或原始安装者。

`InstallReceipt` 位于对应技能根外侧的 `.foundry-distribution/receipts/<name>.json`，包含 source、version、catalogDigest、agent、scope、路径和文件摘要。收据不可信任为唯一事实，重试必须重验文件；不将收据塞入技能目录改变两入口文件等价性。无归属证据的中断目录视为冲突，不能自行删除。

每项技能状态为 pending → staged → verified → installed/reused，任一步可 failed；未轮到的项为 not-run。只有完整 installed/reused 或官方本次核验成功集合进入后续步骤；部分成功不能升级为全成功。

## 挂载调用计划与事实

`MountMapping` 的事件及 hook 条目只从本次所选已安装技能的 speckit-hooks.json 读取，顶层为事件名，值为条目数组；extensionId 沿用技能标识，projectPrerequisites 仍按项目前提核验。当前规划来源为 implementation-preparation、artifact-spec-analysis、artifact-project-description，正式使用时以主线实际同版文件为准。平台脚本组装临时 hooks-only 声明，不维护配置副本。命令组仍为 modes，成员仅 task-increment；选择、正文、附件和版本满足后注册，不要求三个暂停模式。缺必需配置属于 missingFiles，须在本批首次官方调用前失败；无 Increment 选择为不适用，不从历史目录补选，不存 registry、指纹或第二套状态。

`PreparationDelivery` 只是同一 Skill 的消费事实：skillName、releaseVersion/catalogDigest、正文与实际必要附件的文件摘要、hook 事件/extensionId、生成入口及引用路径、loadEvidence 和 coverageLimits。不是单独持久格式或工程状态。source/installed/projection 文件按清单字节核验；官方生成入口允许原生 frontmatter 转换，核对身份、有效正文及附件可读。loadEvidence 缺失不能宣称完整加载，不能代替主线讨论、逐 Task 方案或停止/放行证据。

`ManagedMigration` 保存本次旧登记/受管产物清点、来源依据、未知内容冲突、拟调用官方操作及实际前后差异，作为 RunReport 的阶段证据，不新增对象状态系统。仅清点官方登记及明确受管路径；未知附件或归属不明时受影响官方调用未执行，现场保留。成功须证明旧三入口去留、连续重试不复活、无关内容保持，退出0或新清单缩减本身不充分。

`MountTarget`：显式项目绝对路径、Spec Kit 版本、default integration、配置快照摘要与只读解析结果。项目级默认 cwd；全局没有隐式挂载项目。非 Spec Kit 为 skipped，已有 Spec Kit 但工具/版本/集成不符为 failed。

`MountResult`：hooks、commands 独立阶段。hooks 记录所选配置逐项官方重装结果，commands 记录 Increment 每次官方重装与原生产物核验；没有安装内容复用导致 skip-add 的分支。hooks 失败则 commands=not-run；无 Increment 选择为 skipped，所选来源不完整为 failed，缺三个暂停模式不算失败。暂停入口迁移报告实际差异，不自动改变工程 checkbox。官方写入后读回失败保留已写事实和恢复条件，不伪称原子回滚。

## 隐匿与总报告

`ExcludeItem`：项目、相对精确路径、归属、原跟踪状态、排除规则、实际命中来源、生效结果。仅本次成功内容且在目标项目内的独占路径可入列；共享配置和项目外全局文件列为 coverageLimit，不伪造成功。

`RunReport`：schemaVersion、request、resolvedRelease、upstream、skills[]、stages（installation/hidden/hooks/commands）、overall、retry[]、coverageLimits[]。阶段枚举 success/skipped/failed/not-run，附机器 reasonCode 和中文说明；overall 为 success/partial/failed。请求步骤任一失败则退出非零；允许的“不适用/关闭/无仓库”等 skipped 不是失败。安装已成功而挂载失败为 partial，保留成功事实。

`upstream` 记录本次在线解析的 `{ package: "skills", channel: "latest", version, integrity }`；version 与建议原生命令一致，integrity 对应同一实际发布包。不把解析结果存为下一次的来源锁；网络、完整性或规则布局失败须明确失败，不使用旧表。

报告默认输出 JSON 至 stdout，进度写 stderr；不默认写项目报告文件。显式 `--report <path>` 才创建报告，已有报告路径拒绝覆盖；报告不自动加入排除。跨文件不承诺事务回滚；原生写入中断留下的未知状态须供用户处理，不能按收据盲重试。

Agent 在线来源直接由 script/install-skills/read-agents.mjs 提供，包根 distribution 目录和 agents.json 已移除。构建只交付读取器及平台脚本，不维护另一份来源声明或映射。安装期读取实际 npm 元数据和同包规则，报告 upstream 保存本次实际 version 与 integrity。该运行记录不回写发布清单或形成下次调用的版本锁。eve-frontmatter-v1 是投影格式标识，与 CLI 发布版本分开。

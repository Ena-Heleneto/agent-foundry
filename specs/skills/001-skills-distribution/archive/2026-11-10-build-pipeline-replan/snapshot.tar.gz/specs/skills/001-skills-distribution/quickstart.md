# 验证指南：从本地构建到真实远端

**现行执行入口（截至 2026-11-09）**：只调用 node script/index.mjs 加参数。Agent 规则在安装或官方预检时在线解析官方 npm skills latest，不固定版本、提交或数量；同次建议命令和报告使用解析出的实际版本。来源直接定义在现有 read-agents.mjs，不维护包根 distribution 或 agents.json。自有技能版本及不可变技能发布来源仍必须明确。

**现行衔接（2026-11-10）**：用户直接把 skill、MCP 等源码迁到公开仓库，T054/T057 自动工程导出已撤回，本轮任务衔接前为52项有效任务、11完成，当前有效范围和状态以tasks为准。旧[实验记录](analysis/acceptance/pipeline-local.md)不计现行能力；T055/T056/T058～T063 及完整来源仍待办。当前模式仅 Increment，准备/分析/结案 hooks 按同版来源消费，三暂停模式移出本期测试/结案；T012/T013 完整同版来源仍待移交，其他已验证事实沿原证据保持。

本指南区分当前能力、历史重现实验与后续验收设计。标准 US1 72/72、内容/构建/Node 入口消费 25/25 是已有工程结果，Windows/macOS、完整安装挂载、真实公开来源和专项用户行为仍按原任务验收；本次文档同步未重跑这些工程检查。下方标为历史的固定版本工具和数量只供复验旧证据，不构成产品锁版要求。

## 流水线与独立工程验证（计划接口，尚未实施）

本版本只做 Foundry 内的工程交付及隔离演练；首次正式发布在用户迁移项目后由独立公开仓库执行。当前只有[流水线契约](contracts/pipeline.md)及设计，没有 build/ci 工具或技能 workflow，下面的新命令是后续实现应提供的验证接口，不是本轮已经运行的命令。尖括号必须替换为实施时真实值，缺入口不能算 skip/pass。

### 当前版本的本地隔离验证

前置：Node/pnpm/Git/Python 及各平台工具按[兼容契约](contracts/compatibility.md)准备。候选、授权和 Git 边界骨架可先用明确标注的合成夹具验证；正式候选及其最终验收要求完整获准来源、正式 Release/发布材料就绪，不能用夹具替代。先核对当时源码和已确认修复，不重复按旧诊断修改无关类型或配置。依赖准备使用隔离环境，不运行会挂载真实用户工作区的 postinstall。

1. 完成新增前置骨架后，在 Foundry 根运行其单入口：

   ```bash
   node --test --test-isolation=none packages/skills/tests/distribution/pipeline-contract.test.mjs
   ```

   预期覆盖真实临时 bare Git、候选篡改、未授权、两次重试与两并发、响应丢失和旧版本保留；缺 tools/平台/网络分别报告。合成候选只验证边界，正式集合缺项保持完整验收未通过。

2. 从同一源码与完整依赖快照进行两次干净构建，逐文件比较公开路径及字节；只按 release.files 加 release.json 准备 payload。对 development、缺 README/许可证、额外 eval/MCP/源码 SKILL.md、链接或越界分别验证拒绝。不生成迁移工程包或项目索引。
3. 使用 simulate 模式和本次自有 bare Git 路径演练发布，不传真实仓库或凭据：

   ```text
   node <包根>/build/ci/run.mjs --mode simulate --package-root <明确包根> --candidate-dir <候选目录> --remote <临时bare仓库绝对目录>
   ```

   两次重试/两个并发请求仅保留一个相同内容的版本身份；同版不同字节拒绝，响应丢失后读回真实 ref，不覆盖旧 tag。公开候选根不得含工程源码或多个历史版本目录；Foundry 布局 publish 必须失败。

T054/T057 已撤回，原导出器和专用测试已移除。T055 后续新建 pipeline-contract.test.mjs 验候选，T056 增量补 Git 范围；T058/T059 接驱动和 workflow，T037/T060 判断完整本地交付。用户直接迁移源码后由 T061 验实际独立运行，远端保持 not-run/等待迁移，不以本地实验抵扣真实平台。

### 迁移后的首次正式发布与验收

用户创建并迁移独立技能工程，保留默认分支的源码、根 `.github/workflows` 和独立依赖配置；不自动删除 Foundry 原目录。先在新源码 SHA 上重新检查、准备候选，不能直接复用旧 Foundry 身份授权。

维护者配置 `SKILLS_PROJECT_MODE=standalone`、`SKILLS_PUBLISH_REPOSITORY=<当前owner/repo>`；默认分支实际名称由仓库读取。普通 PR 检查不得获得发布写权限，手动发布必须从默认分支运行并绑定版本、源码 SHA、run/attempt/artifact ID、catalogDigest、candidateDigest。缺失、过期或被替换的候选应失败，重新准备后须重新触发；发布 job 不构建或执行候选内容。14 天 artifact 留存受平台上限约束，不能依赖未验证的私有仓库审批套餐。

首次真实发布应只创建 `skills-v<version>` 指向的完整候选提交；远端固定 SHA 根全部文件与候选一致，保留旧版本引用。将实际来源 URL、版本、源码 SHA、发布 SHA、候选摘要及展开的两入口命令记录在发布根外 release-source.md，远端记录拟为 pipeline-remote.md；只有实际运行后才生成证据。

记录两种 URL 并核对同仓库同发布 SHA：脚本 RELEASE_SOURCE 为 `https://raw.githubusercontent.com/<owner>/<repo>/<发布SHA>`，官方整包/多技能为 `https://github.com/<owner>/<repo>/tree/<同一发布SHA>/skills`，分类及单技能追加目录。官方命令仍显式列出本次核验的技能名，不用星号；以当次在线解析的 CLI 版本实测四种选择，不能把 raw 目录 URL 当官方目录来源。远端预检的转换规则见[安装契约](contracts/install.md)。

仅凭发布成功不能勾选 SC-016 整体通过：还须从真实固定来源验证两入口安装及适用挂载、原支持矩阵与至少一位独立使用者。首次无真实旧公开版本时，以 T056 隔离多版本材料验证恢复机制，可分别判断 T062 的首次发布和远端核验；SC-017 的真实旧版本固定来源复验明确留在 T038，实际历史未形成时该部分及 T038/T040 保持未完成，不得编造历史或为补样本自动另发版本。失败记录发布是否已经发生，按实际 ref 重试，不自动删除或 force 更新。

## 包职责修正后的验证要求（2026-11-03）

包只提供技能与脚本，不维护包根扩展声明或 mounts.json。保留[旧五指令脚本工程证据](../20261029-speckit-workflow-foundation/analysis/acceptance/script-mount-mvu.md)，不等待前序全部验收。模式临时输入按现有脚本成功/失败均清理；新增外部独立交付、所选钩子与35集成验证，不重做逐模式命令扩展。

## 环境和基线

开发环境使用仓库既有 Node/pnpm/Vite 与 Python；yaml 2.8.3 由包 devDependencies 经 shared catalog 声明，保留工作区现行 trustPolicy: no-downgrade。外部最小环境见 [兼容契约](contracts/compatibility.md)。Linux、macOS、Windows 各用独立临时项目和隔离测试用户或容器；全局安装绝不写开发者真实用户的技能目录。路径 fixture 与真实 CLI 测试分别记账，禁止拿路径模拟代替真实入口安装。

产品每次在线解析 skills latest；Specify 默认 1.2.6，本机 dev0 不作其证据。记录实际 Node/npm/Git/Specify/shell 版本以及本次 upstream.version/integrity。Node ≥22.20.0、tar 和相应平台工具需提前具备；source-dir 也需要在线查询。网络、完整性或上游布局失败明确退出且目标零写入，不回退旧表。历史固定版本只用于下方标注的旧实验。

## 构建与最小工程检查

实施代码后在仓库根运行：

```bash
pnpm --filter @foundry/skills run lint
pnpm --filter @foundry/skills run check-types
pnpm --filter @foundry/skills run build
pnpm --filter @foundry/skills run test
pnpm --filter @foundry/skills run test:distribution
uv run --project apps/mcp pytest apps/mcp/tests/test_registry.py
node --test scripts/dev/actions/link-skills/test-link-skills.mjs
```

当前构建预期：dist 根为 mcp、skills、script、release.json、projections 五项；dist/mcp/manifest.json 只来自 src/mcp，dist/skills 保留完整线下内容。开发 release 只选择 coding/frontend 当前内容并标 development；完整同版 workflow 来源未就绪时不冒认完整发布。scripts 原样交付 read-agents.mjs，files/adapters 无 agents.json，构建不联网查询来源或执行运行脚本。旧根 manifest/index 不恢复。

### 单配置验证（2026-11-02 用户调整）

只执行 `pnpm --filter @foundry/skills run build`，不再使用 distribution 模式。运行 `node packages/skills/tests/distribution/test-build-config.mjs` 验证单次交付、源目录缺失、脚本独立执行、MCP 清单递归扫描与稳定重建、增删变更，以及手写清单/重复名称/非法元数据失败；运行包 test 验证真实样例和线下正文。不要手工编辑 dist 或源 manifest 来令测试通过。

## 当前官方只读预检

前置工具及同版本地构建产物准备好后，在独立消费项目运行以下模板，尖括号须换成实际值；此步骤不执行官方安装或挂载：

```text
node <dist绝对目录>/script/index.mjs --check --official --source-dir <dist绝对目录> --version <自有技能SemVer> --agent codex --all
```

成功报告应包含实际 upstream.version/integrity、选择与目标；安装阶段为 not-run，目标树无新增。建议使用同次解析的 skills@版本及显式已核验名称，不用星号扩大集合；若在线获取、完整性或规则布局失败，不输出可执行安装建议。对照[安装契约](contracts/install.md)处理冲突和后续步骤；公开来源尚未就绪，模板不证明远端通过。

## A：历史 MVU-A 重现（skills 1.7.4）

本节仅复验 2026-11-04 的旧基线，数量及版本不是现行产品约束。先准备当时官方工具（以下安装只写自选临时工具目录，不改 workspace）：

```bash
npm install --prefix /tmp/foundry-t003-tools --ignore-scripts --no-audit --no-fund --save-exact skills@1.7.4 yaml@2.8.3
```

另取得官方 skills 的 v1.7.4 源码并解压到独立目录。将 FOUNDRY_SKILLS_PACKAGE 指向该 npm 包目录、FOUNDRY_SKILLS_SOURCE 指向含 package.json 与 src/agents.ts 的源码根。测试检查版本与实际 YAML 依赖；不会隐式下载 latest。路径仅是测试工具来源，真正安装目标由沙箱创建。

可重复执行命令（路径按实际位置替换）：

```bash
FOUNDRY_SKILLS_PACKAGE=/tmp/foundry-t003-tools/node_modules/skills FOUNDRY_SKILLS_SOURCE=/tmp/foundry-skills-source/skills-1.7.4 pnpm --config.verifyDepsBeforeRun=false --filter @foundry/skills run test:distribution -- --mvu A
```

2026-11-04 用户确认本次 T003 仅验 Linux；最低 Node 22.20.0 下9项通过，证据见 [MVU-A记录](analysis/acceptance/mvu-a.md)。其他平台及远端尚未验证。

在隔离环境从导出根、分类目录、单技能目录分别运行原生 `npx skills@1.7.4 add <source> --list`，列表精确等于清单子集，无 eval 或重复。随后使用 [安装契约](contracts/install.md) 四种选择安装；本地目录用于本地实验，URL语法必须等公开仓库后另测。

选取单技能 `document-changed-symbols`；分类 `frontend`；多技能 `vue-reactivity task-pair`（纯安装关闭挂载）；整包全部 16 项。正文与必要附件按目标 agent 投影逐字节比较，另断言未选技能新增数为零。用 Eve 校准固定 yaml 2.8.3 序列化，断言 frontmatter/正文与官方输出一致，不允许忽略字段后宽松比较。

原生 CLI 对混合未知名和既有目标的行为作为已知风险记录；本包只读预检必须在这些输入下零目标写入。检查所有 79 agent、77 global 路径解析以及环境变量和 OpenClaw 分支；eve/promptscript global 请求在写入前失败。

## B：下载与安全提交

**2026-11-04 用户确认的本轮范围**：仅验证 Linux。agent 在仓库外准备独立脚本副本、临时消费目录与受控 HTTPS 测试源，用户无需预先创建公开仓库或准备外部项目。下方 PowerShell 命令保留为其他平台的待验证步骤；Windows/macOS 及未具备的最低运行时不计通过，不阻塞本轮 T004 验收。

```bash
pnpm --filter @foundry/skills run test:distribution -- --mvu B
```

MVU-B 将 `script/install-skills/` 原样复制到仓库外沙箱，实际从独立消费目录执行 Bash 平台入口，不依赖源码、monorepo、pnpm 或 node_modules。清单与最小技能由实验生成，不能冒充正式发布物；不等待 T008/T012 正式构建。最小入口仅支持 Linux x86_64、Codex 项目级、显式名称选择；其他输入明确失败，后续任务在骨架上扩展。

```text
bash <独立副本>/script/install-skills/install-skills.sh --source <受控HTTPS根URL及完整提交> --version 0.1.0 --agent codex --skill <实验技能>
bash <独立副本>/script/install-skills/install-skills.sh --source-dir <本地实验发布根绝对目录> --version 0.1.0 --agent codex --skill <实验技能>
```

上方是内部平台模块的实验模板，不是公开可运行地址或第二个公开入口。Bash 实际负责下载、验证和提交；外部统一使用 Node 入口，Node 调度和真实独立安装已由 T041 另验。jq 1.8.1 在目标项目之外准备，并验证固定官方摘要；FOUNDRY_JQ 可指向预先准备的同版普通文件，仍先核验后执行。测试默认自动取得官方工具，也可使用此变量离线复验；工具准备失败不得进入目标写入。PowerShell 安装模块当前明确失败，不将未实现能力算作跨平台通过。

本轮 Linux 安装结果与输入文件集逐字节一致；跨平台等价性留待具备环境后验证。不含 workflow 时省略 no-mount 不调用挂载；本 MVU 的 workflow 请求必须显式 --no-mount，原生挂载由 T005/T006 接通。HTTP 故障使用本地受控 HTTPS 源：404、截断、超时、错误摘要及跨协议重定向均不产生假成功。证书在测试运行时生成，临时 CA 只通过 CURL_CA_BUNDLE 传给本次子进程；不修改系统 CA，不跳过 TLS。默认 curl 配置不能覆盖脚本的传输安全设置；测试源不代表真实公开交付。

预置未知同名文件、不同版本、用户编辑、额外文件、Git 跟踪但工作树已删的路径、父仓库跟踪、损坏索引、只读目录、目录链接、锁争用、提交前目标变化及中断残留。原用户字节保持，残缺目录不入成功集合；多技能前项成功后后项失败报告 partial。合法安装连跑两次验证复用且不改技能或收据，TERM 中断清理后实际重试成功；失效锁或无收据现场保留给用户处理。

可通过 FOUNDRY_MVU_B_SCRIPT_DIR 指向独立构建产物的 script 目录，用同一组实验验证交付副本。实际版本、命令、红绿记录和限制保存于 analysis/acceptance/mvu-b.md，不以此说明替代通过证据。

## C：历史最小公共材料核验重现

本节复验旧技能集合和固定官方包，不代替当前 Increment/准备 hook 移交。内部最小核验模块已实现，模块接口见 [内部核验说明](../../../packages/skills/script/mount-entry/README.md)，实际结果见 [MVU-C 验收记录](analysis/acceptance/mvu-c.md)。外部分发唯一入口为 node script/index.mjs 加参数，当前先接现有安装骨架，实际挂载仍待 T006。先准备固定版本 skills@1.7.4 npm 包，将 FOUNDRY_SKILLS_PACKAGE 指向该包目录；Bash 可将 FOUNDRY_JQ 指向已取得的 jq 1.8.1 官方二进制，否则内部模块会自行准备并核验。实验在自有 /tmp 目录执行，未提供真实公开来源。

```bash
pnpm --filter @foundry/skills run test:distribution -- --mvu C
```

本项先创建公共入口 mount-entry.sh/.ps1，原样复制到独立沙箱并在用户手动启动入口时准备运行依赖；原生调用由后续MVU-D接通。官方仅安装一个 workflow 技能，不提供源码仓库；从独立导出获取 mount 工具，传版本、选择、agent、scope、installed-root 和明确项目。校验文件和公共材料同 catalogDigest。分别注入缺附件、不同版本、错误位置、伪造退出0、有效与失败混合项，断言只有本次完整成功项进入映射。单选 task-explore 时技能安装成功，但五指令挂载报告其余四项选择缺失、不补装；补齐本次显式选择并逐项核验后才可调用命令脚本。

项目历史上有 workflow、本次仅 frontend 时不调用 mount；全局 workflow 未给项目时 installation=success、hooks=failed/缺项、commands=not-run，并给补传项目的重试命令。no-mount 时不要求项目；非 Spec Kit 明确 skipped。

本轮 Codex 原始目录投影最新 Bash 正式调度器 23 项通过，Linux PowerShell 构建副本 22 项通过、1 项 Bash 专属场景跳过，包含混合选择枚举异常后的逐项报告。模块不会修改已安装技能；无法完整枚举目录也必须失败。五项齐备仍明确报告原生挂载 unsupported/not-run，实际 hooks/commands 接入由 D 验证，不以文件核验替代。

## D：Increment、实施准备与旧入口迁移（本轮验证设计）

前置：主线正式同版 task-increment、implementation-preparation、artifact-spec-analysis 与 artifact-project-description 及其实际必需附件已移交；仅验证所选映射。测试使用独立临时项目、隔离用户与工具缓存，初始化仅由夹具执行；先记录实际指定的 Specify 1.2.6，不以 PATH 其他版本或旧 dev0 代验。现有 D 场景尚待实现，完成后运行：

```bash
pnpm --filter @foundry/skills run test:distribution -- --mvu D
```

缺 D 文件或正式来源要报告失败/未运行，不能把模拟输出记作通过。D-MOUNT/D-PREP/D-CHAIN 的具体责任与阻塞边见 [plan](plan.md)；以下不是本轮已运行结果。

1. 在隔离旧三/四/五集合项目中预置无关扩展、原生核心入口和普通用户哨兵，记录登记、树和字节。仅安装/选择 Increment，缺三个暂停来源不阻塞；使用官方同 ID modes --force 更新后，旧暂停及退役活动入口残留为0，Increment 与所选 hooks 产物正确，无关内容保持。连续再执行两次，旧入口不复活。仅脚本列表改变或官方退出0不能通过。
2. 在另一个受管目录加入未知附件或用户维护文件。调用前清点应使受影响官方更新停止且目标树零变化，报告精确冲突与恢复条件。登记缺失/损坏、归属不明也须报告无法确认，不手改 registry/生成文件或整目录删除。上游删除风险只可在可丢弃样本中另记，不能算产品保护成功。
3. 对正式准备正文、全部必要附件与同目录 speckit-hooks.json 比较源/Release/实际安装投影摘要。缺正文、缺附件、缺声明、版本不符分别在首个官方调用前失败；配置随技能交付，dist/script 无 definitions。
4. 通过既有 hooks-only 机制注册所选准备/分析/结案；核对 before_implement、after_tasks 和技能自带结案事件、extension ID、条目与实际来源一致，hooks-only 无额外命令。hooks 失败后 Increment 的 commands=not-run；无 Increment 选择只报告命令不适用。
5. 核对生成入口身份、有效正文和附件引用实际可读。官方可以重建 frontmatter，故生成入口不与源 SKILL.md 简单整文件比字节。在无待实施业务任务的实际宿主完整读取准备正文与必要附件并留证，不执行实现；安装/加载不替代主线讨论确认、自然语言发现和逐 Task 方案门禁。
6. 从同版独立产物分别经唯一 Node 入口验证 curl 自动编排、官方安装后显式第二步；关闭、非 workflow、缺项目、缺环境、平台失败、部分成功和重试分别报告。工作区 nuxt-prepare 在自有夹具副本验证来源→hooks→Increment 及失败阻断，不运行真实工作区 postinstall。
7. 按当次 skills 与所选 Specify 适用集成交集验证原生产物和实际加载，旧35项表只作历史；Bash、PowerShell 与 Linux/macOS/Windows 分别留证。缺运行环境逐项未验，不用 Bash 模拟或入口文件存在代替全部宿主结果。

源码与测试沿既有 register-commands/register-hooks/mount-entry/install-skills 增量完善，Node 保持调度职责。已有 test-register-commands.mjs、test_register_commands.py、test-register-hooks.mjs、test_full_remount.py、nuxt-prepare/test-nuxt-prepare.mjs 及 test-build-config.mjs 对当前集合/未知内容/顺序分别验证；其旧集合断言须在后续任务内修订，历史验收记录原文不改。

## E：Git隐匿

```bash
pnpm --filter @foundry/skills run test:distribution -- --mvu E
```

测试普通仓库根、无.git、父仓库下子目录、.git文件worktree/submodule、global有/无项目、项目外技能、共享配置、反向规则、空格/通配字符路径、已跟踪目标、exclude不可写。使用真实 Git check-ignore来源、ls-files和status联合核验。未选路径必须保持可见，原规则不丢失，同版连续两次不重复追加。hidden失败可与安装成功并存，挂载结果不被覆盖。

## F：独立迁移与既有消费者

```bash
pnpm --filter @foundry/skills run test:distribution -- --mvu F
```

在现有单次 Vite 构建上接入 MVU-B/C/D 已验证的安装与挂载能力，沿用 script → dist/script，不增加模式切换或空工具入口。相同输入构建两次并比较摘要；在外部沙箱验证已交付工具不依赖 monorepo。后续公开迁移按明确发布选择核验，不能把当前 dist 全量构建等同于公开集合。检查完整附件、脚本临时输入及缺少实际读取器或必要平台脚本时构建失败；记录包检查、显式读取 dist/mcp/manifest.json 的 registry 检查、link-skills 与已有入口保护。MCP 应用默认路径和上下文估算工具迁移另行验收，不声称已兼容。

## 完整验收与公开仓库阶段

MVU最小实验通过后才填充下游业务，再运行完整矩阵：

```bash
pnpm --filter @foundry/skills run test:distribution -- --matrix full
```

上述单入口由 T063 实现，具体路径是 packages/skills/tests/distribution/matrix.mjs；T002 已交付的调度器只负责调起，并不代为实现矩阵。默认 test:distribution 无 selector 时也包含 full 场景，缺入口必须失败，不能跳过。三平台真实执行与同身份结果汇总均在发布前完成，本机单平台输出不能宣称三平台通过；T037 核验本地全集，T038 在迁后沿同一入口追加 remote 全集，不将 T038 反向设为 T037 前置。

纯安装矩阵对 curl 显式使用 --no-mount，挂载在 D 和完整挂载场景单独验证，避免把环境缺项混入安装结果。

矩阵按实际解析的 skills 版本枚举：3平台 ×(项目级数量+全局支持数量) ×2入口 ×4选择；旧 1.7.4 的 3744 组保留为历史基线。不得以代表agent替代全部组合；真实agent程序可不参与纯安装路径测试，但必须区分路径fixture、真实安装、实际技能调用三种证据。另加 SC-003～007 的失败/重试和挂载矩阵，记录完整文件率100%、技能未选新增0、安装目录用户修改及挂载无关配置保留100%。测试入口须拒绝把缺失运行时的 skip 统计为 pass。

每项证据保存平台/工具版本、实际 upstream.version/integrity 与支持清单、技能 source revision、输入、预期、实际、命令、退出码、产物路径及限制，汇总到本功能后续 `analysis/acceptance/distribution.md`；未执行项逐条说明。当前不预建假通过记录。

T030/T031 准备材料，US4 及 T059 完成后由 T063 实现完整矩阵入口并核验分平台汇总及全部本地组合；T037 消费同源码/文件身份的全矩阵，重建两次、执行完整发布校验并固定 Foundry 候选。新增项目迁移/流水线职责已由 T055/T056/T058～T062 承接：T055/T056 先验候选和 Git 边界，T058/T059 接通驱动/workflow，T060 验本地交付；T061 迁后真实检查与 T062 获授权发布另行执行。原任务身份及验收保持。用户迁移技能源码工程后，在独立公开仓库的新源码 SHA 上重新检查、准备并手动首次正式发布；T061 在迁后重建核验新候选、T062 获明确授权后发布并读回固定来源，T032 再只读比对该远端与对应新候选，不在验收时修改发布物。发布 README 继续参数化接收 RELEASE_SOURCE，来源 commit 不回写 README；真实 URL、源码/发布 SHA、version、catalogDigest、README 摘要和实测命令在发布根外 release-source.md 留证。使用固定来源在三平台补两入口/适用挂载和独立使用者验收，缺地址或真实用户保持未验，不以本地迁移演练抵扣 SC-008。

T032/T038 只读使用实际发布对应的候选，迁移改变身份时须在新仓库重建重验；不能为替换地址修改发布根。T039 若改变交付字节，旧候选及相关验收失效；已公开内容须新版本、重新授权发布并重做适用远端验收，不能复用旧版本通过记录。

当前真实 Increment 反馈验收由 T052 承接，前置为主线当前同版能力移交与可实际规划的分发业务目标，已有 Task 仅关联职责，不再要求 Task 定位参数。Tutor 的 T053 与 Pair/Direct 专项移出本期测试、移交和结案，保留身份与历史，不只是后置待补。当前tasks已修订原四/五项做法，T053原文/checkbox迁至暂停历史并移出收尾依赖；工程勾选未变，仍需按实际命令和证据验收。双方只回链真实证据，不互相自动勾选。

**历史说明（已由上述当前集合及验收分工替代，不作为续接入口）**：外部项目具有独立可追溯产物与真实正式任务后，可开展限定环境的 Explore/Guide 行为验收，不等待 T032/T038 全矩阵或公开发布完成。分发记录来源、安装与挂载，工作流 T044/T045 记录实际使用并互链。工作流 T038/T046 的公共规则覆盖仍按原验收，本功能不自动完成它们或伪造学习证据。

## 历史：计划阶段实际检查（2026-11-02）

- 10份新增计划文档逐文件执行 `pnpm --config.verifyDepsBeforeRun=false exec eslint --fix <文件>`，并统一执行同参数的 `eslint <10份文件>`，均通过。该参数只关闭pnpm执行前自动依赖校验，不改变ESLint规则。
- 本地相对链接检查无失效；plan覆盖FR-001～027；兼容清单79项无重复；六项MVU表的命中事实、假设和信号检查通过；`git diff --check`通过。
- 开始规划时记录的12份已有文件逐一核对SHA-256均不变，包含用户已有配置修改、spec、前阶段快照与原T038记录。
- Mermaid自动检查未完成：`node --input-type=module`调用本地mermaid.parse时缺少浏览器DOM，报DOMPurify.sanitize不可用；随后同方式使用Puppeteer启动 `/snap/bin/chromium`，被沙箱拒绝创建 `/run/user/1000/snap.chromium`，退出46。图表已按文本复核，尚无自动语法/渲染通过证据；需要可运行浏览器的环境补验8张图。未为此安装浏览器或修改系统配置。
- 上述是计划产物检查，不是功能代码验证。MVU、完整矩阵、包代码检查和真实远端验收尚未执行，原因是本轮只获授权推进plan且实现尚不存在；按本指南留待后续阶段。

## 原样脚本与入口分工验证

构建验证须给运行脚本放入无法解析的第三方 import，确认 build 仍能原样交付；逐字节核对 mjs/ts/json 和运行目录，排除测试、缓存及本机 node_modules。复制到独立目录后准备 Node、tar 及平台工具，经唯一 Node 入口验证读取器和平台调用；不要求第三方 Node 运行库，不编译本包运行代码。T003 TS 实验辅助模块保留在 tests/distribution/helpers，使用开发依赖执行，不进入业务交付目录。T003 的官方配置探针编译仅为读取第三方源码的测试手段。

T004/T005 后续分别验证 curl 自动准备运行依赖和用户手动启动公共入口；T019/T027 验证自动安装挂载串联。缺依赖、下载失败、版本不符须报告失败；目标项目依赖文件保持不变。当前只完成构建边界修正，不能把这些待实现步骤记为通过。

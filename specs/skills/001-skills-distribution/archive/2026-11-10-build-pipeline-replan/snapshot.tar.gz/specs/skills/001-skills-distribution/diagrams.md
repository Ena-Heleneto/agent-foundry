# 技术流程图：分发核验与阶段状态

2026-11-10 按当前 spec、plan 与数据模型同步 Increment、实施准备、旧入口迁移及 Agent 在线来源；唯一公开入口仍为 node script/index.mjs。下图区分已具备的只读数据查询与后续安装、挂载流程，图示不代表完整平台或业务验收。来源：[plan.md](plan.md)、[data-model.md](data-model.md)。

## 安装与官方预检的 Agent 来源

```mermaid
flowchart TD
    A[每次调用查询官方 npm skills latest] --> B[校验同一发布包的版本与完整性]
    B --> C{规则读取成功吗}
    C -->|否| F[失败并保持目标零写入 不回退旧表]
    C -->|是| D[按本次规则解析所选 agent 与 scope]
    D --> E[核对选择 实际路径及已有内容冲突]
    E --> G{检查通过吗}
    G -->|否| F
    G -->|是| H{是否官方只读预检}
    H -->|是| I[报告实际版本及同版命令 不执行安装]
    H -->|否| J[进入平台已支持的安装流程]
```

术语：latest 是本次查询的渠道；version/integrity 是实际取得包的版本与完整性证据，同次规则和建议 CLI 一致，下次重查。自有技能 release 版本及来源提交仍固定。读取器只提供数据，不执行 CLI 入口、准备 npm 缓存或写目标；规则布局变化须明确失败。普通安装的后续能力仍受各任务实际支持范围限制。

实现位置：`packages/skills/script/install-skills/read-agents.mjs` 及安装平台脚本。构建原样复制脚本，不查询在线数据，不维护包根 distribution 或 agents.json。已有验证见[在线来源记录](analysis/acceptance/online-agent-source.md)，未宣称未来上游或完整跨平台通过。

## 单技能提交状态

```mermaid
stateDiagram-v2
    [*] --> Pending
    Pending --> Reused: 归属及全部字节相同
    Pending --> Failed: 未知或修改冲突
    Pending --> Staged: 空目标下载暂存
    Staged --> Verified: 文件全集与摘要通过
    Staged --> Failed: 下载或核验失败
    Verified --> Installed: 提交前复查后完成目录提交
    Verified --> Failed: 目标变化或写入失败
    Reused --> [*]
    Installed --> [*]
    Failed --> [*]
```

术语：Pending＝待处理；Staged＝文件只在临时目录；Verified＝文件已验完整；Installed＝已经交付；Reused＝现有同版内容通过重验；Failed＝失败，不参与挂载。逐技能成功不等于整批成功。

计划位置：`packages/skills/script/install-skills/install-skills.sh` 及 .ps1 的安装与归属核验。

## 内部挂载顺序

```mermaid
flowchart TD
    A[明确版本与本次选择] --> B[核验实际技能和公共材料]
    B --> C{项目与环境适用吗}
    C -->|非Spec Kit| S[挂载跳过并保留安装结果]
    C -->|缺条件或冲突| F[挂载失败]
    C -->|可用| D[处理全部选中钩子映射]
    D --> E{钩子均成功或不适用}
    E -->|否| N[指令未执行]
    E -->|是| G{本次选择包含Increment吗}
    G -->|否| K[指令不适用]
    G -->|是| M{所选Increment自身文件齐备吗}
    M -->|否| X[报告缺项 保留安装 不补装]
    M -->|是| R[官方重装Increment并读回旧入口去留]
    R --> H[核验原生产物并分别汇报]
```

术语：公共材料＝独立取得的同版脚本与发布清单；映射＝技能需要注册哪些动作；原生产物＝Specify CLI实际创建的文件与配置。环境检查不是自动安装前置工具。仅本次所选 Increment 自身齐备后每次官方重装，不要求三暂停模式，技能安装可复用不代表命令跳过。

计划位置：`packages/skills/script/mount-entry/`、`register-hooks/`；已存在且复用：`packages/skills/script/register-commands/`。外部整体验收尚未通过。

## 精确排除的判定

```mermaid
flowchart TD
    A[请求hidden] --> B{明确项目自身git是目录吗}
    B -->|否| S[说明原因并跳过]
    B -->|是| C[筛选本次成功且项目内的独占路径]
    C --> D{路径被跟踪或属于共享配置吗}
    D -->|已跟踪| F[报告冲突失败]
    D -->|共享配置| L[保留可见并报告限制]
    D -->|独占未跟踪| E[追加精确规则且保留原文]
    E --> G[核验Git实际命中来源和效果]
    G --> H{规则生效吗}
    H -->|是| I[隐匿成功]
    H -->|否| J[隐匿失败但保留安装内容]
```

术语：hidden＝让Git普通未跟踪列表不显示本地文件；独占路径＝只含本次安装器拥有的内容；共享配置＝多个功能共同使用的文件，不能整体隐藏；命中来源＝实际让Git忽略该路径的规则位置。

计划位置：`packages/skills/script/install-skills/install-skills.sh` 及 .ps1 的 Git 排除能力。规范状态与公开返回格式见数据模型。

## 直接源码迁移、候选与来源身份（2026-11-10 更新）

```mermaid
flowchart LR
    A[明确的 Foundry 源码提交] --> B[记录直接迁移所需文件及调整]
    B --> C[当前版本隔离验证候选和流水线边界]
    C --> D[同源同依赖快照两次构建]
    D --> E[ReleaseCandidate 仅白名单文件]
    B --> F[用户直接迁入独立公开仓库]
    F --> G[新仓库维护配置依赖并按新源码检查构建候选]
    G --> H[PublishRequest 绑定候选及运行身份]
    H --> I[Publication 独立候选树提交与版本 tag]
    I --> J[官方 tree 目录 URL]
    I --> K[脚本 raw 文件根 URL]
    J --> L[绑定同 repository 和 publishedRevision]
    K --> L
```

源码由用户直接迁移，新仓库维护依赖配置；本功能不导出工程包或生成配置投影。ReleaseCandidate 是白名单安装内容，与源码范围分别限定。迁移后的源码 SHA 变化，须在新仓库重建和重新授权。官方 tree URL 负责目录发现，raw URL 用于逐文件下载，两者对应同一发布提交；发布 SHA 与源码 SHA 分别保存。候选索引及 CI 报告在安装发布根之外。

计划位置：`packages/skills/build/ci/{run,candidate,publish}.mjs` 与两份 skills workflow，尚未实施；数据和调用见 [数据模型](data-model.md) 及 [流水线契约](contracts/pipeline.md)。本图是设计关系，不表示已经完成迁移或构建实验。

## 发布写入与核验分开记录

```mermaid
stateDiagram-v2
    [*] --> Checked: 默认分支检查通过
    Checked --> Candidate: 固定源码与文件身份
    Candidate --> Rejected: 身份错误 过期 篡改或未授权
    Candidate --> Authorized: 独立仓库手动请求且守卫通过
    Authorized --> Published: 新 tag 创建成功
    Authorized --> Reused: 已有 tag 全部字节相同
    Authorized --> Rejected: 已有同版内容不同
    Authorized --> Unknown: 推送响应丢失
    Unknown --> Published: 读回证明本次已创建
    Unknown --> Reused: 读回已有相同内容
    Unknown --> Retryable: 读回证明未创建
    Unknown --> Partial: 无法核实远端事实
    Retryable --> Authorized: 相同候选重新授权核对
    Published --> Verified: 远端全文件及安装验证通过
    Reused --> Verified: 远端全文件及安装验证通过
    Published --> Partial: 远端核验失败
    Reused --> Partial: 远端核验失败
    Partial --> Verified: 仅重验既有固定来源通过
    Rejected --> [*]
    Verified --> [*]
```

Authorized 表示明确候选的发布授权通过；Published 表示写入已发生；Verified 表示该运行请求的远端校验通过，完整支持矩阵及独立使用者验收仍按原任务分别判断；Partial 保留已知 ref 和尚未验证的部分，不能重写成“从未发布”。响应丢失先读远端，未知状态不能盲目重推。并发请求仅尝试无 force 创建一个新 tag，以远端实际结果裁决；同版不同内容始终拒绝。

计划位置：`packages/skills/build/ci/publish.mjs`、release workflow 和 PipelineRun 报告；本期只在临时 bare Git 验证状态分支，真实 Actions/HTTPS/安装在迁后补证。Foundry 模式不会进入真实 Authorized/Published 阶段。

## 旧入口迁移中的用户内容保护

```mermaid
flowchart TD
    A[核对旧登记和明确受管路径] --> B{有未知附件 用户维护文件或归属不明吗}
    B -->|有| C[停止受影响官方调用 保留现场 报告冲突]
    B -->|无| D[官方同ID更新为仅Increment]
    D --> E[读取旧入口 登记及无关文件的实际变化]
    E --> F{符合当前集合并保护原内容吗}
    F -->|否| G[报告已写与未验 返回方案或修复记录]
    F -->|是| H[连续重试两次 核对旧入口不复活]
```

术语：受管＝有明确来源和官方登记的对象；未知附件＝无法证明属于可替换交付的额外内容；同 ID 更新＝官方先移除旧登记再注册新集合。仅检查明确受影响目录，不增加永久指纹或自动搬移用户文件。

计划位置：packages/skills/script/mount-entry、register-commands 与 register-hooks 双平台模块。D-MOUNT 尚未实际运行；本图不说明真实用户目录已迁移。

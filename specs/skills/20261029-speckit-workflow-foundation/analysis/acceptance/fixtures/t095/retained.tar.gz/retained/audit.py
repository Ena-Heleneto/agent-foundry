"""独立核对真实官方输出、发现与全文读取；不替代业务或自然语言验收。"""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parent
REPO=Path('<source-workspace>')
def tree(root):
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}
reports={}
for name in ['project','global','references-control','references-bridged']:
 case=ROOT/'official-cases'/name; project=case/'project'; skills=(case/'user' if name=='global' else project)/'.agents/skills';source=Path(str(skills)+'-speckit-sources')/'task-increment';extension=project/'.specify/extensions/modes'
 assert not (skills/'task-increment').exists()
 assert tree(source)==tree(case/'sources/task-increment')==tree(extension/'skills/task-increment')
 for skill,kind in [('implementation-preparation','workflow'),('business-node-delivery','coding')]:
  assert tree(skills/skill)==tree(REPO/'packages/skills/src'/kind/skill)
 calls=json.loads((case/'calls.json').read_text()); assert len(calls)==4 and all(c['status']==0 for c in calls)
 generated=project/'.agents/skills/speckit-modes-increment/SKILL.md';assert generated.is_file()
 assert generated.read_bytes()==(ROOT/'official-cases-final-code'/name/'project/.agents/skills/speckit-modes-increment/SKILL.md').read_bytes(),(name,'最终重跑入口与被宿主读取版本不一致')
 assert not any((project/'.agents/skills'/s).exists() for s in ['task-pair','task-tutor','task-direct','speckit-modes-pair','speckit-modes-tutor','speckit-modes-direct'])
 report={'source_files':tree(source),'extension_source_files':tree(extension/'skills/task-increment'),'generated_sha256':hashlib.sha256(generated.read_bytes()).hexdigest(),'official_calls':len(calls),'scope':'global' if name=='global' else 'project'}
 if name.startswith('references-'):
  doc=generated.read_text(); link=re.search(r'\[必要附件\]\(([^)]+)\)',doc)[1];target=(project if link.startswith('.specify/') else generated.parent)/link; readable=target.is_file()
  assert readable==(name=='references-bridged')
  if readable:assert target.read_bytes()==(case/'sources/task-increment/references/t095-note.md').read_bytes()
  report['attachment']={'reference':link,'actual_readable':readable}
 reports[name]=report
for name in ['missing-increment','missing-preparation','unknown-source','unknown-hidden','unknown-generated','unknown-extension','linked-root','collision','file-directory','missing-reference','symlink']:
 case=ROOT/'official-cases-final-code'/name; assert json.loads((case/'calls.json').read_text())==[],name
for name in ['project','global','references-bridged']:
 result=json.loads((ROOT/'discovery'/name/'result.json').read_text()); assert result['raw_increment_not_discovered'] and result['errors']==[]
hosts={}
for name in ['global','references-bridged']:
 out=ROOT/'host'/name;result=json.loads((out/'result.json').read_text()); assert result['exit']==0 and not result['timeout'] and result['changed']==[]
 assert json.loads((out/'before.json').read_text())==json.loads((out/'after.json').read_text())
 es=[json.loads(l) for l in (out/'events.jsonl').read_text().splitlines() if l.strip()];commands=[e['item'] for e in es if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='command_execution']; outputs=[c.get('aggregated_output','') for c in commands]
 entries=json.loads((ROOT/'discovery'/name/'response.json').read_text())['data'][0]['skills'];checks={}
 for entry in entries:
  if entry['name'] in ['speckit-modes-increment','implementation-preparation']:
   text=Path(entry['path']).read_text().strip();matches=[c.get('id') for c in commands if text in c.get('aggregated_output','')]; assert matches,(name,entry['name'],'缺完整工具输出');checks[entry['name']]=matches
 if name=='references-bridged':
  text=(ROOT/'official-cases'/name/'project/.specify/extensions/modes/references/t095-note.md').read_text().strip(); assert any(text in o for o in outputs)
 result['full_read_command_ids']=checks;result['note']='明确请求下实际全文读取；自然语言完整行为未验';hosts[name]=result
for log in ['official-final-code.log']:
 text=(ROOT/log).read_text();assert 'pass 12' in text and 'fail 0' in text and 'skipped 0' in text
before=json.loads((ROOT/'parent-before.json').read_text())
for relative,digest in before.items():
 if relative.startswith('packages/') or relative.startswith('.specify/') or relative.endswith('/plan.md') or relative.endswith('/contracts/registration.md'):
  assert hashlib.sha256((REPO/relative).read_bytes()).hexdigest()==digest,relative
report={'official_cases':reports,'negative_cases_zero_official_calls':11,'discovery_cases':3,'host_cases':hosts,'official_tests':{'passed':12,'failed':0,'skipped':0},'package_checks':{'lint':'退出1，collections.ts entries原有两项错误','check-types':'退出0','test':'12项通过、退出0','target-eslint':'退出0','build':'按明确指令暂跳过'},'production_sources_and_registration_scripts_unchanged':True,'limits':['仅Linux与本机宿主版本','实际发现和明确请求下读取分开验证，非T099普通自然语言行为','正式生产安装器/真实挂载尚未实施','无build/dist消费或真实用户效果']}
(ROOT/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'cases':list(reports),'zero_call_cases':11,'discovery_cases':3,'hosts':{n:{'exit':s['exit'],'elapsed_seconds':s['elapsed_seconds'],'full_read_command_ids':s['full_read_command_ids']} for n,s in hosts.items()},'checks':report['package_checks']},ensure_ascii=False,indent=2))

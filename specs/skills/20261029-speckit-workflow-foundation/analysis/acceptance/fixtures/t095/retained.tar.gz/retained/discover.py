"""使用本机实际协议调用skills/list；不以目录枚举或模型描述冒充发现。"""
from pathlib import Path
import json, os, selectors, subprocess, sys, time
ROOT=Path(__file__).resolve().parent
name=sys.argv[1]
case=ROOT/'official-cases'/name
project=case/'project'
out=ROOT/'discovery'/name
out.mkdir(parents=True,exist_ok=False)
env={**os.environ,'HOME':str(case/'user'),'USERPROFILE':str(case/'user'),'XDG_CONFIG_HOME':str(case/'user/.config'),'XDG_CACHE_HOME':str(case/'user/.cache'),'XDG_STATE_HOME':str(case/'user/.local/state'),'XDG_DATA_HOME':str(case/'user/.local/share')}
# 不复制凭据；本接口不调用模型，全部运行时状态也在测试用户目录。
env.pop('CODEX_HOME',None)
for key in list(env):
 if key.startswith('GIT_'):env.pop(key)
requests=[{'id':1,'method':'initialize','params':{'clientInfo':{'name':'foundry-t095','version':'0.1.0'},'capabilities':{'experimentalApi':True}}},{'method':'initialized','params':{}},{'id':2,'method':'skills/list','params':{'cwds':[str(project)],'forceReload':True}}]
(out/'requests.json').write_text(json.dumps(requests,ensure_ascii=False,indent=2)+'\n')
start=time.monotonic(); received=[]; response=None
with (out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(['codex','app-server','--stdio'],cwd=project,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=stderr,text=True,bufsize=1)
 selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
 try:
  p.stdin.write(json.dumps(requests[0])+'\n');p.stdin.flush()
  while time.monotonic()-start<45:
   ready=selector.select(1)
   if not ready:
    if p.poll() is not None:break
    continue
   line=p.stdout.readline()
   if not line:break
   event=json.loads(line);received.append(event)
   if event.get('id')==1:
    if event.get('error'):raise RuntimeError(event['error'])
    for request in requests[1:]:p.stdin.write(json.dumps(request)+'\n')
    p.stdin.flush()
   if event.get('id')==2:
    if event.get('error'):raise RuntimeError(event['error'])
    response=event['result'];break
 finally:
  p.terminate()
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:p.kill();p.wait()
  selector.close()
(out/'events.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in received))
assert response is not None, (out/'stderr.log').read_text()[-1200:]
(out/'response.json').write_text(json.dumps(response,ensure_ascii=False,indent=2)+'\n')
items=response['data'][0]
names=[s['name'] for s in items['skills']]
assert names.count('speckit-modes-increment')==1,names
assert names.count('implementation-preparation')==1,names
assert names.count('business-node-delivery')==1,names
assert 'task-increment' not in names,names
assert not any(n in names for n in ['task-pair','task-tutor','task-direct','speckit-modes-pair','speckit-modes-tutor','speckit-modes-direct']),names
assert not items['errors'],items['errors']
proof={'case':name,'project':str(project),'elapsed_seconds':round(time.monotonic()-start,3),'skills':[{'name':s['name'],'path':s['path'],'scope':s['scope']} for s in items['skills'] if s['name'] in ['speckit-modes-increment','implementation-preparation','business-node-delivery']],'raw_increment_not_discovered':True,'errors':items['errors'],'model_called':False,'authentication_copied':False}
(out/'result.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n');print(json.dumps(proof,ensure_ascii=False))

"""T095父资料允许差异、稳定身份、引用与正式来源保护核查。"""
from pathlib import Path
import hashlib,json,re,unicodedata
from urllib.parse import unquote
ROOT=Path('<source-workspace>')
TEMP=Path(__file__).resolve().parent
BASE=ROOT/'specs/skills/20261029-speckit-workflow-foundation'
BEFORE=TEMP/'parent-before/specs/skills/20261029-speckit-workflow-foundation'
def slug(s):
 s=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',s).replace('`','').strip().lower()
 return ''.join(c for c in s if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LN').replace(' ','-')
paths=[BASE/'implementation/T095.md',BASE/'analysis/acceptance/entry-discovery-mechanism.md',BASE/'analysis/acceptance/fixtures/t095/README.md']
links=0
for p in paths:
 for v in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in v:continue
  f,_,anchor=v.partition('#');target=(p.parent/unquote(f)).resolve() if f else p
  assert target.is_file(),(str(p),v)
  if anchor:
   s=target.read_text();anchors={slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',s,re.M)}|set(re.findall(r'<a\s+id="([^"]+)"',s));assert unquote(anchor) in anchors,(str(p),v)
  links+=1
old=(BEFORE/'tasks.md').read_text();new=(BASE/'tasks.md').read_text();pattern=r'^- \[([ xX])\] (T\d+)\b';a=re.findall(pattern,old,re.M);b=re.findall(pattern,new,re.M)
assert [t for c,t in a]==[t for c,t in b]
changes=[{'id':ta,'before':ca,'after':cb} for (ca,ta),(cb,tb) in zip(a,b) if ca!=cb]
assert all(c=={'id':'T095','before':' ','after':'x'} for c in changes)
assert old.split('## 三模式暂停记录',1)[1]==new.split('## 三模式暂停记录',1)[1]
pattern=r'^- \*\*(?:FR|SC)-\d+\*\*.*$';assert re.findall(pattern,(BEFORE/'spec.md').read_text(),re.M)==re.findall(pattern,(BASE/'spec.md').read_text(),re.M)
for relative,digest in json.loads((TEMP/'parent-before.json').read_text()).items():
 if relative.startswith('packages/') or relative.startswith('.specify/') or relative.endswith('/plan.md') or relative.endswith('/contracts/registration.md'):
  assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==digest,relative
mvuOld=(BEFORE/'mvu.md').read_text();mvuNew=(BASE/'mvu.md').read_text(); sections=lambda s:{name:body for name,body in re.findall(r'^(## MVU-\d+.*?)\n(.*?)(?=^## MVU-|\Z)',s,re.M|re.S)}
for name,body in sections(mvuOld).items():
 if name.strip()!='## MVU-004':assert sections(mvuNew).get(name)==body,name
report={'new_document_links':links,'all_107_task_ids_and_order_preserved':True,'checkbox_changes':changes,'paused_and_history_preserved':True,'FR_SC_definitions_preserved':True,'formal_sources_scripts_constitution_pointer_plan_contract_preserved':True,'other_nine_mvu_preserved':True}
(TEMP/'parent-check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))

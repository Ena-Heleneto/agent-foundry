"""明确请求下的实际正式正文/附件读取；不冒充自然语言识别或业务执行。"""
from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
name=sys.argv[1]
case=ROOT/'official-cases'/name
project=case/'project'
out=ROOT/'host'/name
if out.exists():out.rename(ROOT/'host'/(name+'-environment-first'))
out.mkdir(parents=True)
metadata=json.loads((ROOT/'discovery'/name/'response.json').read_text())['data'][0]['skills']
selected=[s for s in metadata if s['name'] in ['speckit-modes-increment','implementation-preparation']]
paths=[s['path'] for s in selected]
assert len(paths)==2
prompt='这是T095隔离来源与加载验证，下面路径来自本轮真实skills/list。仅做明确请求下的只读全文加载，不执行技能里的业务、规划、讨论或写入流程。分别完整读取每份SKILL.md，工具输出不能用head/sed截断；若正文的T095隔离附件引用存在，也完整读取其实际目标，路径以当前项目根解释。返回实际读取路径、入口与维护源的区别及未验边界即可，不生成或修改任何文件、不用子代理。\n'+ '\n'.join(paths)+'\n'
(out/'input.txt').write_text(prompt)
def snap():
 return {str(p.relative_to(case)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(case.rglob('*')) if p.is_file() and '.git' not in p.parts and '.codex' not in p.relative_to(case).parts}
before=snap();(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
args=['codex','exec','--cd',str(project),'--skip-git-repo-check','--sandbox','read-only','--json','--color','never','--output-last-message',str(out/'final.txt'),'-']
start=time.monotonic()
with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(args,cwd=project,env={**os.environ,'DO_NOT_TRACK':'1'},stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,text=True,start_new_session=True)
 timeout=False
 try:p.communicate(prompt,timeout=180)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
after=snap();(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
result={'case':name,'exit':p.returncode,'timeout':timeout,'elapsed_seconds':round(time.monotonic()-start,3),'args':args,'model_override':False,'changed':[k for k in sorted(before.keys()|after.keys()) if before.get(k)!=after.get(k)],'discovery_and_load_are_separate':'发现用隔离测试用户的实际skills/list；本回合用既有认证运行时，在只读项目明确请求读取已发现的实际路径，不称自然语言行为验证'}
(ROOT/'host'/name/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
if (out/'final.txt').exists():print((out/'final.txt').read_text()[:1800])
if p.returncode:print((out/'stderr.log').read_text()[-1200:])
raise SystemExit(0 if p.returncode==0 and not timeout else 1)

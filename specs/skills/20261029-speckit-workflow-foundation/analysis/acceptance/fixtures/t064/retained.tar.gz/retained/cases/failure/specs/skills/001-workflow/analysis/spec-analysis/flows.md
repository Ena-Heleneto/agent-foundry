# 功能分析流程图

依据[有效规格](../../spec.md)、[总体方案](../../plan.md)、[闭环详情](../../mvu.md)和[原任务清单](../../tasks.md)。下图解释计划中的判断与关系，不记录实施或验收通过；全部 Mermaid 仅保存源码，不渲染。MVU 指可观察的小业务结果，hook 指原生入口调用扩展的接点。

## Implement 业务判断

用户希望得到当前任务的可继续范围，材料不足时先得到停止原因。计划位置：原生 Implement 与共同准备 skill，实际正文当前缺失；业务要求和验收位置为 [spec.md](../../spec.md)、[mvu.md](../../mvu.md) 的 MVU-001、[tasks.md](../../tasks.md) 的 T002、T007。本图不表示 hook 自带程序级锁。

```mermaid
flowchart TD
    A[用户进入当前 Task 的 Implement] --> B{适用真实认可方案和必要资料齐备吗}
    B -->|否| C[说明缺项与恢复动作 停止受影响业务]
    B -->|是| D{保存读回 技术前置及授权满足吗}
    D -->|否| C
    D -->|是| E[原生入口实际消费当前 Task 和方案]
    E --> F[核对读取与调用证据 回传可继续范围]
```

## Increment 业务判断

用户给定 Spec 和可选业务描述后得到可读的小结果、职责和依赖。实际资料规划入口为[本地 Increment 技能](../../../../../.agents/skills/task-increment/SKILL.md)，输入边界依据[已同步的历史要求](../../spec.md#本次同步的历史要求)，有效职责与验收沿 [mvu.md](../../mvu.md) 的 MVU-002 和 [tasks.md](../../tasks.md) 的原 T006 阅读。仅 Spec 时复用已有有效材料；明确旧式 Task 定位不触发规划写入，描述中引用原 Task 仍用于职责关联，不应被误拒。

清单保存简洁目标、必要范围/约束/依赖、整体验收和唯一工程 checkbox；详细逻辑留待原 Task 实际开工前讨论认可后保存独立方案并链接。下图只解释分工，不在分析中认可方案或另建任务/MVU。本次已在同一会话执行资料规划并从保存障碍续接分析，未运行这些输入分支的入口专项验证，也不据图示勾选 T006。

```mermaid
flowchart TD
    A[接收 Spec 定位与可选描述] --> I{明确使用旧式 Task 定位参数吗}
    I -->|是| J[说明不再支持 待意图明确前不据参数写规划]
    I -->|否| K{提供业务描述了吗}
    K -->|否| L[复用已保存有效材料]
    K -->|是| M[提取业务意图 保留原 Task 的职责引用]
    L --> N[读取原文 spec plan 同级 mvu tasks 及实际证据]
    M --> N
    N --> B[先确定可观察小结果]
    B --> C[复用原 Task 映射职责与必要依赖]
    C --> O[保持轻量清单 详细方案留待开工前讨论认可]
    O --> D[逐份保存规划 检查并读回]
    D --> E{规划保存及核对成功吗}
    E -->|否| F[报告实际已写 未写及恢复条件 从原路径磁盘续接]
    E -->|是| G[显式调用同一分析技能]
    G --> P{分析逐份保存 检查及完整读回成功吗}
    P -->|否| F
    P -->|是| H[分别回执规划与分析结果 不自动实施]
```

## 分发业务判断

使用者最终应只得到有效入口。计划目标为 `specs/skills/001-skills-distribution/` 的真实挂载脚本，当前未定位，不创建该路径；本 Spec 的职责与验收位置为 [mvu.md](../../mvu.md) 的 MVU-003、[tasks.md](../../tasks.md) 的 T008。

```mermaid
flowchart TD
    A[依据原文整理分发提示词] --> B{真实目标 授权与必要前置齐备吗}
    B -->|否| C[保留协同资料 报告目标侧未验及恢复条件]
    B -->|是| D[目标侧保留 Implement 和 Increment 移除三模式挂载]
    D --> E[真实入口加载核验并保护历史引用]
```

## 技术职责与调用关系

这是[既有图示导航](../../diagrams.md)指向的唯一技术图。实际位置：[扩展配置](../../../../../.specify/extensions.yml)、[任务入口脚本](../../../../../.specify/scripts/bash/setup-tasks.sh)、[Increment 技能](../../../../../.agents/skills/task-increment/SKILL.md)、[本地分析技能](../../../../../.agents/skills/artifact-spec-analysis/SKILL.md)、[正式分析来源](../../../../../.specify/extensions/artifact-spec-analysis/skills/artifact-spec-analysis/SKILL.md)。setup 脚本负责定位和模板输出，after_tasks 分析由原生任务命令流程按扩展配置调用，不是该脚本内直接执行分析。本次恢复未重跑 setup 或 after_tasks，Increment 保存后的显式调用和恢复沿用同一分析技能及原目标，不注册 after_increment，也不建立分析生成器。

分析消费者须实际打开同级 mvu，核对四项详情、Task 职责和证据，不以文件发现清单或 plan 导航代替消费。按项目约定先保存 README、检查并全文读回，再保存 flows 并同样核验；任一失败只停止受影响动作，回执实际已写和未写，不替换保护对象或改用替代路径。

准备 skill 和 Implement 模板的预期位置分别为 `.agents/skills/implementation-preparation/SKILL.md`、`.agents/skills/speckit-implement/SKILL.md`，本副本均不存在；虚线表示计划接入，不证明调用已成立。资料分析两种调用关系与 Implement 业务准备分别核验，分析保存不证明宿主契约、工程或业务通过。

```mermaid
flowchart TD
    A[原生 setup 解析模板和目标 Spec] --> B[任务命令生成 tasks 并补齐同级 mvu 职责]
    B --> C[任务命令流程按扩展配置调用 after_tasks]
    C --> D[同一 artifact-spec-analysis 读取需求 spec plan mvu tasks 与证据]
    J[Increment 接收 Spec 与可选描述] --> K[读取原输入及实际规划 核对同级 mvu 四项和职责]
    K --> L[先闭环后轻量任务 逐份保存规划并核验]
    L --> M{规划保存 检查及读回成功吗}
    M -->|是 显式调用| D
    M -->|否| N[报告已写 未写和恢复条件 只停止受影响动作]
    D --> E[先保存 README 检查并全文读回 再处理 flows]
    E --> O{两份分析保存 检查及完整读回成功吗}
    O -->|否| N
    O -->|是| P[回执分析资料结果 保留任务与业务验收边界]
    F[原生 Implement 模板 当前缺失] -.计划 before_implement.-> G[共同准备 skill 当前缺失]
    G -.计划逐 Task 消费.-> H[spec plan mvu 原 Task 及适用真实认可方案]
    G -.条件不足须停止 仍待实证.-> I[返回缺项与恢复范围]
```

## MVU 里程碑与流转

里程碑只表示预期可观察交付，状态和四项详情仍以 [mvu.md](../../mvu.md) 为准，工程完成事实只在 [tasks.md](../../tasks.md)。实线表示必要前置，虚线仅表示 plan 推荐先整理资料；不由此新增 T006 到 T007 或 T002 的强制依赖。计划位置为本 Spec 现有规划产物，宿主和目标分发位置仍待核实。

```mermaid
flowchart TD
    A[MVU-002 读者看清小结果和原任务职责 T006] -.推荐先整理 不强制依赖.-> B[T007 契约调用和消费信号成立]
    B --> C[MVU-001 用户得到可靠准备结论 T002]
    B --> D[MVU-003 真实目标仅加载有效入口 T008]
    C --> D
    E[真实目标和适用授权] --> D
    A --> F[有效范围实现及必要验证完成后 T009 收尾]
    C --> F
    D --> F
```

T006 资料整理、T002 前期讨论及 T008 提示词整理可独立推进；共享文件写入须串行。T007 失败仅阻止契约依赖的验收，目标缺失仅阻止目标侧操作与验收；三种暂停模式不进入本期流转。里程碑图不表示本轮开展上述业务验证或清理。

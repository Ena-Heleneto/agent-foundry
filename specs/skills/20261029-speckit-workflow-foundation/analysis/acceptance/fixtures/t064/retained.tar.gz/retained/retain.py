"""保留T064真实输入、宿主事件、快照和核查，排除Git和个人画像。"""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parent
REPO=Path('<source-workspace>')
DEST=REPO/'specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/t064'
retained=ROOT/'retained'
assert not retained.exists()
retained.mkdir()
for name in ['prepare.py','run.py','delta.py','audit.py','retain.py','audit.json','parent-before.json','parent-links.json','parent-protection-initial.json','delta-proof.json','failure-unblock.json','final-assertions.json']:
 source=ROOT/name
 if source.exists():shutil.copy2(source,retained/name)
for name in ['installations','extension-input','host','before-project','snapshots','cases','failure-original']:
 shutil.copytree(ROOT/name,retained/name,ignore=shutil.ignore_patterns('.git','__pycache__'))
formal=retained/'formal-source'
formal.mkdir()
for name in ['artifact-spec-analysis','task-increment']:
 shutil.copytree(REPO/'packages/skills/src/workflow'/name,formal/name)
shutil.copy2(REPO/'packages/skills/src/workflow/collection.config.json',formal/'collection.config.json')
files=[p for p in retained.rglob('*') if p.is_file()]
assert not any('user-shadow' in p.parts or p.name in {'.env','auth.json','credentials.json'} for p in files)
manifest={str(p.relative_to(retained)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(retained/'files.sha256.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=DEST/'retained.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(retained,arcname='retained')
verification=ROOT/'archive-verify'
verification.mkdir()
with tarfile.open(archive,'r:gz') as tar:tar.extractall(verification,filter='data')
for rel,digest in manifest.items():assert hashlib.sha256((verification/'retained'/rel).read_bytes()).hexdigest()==digest,rel
for name in ['created','changed','failed','recovered','final']:
 path=verification/'retained/snapshots'/name
 if not path.exists():continue
 assert all(p.is_file() for p in path.rglob('SKILL.md'))
result={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files_verified':len(manifest),'safe_extract_and_full_hash_match':True,'profile_excluded':True}
(ROOT/'archive-proof.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

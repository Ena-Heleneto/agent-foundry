"""T064独立核验：实际读取、保存、身份保护和引用；不替代用户验收。"""
from pathlib import Path
import hashlib
import json
import re
import unicodedata
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parent
FEATURE = Path('specs/skills/001-workflow')
REPO = Path('<source-workspace>')

def digest(path):
 return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(project):
 return {str(p.relative_to(project)):digest(p) for p in sorted(project.rglob('*')) if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts}

def slug(text):
 text=re.sub(r'\[([^]]+)\]\([^)]+\)',r'\1',text).replace('`','').strip().lower()
 return ''.join(c for c in text if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LN').replace(' ','-')

def check_links(paths):
 checked=[]
 for path in paths:
  text=path.read_text()
  assert text.endswith('\n') and all(l==l.rstrip() for l in text.splitlines()),str(path)
  assert not re.search(r'^\s*- \[[ xX]\]',text,re.M),str(path)
  for value in re.findall(r'\]\(([^)]+)\)',text):
   if '://' in value or value.startswith('mailto:'):continue
   file,_,anchor=value.partition('#'); target=(path.parent/unquote(file)).resolve() if file else path
   assert target.is_file(),(str(path),value)
   if anchor:
    content=target.read_text()
    anchors={slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',content,re.M)}|set(re.findall(r'<a\s+id="([^"]+)"',content))
    assert unquote(anchor) in anchors,(str(path),value,sorted(anchors))
   checked.append({'file':str(path),'reference':value})
 return len(checked)

def task_marks(path):
 return re.findall(r'^- \[([ xX])\] (T\d+)\b',path.read_text(),re.M)

def audit_stage(stage):
 folder=ROOT/'host'/stage
 result=json.loads((folder/'result.json').read_text())
 events=[]
 for line in (folder/'events.jsonl').read_text().splitlines():
  try:events.append(json.loads(line))
  except json.JSONDecodeError:pass
 commands=[e['item'] for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='command_execution']
 outputs=[c.get('aggregated_output','') for c in commands]
 project=Path(result['project'])
 for name,relative in [('analysis_full_read','.agents/skills/artifact-spec-analysis/SKILL.md'),('increment_full_read','.agents/skills/task-increment/SKILL.md'),('native_tasks_full_read','.agents/skills/speckit-tasks/SKILL.md')]:
  needle=(project/relative).read_text().strip()
  result[name]=[c.get('id') for c in commands if needle in c.get('aggregated_output','')]
 candidates=[project/FEATURE/'mvu.md',ROOT/'before-project'/FEATURE/'mvu.md',*(ROOT/'snapshots').glob('*/specs/skills/001-workflow/mvu.md')]
 result['mvu_full_read']=any(p.read_text().strip() in out for p in candidates if p.is_file() for out in outputs)
 result['mandatory_hook_emitted']=any('EXECUTE_COMMAND:' in e.get('item',{}).get('text','') for e in events)
 result['failed_commands']=[{'id':c.get('id'),'exit':c.get('exit_code'),'output_tail':c.get('aggregated_output','')[-1800:]} for c in commands if c.get('exit_code')]
 result['messages']=[e['item'].get('text','') for e in events if e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message']
 return result

if __name__=='__main__':
 stages={p.parent.name:audit_stage(p.parent.name) for p in sorted((ROOT/'host').glob('*/result.json'))}
 baseline=ROOT/'before-project'
 original_marks=sorted(task_marks(baseline/FEATURE/'tasks.md'))
 projects={}
 for name in ['flow','failure']:
  project=ROOT/'cases'/name
  if not project.exists():continue
  assert sorted(task_marks(project/FEATURE/'tasks.md'))==original_marks,(name,'identity/marks changed')
  protected=['business.py','.specify/memory/constitution.md',str(FEATURE/'evidence.md'),str(FEATURE/'implementation/T002.md')]
  for rel in protected:assert digest(project/rel)==digest(baseline/rel),(name,rel)
  for old in (baseline/'inputs').rglob('*'):
   if old.is_file():assert digest(old)==digest(project/old.relative_to(baseline)),str(old)
  for old in (baseline/FEATURE/'requirements').rglob('*'):
   if old.is_file() and old.name!='README.md':assert digest(old)==digest(project/old.relative_to(baseline)),str(old)
  analysis=sorted((project/FEATURE/'analysis/spec-analysis').glob('*.md'))
  assert {p.name for p in analysis}=={'README.md','flows.md'},name
  count=check_links(analysis+[project/FEATURE/'diagrams.md'])
  formal=REPO/'packages/skills/src/workflow/artifact-spec-analysis/SKILL.md'
  for path in [project/'.agents/skills/artifact-spec-analysis/SKILL.md',project/'.specify/extensions/artifact-spec-analysis/skills/artifact-spec-analysis/SKILL.md']:
   assert digest(path)==digest(formal),str(path)
  projects[name]={'links':count,'snapshot':snapshot(project),'protected':protected,'marks':original_marks}
 report={'stages':stages,'projects':projects,'formal_proof':json.loads((ROOT/'installations/formal-proof.json').read_text()),'delta_proof':json.loads((ROOT/'delta-proof.json').read_text()) if (ROOT/'delta-proof.json').exists() else None,'limits':['仅Linux隔离宿主，非真实工作区挂载','无build/dist消费','未渲染图示或取得真实用户阅读反馈']}
 (ROOT/'audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'stages':{k:{x:v.get(x) for x in ['exit','timeout','elapsed_seconds','changed','analysis_full_read','increment_full_read','native_tasks_full_read','mvu_full_read','mandatory_hook_emitted']} for k,v in stages.items()},'project_links':{k:v['links'] for k,v in projects.items()}},ensure_ascii=False,indent=2))

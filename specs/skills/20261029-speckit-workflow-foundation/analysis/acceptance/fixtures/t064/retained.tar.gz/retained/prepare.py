"""复制已验证项目并由官方 CLI 刷新正式维护源，只写本 Task 临时现场。"""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import yaml

ROOT = Path(__file__).resolve().parent
REPO = Path('<source-workspace>')
OLD = Path('/tmp/foundry-t063-20261111-_uj29ljp/cases/flow')
PROJECT = ROOT / 'cases/flow'
FEATURE = Path('specs/skills/001-workflow')
SPECIFY = Path('<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/specify')
SKILLS = next(Path('/tmp/foundry-t104-20261111/npm-cache/_npx').glob('*/node_modules/skills/bin/cli.mjs'))
SOURCE = REPO / 'packages/skills/src/workflow/artifact-spec-analysis'
CONFIG = REPO / 'packages/skills/src/workflow/collection.config.json'
LOGS = ROOT / 'installations'
LOGS.mkdir()
shutil.copytree(OLD, PROJECT, ignore=shutil.ignore_patterns('.git', '__pycache__', 'spec-analysis'))
subprocess.run(['git', 'init', '--quiet'], cwd=PROJECT, check=True)
ENV = {**os.environ, 'XDG_STATE_HOME': str(ROOT / 'official-state'), 'DO_NOT_TRACK': '1', 'DISABLE_TELEMETRY': '1', 'NO_COLOR': '1', 'CI': '1', 'PYTHONDONTWRITEBYTECODE': '1'}

def hashes(path):
    return {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}

def run(args, name):
    result = subprocess.run(args, cwd=PROJECT, env=ENV, capture_output=True, text=True, timeout=60)
    (LOGS / name).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, (args, result.returncode, result.stderr[-1600:])
    return result.stdout.strip()

native = PROJECT / '.agents/skills/speckit-tasks'
native_before = hashes(native)
versions = {'specify': run([str(SPECIFY), '--version'], 'specify-version.log'), 'skills': run(['node', str(SKILLS), '--version'], 'skills-version.log'), 'codex': run(['codex', '--version'], 'codex-version.log')}
assert versions['specify'] == 'specify 1.2.6' and versions['skills'] == '1.7.4'
commands = []
for name in ['artifact-spec-analysis', 'task-increment']:
    source = REPO / 'packages/skills/src/workflow' / name
    args = ['node', str(SKILLS), 'add', str(source), '--skill', name, '--agent', 'codex', '--copy', '--yes']
    run(args, name + '-add.log')
    assert hashes(source) == hashes(PROJECT / '.agents/skills' / name)
    commands.append(args)
config = json.loads(CONFIG.read_text())
settings = config['skill']['artifact-spec-analysis']['hook']
assert set(settings) == {'after_tasks'}
metadata = yaml.safe_load((SOURCE / 'SKILL.md').read_text().split('---', 2)[1])
hook = {event: [{'command': metadata['name'].replace('-', '.'), 'description': metadata['description'], **options}] for event, options in settings.items()}
extension = ROOT / 'extension-input/artifact-spec-analysis'
(extension / 'skills').mkdir(parents=True)
shutil.copytree(PROJECT / '.agents/skills/artifact-spec-analysis', extension / 'skills/artifact-spec-analysis')
manifest = {'schema_version': '1.0', 'extension': {'id': metadata['name'], 'name': 'Spec Analysis Formal Source', 'version': '0.1.0', 'description': 'T064正式来源完整生命周期验证；非构建产物或正式安装器接线'}, 'requires': {'speckit_version': '==1.2.6'}, 'provides': {}, 'hooks': hook}
(extension / 'extension.yml').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
shutil.copy2(CONFIG, ROOT / 'collection.config.json')
register = [str(SPECIFY), 'extension', 'add', '--dev', str(extension), '--force']
run(register, 'extension-add.log')
commands.append(register)
actual = yaml.safe_load((PROJECT / '.specify/extensions.yml').read_text())
assert list(actual['hooks']) == ['after_tasks']
registered = actual['hooks']['after_tasks']
assert len(registered) == 1
for key, value in settings['after_tasks'].items():
    assert registered[0][key] == value, (key, registered[0])
installed = PROJECT / '.agents/skills/artifact-spec-analysis'
extension_copy = PROJECT / '.specify/extensions/artifact-spec-analysis/skills/artifact-spec-analysis'
assert hashes(SOURCE) == hashes(installed) == hashes(extension_copy)
assert native_before == hashes(native)
proof = {'versions': versions, 'source_kind': '正式维护源官方安装；非构建产物/正式安装器接线', 'source': str(SOURCE), 'source_files': hashes(SOURCE), 'installed_files': hashes(installed), 'extension_files': hashes(extension_copy), 'collection_source': str(CONFIG), 'collection_sha256': hashlib.sha256(CONFIG.read_bytes()).hexdigest(), 'declared_hook': settings, 'registered_hook': registered, 'native_before': native_before, 'native_after': hashes(native), 'commands': commands, 'build_validated': False}
(LOGS / 'formal-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
agents = PROJECT / 'AGENTS.md'
agents.write_text("""# T064 隔离验证工程约定

这是T064自有隔离项目，Task、业务哨兵及旧证据为构造夹具，历史输入逐字引用真实已保存来源，不是本轮新用户确认或真实业务验收。本轮只允许资料规划、tasks生成及分析，不研发或测试暂停模式，不实施业务，不安装依赖、发布、部署、挂载或改外部文件。不得修改business.py、治理、inputs、旧implementation方案、原Task完成事实和evidence。不得使用子代理。

Markdown遵循UTF-8、末尾换行、无尾空格；每份写后用标准库检查并全文读回，检查本地链接。不安装格式器。分析入口与已有分文档采用analysis/spec-analysis/README.md、flows.md；技术图沿diagrams.md导航，不复制工程checkbox或MVU活动定义。没有实质变化保持文件字节稳定。

原生tasks可在当前有效范围完整生成/完善清单，保留T001～T009所有已存在身份、原目标/验收、完成事实与暂停历史，只有真正缺口才使用未占用ID；mvu补真实职责，不能生成implementation认可方案。Increment可在Spec范围同步requirements、spec、plan、mvu、tasks及同一分析，不能改变治理或业务。

保存过程按逐份检查/读回进行，不宣称跨文件原子回滚。若遇到不可写文件、目标路径为受保护目录或能力缺失，只报告实际已写/未写、影响及续接条件；不得chmod、移动、替换保护对象，不改写替代分析路径或删除既有材料绕过故障。故障由验证方解除后从实际磁盘续接。
""")
shutil.copytree(PROJECT, ROOT / 'before-project', ignore=shutil.ignore_patterns('.git', '__pycache__'))
print(json.dumps({'versions': versions, 'formal_files': hashes(SOURCE), 'collection_hook_registered': True, 'native_preserved': True, 'initial_analysis_absent': not (PROJECT/FEATURE/'analysis/spec-analysis').exists()}, ensure_ascii=False, indent=2))

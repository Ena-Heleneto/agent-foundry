"""T064 正式来源实际宿主回合；保留原始输入、事件、文件变化和真实超时。"""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FEATURE = 'specs/skills/001-workflow'
PROMPTS = {
 'create': ('flow', '$speckit-tasks specs/skills/001-workflow。T064隔离验证：从原生入口完整执行任务生成，再执行其实际after_tasks；读取本项目当前有效spec/plan及同级mvu。原T001～T009已有身份、原验收和完成事实保留，暂停任务不扩展；按真实现状复用或完善轻量任务，补mvu职责。本轮只生成资料，不实施业务，不生成认可方案。分析入口原本不存在，沿本项目工程约定完成创建和核查，图示不渲染。'),
 'change': ('flow', '$task-increment Spec:specs/skills/001-workflow。T064历史需求回放验证：请消费requirements/raw/2026-11-10-discussion-history.md和已同步spec/需求摘要，按新明确的Increment不接受Task参数、可选描述、轻量Task与一Task一方案职责同步规划，保留原任务身份、验收、完成事实和暂停边界，之后按本技能实际后续步骤完成分析刷新。本次历史输入不是新用户确认，不实施业务。'),
 'repeat': ('flow', '$task-increment Spec:specs/skills/001-workflow。T064无变化重复验证：无新需求、无新证据，请依据磁盘复核原已保存规划与分析，只补确实遗漏项。没有实质变化保持字节稳定，不为记录检查过而写入时间戳、附录、状态或重复Task/MVU，不实施业务。'),
 'failure': ('failure', '$task-increment Spec:specs/skills/001-workflow。T064受控保存故障验证：消费已保存的历史需求及新明确的Increment输入/轻量Task分工，按实际磁盘更新必要规划，随后完成同一分析刷新。遵守项目逐份保存及保护对象规则；只报告实际结果，不修改保护路径、不绕过失败或实施业务。'),
 'recover': ('failure', '验证方已解除先前记录的保存障碍。沿真实同一会话，从实际磁盘、原输入和已经保存的规划恢复，只补原分析未完成写入、格式/引用检查和完整读回；不重复创建任务/MVU、不改已完成事实、不实施业务。'),
}
PREVIOUS = {'create-finish': 'create', 'change-finish': 'change', 'repeat-finish': 'repeat', 'failure-finish': 'failure', 'recover': 'failure', 'create-ready': 'create', 'recover-finish': 'recover'}
for current,previous in list(PREVIOUS.items()):
 if current not in PROMPTS:
  PROMPTS[current] = (PROMPTS[previous][0], '上轮到宿主时限。沿真实同一会话和实际磁盘，仅补本轮原范围剩余保存、核查和回执，保留故障与未完成事实，不重做已完成步骤、不扩大授权。')



def snapshot(project):
    return {
        str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(project.rglob('*'))
        if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts
    }

def run(stage):
    name, prompt = PROMPTS[stage]
    project = ROOT / 'cases' / name
    out = ROOT / 'host' / stage
    if out.exists():
        out.rename(ROOT / 'host' / (stage + '-environment-first'))
    out.mkdir(parents=True, exist_ok=False)
    args = ['codex', 'exec', '--cd', str(project), '--sandbox', 'workspace-write']
    previous = PREVIOUS.get(stage)
    if previous:
        prior = json.loads((ROOT / 'host' / previous / 'result.json').read_text())
        assert prior['session_id'] and (prior['timeout'] or stage in {'recover', 'create-ready'}), prior
        args += ['resume', '--json', '--output-last-message', str(out / 'final.txt'), prior['session_id'], '-']
    else:
        args += ['--json', '--color', 'never', '--output-last-message', str(out / 'final.txt'), '-']
    (out / 'input.txt').write_text(prompt + '\n')
    before = snapshot(project)
    (out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
    start = time.monotonic()
    env = {**os.environ, 'SPECIFY_FEATURE_DIRECTORY': FEATURE, 'PATH': '<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin:' + os.environ['PATH']}
    with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(args, cwd=project, env=env, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, text=True, start_new_session=True)
        timeout = False
        try:
            process.communicate(prompt + '\n', timeout=360)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    session = None
    for line in (out / 'events.jsonl').read_text().splitlines():
        try:
            event = json.loads(line)
            if event.get('type') == 'thread.started':
                session = event['thread_id']
        except json.JSONDecodeError:
            pass
    after = snapshot(project)
    (out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    result = {'stage': stage, 'project': str(project), 'exit': process.returncode, 'timeout': timeout, 'elapsed_seconds': round(time.monotonic() - start, 3), 'session_id': session, 'args': args, 'changed': [k for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)], 'model_override': False}
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    if (out / 'final.txt').exists():
        print((out / 'final.txt').read_text()[:3500], flush=True)
    if process.returncode:
        print((out / 'stderr.log').read_text()[-1400:], flush=True)
    return process.returncode == 0 and not timeout

if __name__ == '__main__':
    raise SystemExit(0 if run(sys.argv[1]) else 1)

"""只在T064独占夹具回放真实历史要求，不写父Spec或制造新确认。"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parent
REPO = Path('<source-workspace>')
FEATURE = Path('specs/skills/001-workflow')
FLOW = ROOT / 'cases/flow'
FAILURE = ROOT / 'cases/failure'
assert (FLOW / FEATURE / 'analysis/spec-analysis/README.md').is_file(), '先完成真实创建'
assert (FLOW / FEATURE / 'analysis/spec-analysis/flows.md').is_file(), '两份输出是本场景实际前置'
shutil.copytree(FLOW, ROOT / 'snapshots/created', ignore=shutil.ignore_patterns('.git', '__pycache__'))
shutil.copytree(FLOW, FAILURE, ignore=shutil.ignore_patterns('.git', '__pycache__'))
source = REPO / 'specs/skills/20261029-speckit-workflow-foundation/requirements/raw/2026-11-10-implementation-discussion-revision.md'
raw = source.read_text()
for project in [FLOW, FAILURE]:
 feature = project / FEATURE
 target = feature / 'requirements/raw/2026-11-10-discussion-history.md'
 target.write_text('# 历史实施讨论反馈回放\n\n原表达日期：2026-11-10。回放日期：2026-11-11。原文来自本仓库已保存输入，以下逐字引用；不是本轮新增需求或新的用户确认。本次只核验其中Increment无Task参数、轻量Task和单Task方案职责，其余按现行Spec边界理解。\n\n```text\n' + raw.rstrip('\n') + '\n```\n')
 requirement = '\n## 本次同步的历史要求\n\n本次T064隔离回放根据[2026-11-10真实历史输入](requirements/raw/2026-11-10-discussion-history.md)，明确Increment只定位Spec并接受可选业务规划描述，不接受Task定位参数；描述引用原Task仍可作为现状或职责关联。规划先形成可观察的小业务闭环，再映射轻量Task，不预先填满实施步骤；详细实现思路在原Task开工前讨论认可并保存到implementation/<Task ID>.md，由原任务链接，唯一工程checkbox仍在tasks。上述补充不改变原Task身份、原验收、完成事实、三模式暂停或业务实施授权，原T002方案仍未认可。此为已保存有效需求的历史回放，不是父用户本轮新批准。\n'
 with (feature / 'spec.md').open('a') as f: f.write(requirement)
 with (feature / 'requirements/README.md').open('a') as f: f.write('\n## T064历史补充输入\n\n2026-11-11回放2026-11-10[真实反馈原文](raw/2026-11-10-discussion-history.md)：原问题是Task过长、提前固定文件导致难以审阅和实现偏离；方向是Increment取消Task参数、接受可选描述，先小业务闭环再轻量任务，详细方案开工前讨论。当前[有效规格](../spec.md#本次同步的历史要求)已同步本场景验证的这项明确职责；其他议题沿原有效范围，不把历史回放当新的真实确认。旧原文、AI未确认提案和T002未认可事实保持。\n')
# 保护对象由验证方设置，保留原文件，不让被测宿主自行解除。
protected = FAILURE / FEATURE / 'analysis/spec-analysis/flows.md'
(ROOT / 'failure-original').mkdir()
shutil.copy2(protected, ROOT / 'failure-original/flows.md')
protected.chmod(0o444)
# 只给测试副本细化原有逐份保存约定，不改生产技能。
with (FAILURE / 'AGENTS.md').open('a') as f:
 f.write('\n本例分析文件逐份保存，先写README.md并完成格式检查及全文读回，再处理flows.md；遇到保护对象不得重排保存到替代路径。预检可以报告障碍，但未尝试或未写入的部分不得称已保存。\n')
proof = {'original_source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'replay_date':'2026-11-11','expression_date':'2026-11-10','not_new_user_confirmation':True,'blocked_target':str(protected),'original_backup':str(ROOT/'failure-original/flows.md'),'method':'夹具flows.md只读0444，正文可读、真实保存拒绝；不修改真实工作区权限'}
(ROOT/'delta-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
for name in ['flow','failure']:
 shutil.copytree(ROOT/'cases'/name, ROOT/'snapshots'/('before-'+name+'-delta'), ignore=shutil.ignore_patterns('.git', '__pycache__'))
print(json.dumps(proof,ensure_ascii=False))

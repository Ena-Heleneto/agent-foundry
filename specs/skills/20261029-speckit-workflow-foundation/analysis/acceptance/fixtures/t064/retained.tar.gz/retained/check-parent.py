"""只核对T064本轮新增引用和允许的父资料差异，不改其他功能。"""
from pathlib import Path
import json,re,hashlib,unicodedata
from urllib.parse import unquote
ROOT=Path('<source-workspace>')
TEMP=Path(__file__).resolve().parent
BASE=ROOT/'specs/skills/20261029-speckit-workflow-foundation'
def slug(s):
 s=re.sub(r'\[([^]]+)\]\([^)]*\)',r'\1',s).replace('`','').strip().lower()
 return ''.join(c for c in s if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LN').replace(' ','-')
files=[BASE/'implementation/T064.md',*(BASE/'analysis/spec-analysis').glob('*.md'),BASE/'analysis/acceptance/t064-analysis-lifecycle.md',BASE/'analysis/acceptance/fixtures/t064/README.md']
count=0
for p in files:
 for v in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' in v:continue
  f,_,anchor=v.partition('#'); target=(p.parent/unquote(f)).resolve() if f else p
  assert target.is_file(),(str(p),v)
  if anchor:
   s=target.read_text(); anchors={slug(h) for h in re.findall(r'^#{1,6}\s+(.+)$',s,re.M)}|set(re.findall(r'<a\s+id="([^"]+)"',s)); assert unquote(anchor) in anchors,(str(p),v)
  count+=1
before=TEMP/'parent-before/specs/skills/20261029-speckit-workflow-foundation'
a=(before/'tasks.md').read_text();b=(BASE/'tasks.md').read_text()
marks=r'^- \[([ xX])\] (T\d+)\b'; aa=re.findall(marks,a,re.M);bb=re.findall(marks,b,re.M)
assert [t for c,t in aa]==[t for c,t in bb]
changes=[{'id':ta,'before':ca,'after':cb} for (ca,ta),(cb,tb) in zip(aa,bb) if ca!=cb];assert all(x['id']=='T064' and x['before']==' ' and x['after']=='x' for x in changes)
assert a.split('## 三模式暂停记录',1)[1]==b.split('## 三模式暂停记录',1)[1]
for filename in ['spec.md']:
 old=(before/filename).read_text();new=(BASE/filename).read_text();pattern=r'^- \*\*(?:FR|SC)-\d+\*\*.*$';assert re.findall(pattern,old,re.M)==re.findall(pattern,new,re.M)
for rel,sha in json.loads((TEMP/'parent-before.json').read_text()).items():
 if rel.startswith('packages/') or rel.startswith('.specify/') or rel.endswith('/plan.md'):
  assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==sha,rel
for p in (BASE/'analysis/spec-analysis').glob('*.md'):
 assert not re.search(r'^\s*- \[[ xX]\]|^\*\*(?:状态|闭环结果|节点与关键逻辑|关联 Task|验收信号)\*\*',p.read_text(),re.M),str(p)
result={'new_document_links_and_anchors':count,'all_107_task_ids_and_order_preserved':True,'checkbox_changes':changes,'paused_and_historical_sections_preserved':True,'FR_SC_definitions_preserved':True,'formal_sources_config_constitution_feature_pointer_plan_preserved':True,'analysis_has_no_second_checkbox_or_activity_definition':True}
(TEMP/'parent-final-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

---
name: task-increment
description: T066 旧登记样本
---

# 旧 increment 入口
仅验证迁移，不执行业务。

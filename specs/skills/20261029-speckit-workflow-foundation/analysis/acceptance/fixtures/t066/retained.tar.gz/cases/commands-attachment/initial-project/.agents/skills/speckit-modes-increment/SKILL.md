---
name: speckit-modes-increment
description: T066 旧登记样本
compatibility: Requires spec-kit project structure with .specify/ directory
metadata:
  author: github-spec-kit
  source: modes:skills/task-increment/SKILL.md
---

# 旧 increment 入口
仅验证迁移，不执行业务。
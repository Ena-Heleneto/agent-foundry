---
name: task-direct
description: T066 旧登记样本
---

# 旧 direct 入口
仅验证迁移，不执行业务。

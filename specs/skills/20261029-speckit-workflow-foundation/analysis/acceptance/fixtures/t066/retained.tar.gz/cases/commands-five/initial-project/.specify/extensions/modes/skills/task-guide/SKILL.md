---
name: task-guide
description: T066 旧登记样本
---

# 旧 guide 入口
仅验证迁移，不执行业务。

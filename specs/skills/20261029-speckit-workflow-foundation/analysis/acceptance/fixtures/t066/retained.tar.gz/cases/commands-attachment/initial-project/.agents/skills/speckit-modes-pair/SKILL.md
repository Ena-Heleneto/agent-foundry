---
name: speckit-modes-pair
description: T066 旧登记样本
compatibility: Requires spec-kit project structure with .specify/ directory
metadata:
  author: github-spec-kit
  source: modes:skills/task-pair/SKILL.md
---

# 旧 pair 入口
仅验证迁移，不执行业务。
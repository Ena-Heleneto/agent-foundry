---
name: speckit-modes-direct
description: T066 旧登记样本
compatibility: Requires spec-kit project structure with .specify/ directory
metadata:
  author: github-spec-kit
  source: modes:skills/task-direct/SKILL.md
---

# 旧 direct 入口
仅验证迁移，不执行业务。
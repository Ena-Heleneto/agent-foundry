---
name: task-explore
description: T066 旧登记样本
---

# 旧 explore 入口
仅验证迁移，不执行业务。

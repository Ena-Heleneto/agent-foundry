---
name: speckit-modes-review
description: T066 旧登记样本
compatibility: Requires spec-kit project structure with .specify/ directory
metadata:
  author: github-spec-kit
  source: modes:skills/task-review/SKILL.md
---

# 旧 review 入口
仅验证迁移，不执行业务。
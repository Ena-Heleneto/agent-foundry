# 工作流图示导航

当前 Spec 的[功能分析流程图](analysis/spec-analysis/flows.md)解释业务判断、计划调用与闭环里程碑。[技术职责与调用关系](analysis/spec-analysis/flows.md#技术职责与调用关系)为唯一技术图来源，本文件只作导航。

技术图依据 [plan.md](plan.md) 与 [mvu.md](mvu.md)，标明准备 skill、Implement 模板的计划位置及其在当前副本中缺失的事实，不代表已实现或通过验证。全部 Mermaid 仅保存源码，未执行渲染。

"""独立核对真实工具输出、文件保护及分析引用，不把文字命中代业务验收。"""
from pathlib import Path
import hashlib
import json
import re
import unicodedata

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / 'cases/flow'
FEATURE = Path('specs/skills/001-workflow')
CANDIDATE = PROJECT / '.agents/skills/artifact-spec-analysis/SKILL.md'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def events(stage):
    result = []
    for line in (ROOT / 'host' / stage / 'events.jsonl').read_text().splitlines():
        try:
            result.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    return result

def slug(text):
    text = re.sub(r'\[([^]]+)\]\([^)]+\)', r'\1', text)
    text = text.replace('`', '').strip().lower()
    return ''.join(c for c in text if c.isspace() or c in '-_' or unicodedata.category(c)[0] in 'LN').replace(' ', '-')

def links(paths):
    count = 0
    for path in paths:
        text = path.read_text()
        assert text.endswith('\n') and not any(line.rstrip() != line for line in text.splitlines()), path
        for value in re.findall(r'\]\(([^)]+)\)', text):
            if '://' in value or value.startswith('mailto:'):
                continue
            file, _, anchor = value.partition('#')
            target = (path.parent / file).resolve() if file else path
            assert target.exists(), (str(path), value, str(target))
            if anchor:
                headings = re.findall(r'^#{1,6}\s+(.+)$', target.read_text(), re.M)
                anchors = {slug(heading) for heading in headings}
                assert anchor in anchors, (str(path), value, sorted(anchors))
            count += 1
    return count

stages = {}
for stage in ('baseline', 'create', 'create-finish', 'refresh', 'refresh-finish', 'repeat'):
    path = ROOT / 'host' / stage / 'result.json'
    if not path.exists():
        continue
    result = json.loads(path.read_text())
    es = events(stage)
    commands = [e['item'] for e in es if e.get('type') == 'item.completed' and e.get('item', {}).get('type') == 'command_execution']
    messages = [e['item'].get('text', '') for e in es if e.get('type') == 'item.completed' and e.get('item', {}).get('type') == 'agent_message']
    outputs = [c.get('aggregated_output', '') for c in commands]
    result['candidate_full_read_command_ids'] = [c.get('id') for c in commands if CANDIDATE.read_text().strip() in c.get('aggregated_output', '')]
    result['mvu_before_or_after_full_read'] = any((ROOT / 'before/projects/flow' / FEATURE / 'mvu.md').read_text().strip() in output or (PROJECT / FEATURE / 'mvu.md').read_text().strip() in output for output in outputs)
    result['native_tasks_full_read'] = any((PROJECT / '.agents/skills/speckit-tasks/SKILL.md').read_text().strip() in output for output in outputs)
    result['increment_full_read'] = any((PROJECT / '.agents/skills/task-increment/SKILL.md').read_text().strip() in output for output in outputs)
    result['mandatory_hook_emitted'] = any('EXECUTE_COMMAND:' in message for message in messages)
    result['completed_commands'] = len(commands)
    result['failed_commands'] = [{'id': c.get('id'), 'exit': c.get('exit_code'), 'output_tail': c.get('aggregated_output', '')[-600:]} for c in commands if c.get('exit_code')]
    stages[stage] = result

protected = ['business.py', '.specify/memory/constitution.md', str(FEATURE / 'evidence.md'), str(FEATURE / 'implementation/T002.md'), str(FEATURE / 'spec.md')]
for rel in protected:
    assert digest(PROJECT / rel) == digest(ROOT / 'before/projects/flow' / rel), rel
for p in (ROOT / 'before/projects/flow' / 'inputs').rglob('*'):
    if p.is_file():
        assert digest(p) == digest(PROJECT / p.relative_to(ROOT / 'before/projects/flow'))
for p in (ROOT / 'before/projects/flow' / FEATURE / 'requirements').rglob('*'):
    if p.is_file():
        assert digest(p) == digest(PROJECT / p.relative_to(ROOT / 'before/projects/flow'))
task_pattern = r'^- \[([ xX])\] (T\d+)\s+(.+)$'
before_tasks = re.findall(task_pattern, (ROOT / 'before/projects/flow' / FEATURE / 'tasks.md').read_text(), re.M)
after_tasks = re.findall(task_pattern, (PROJECT / FEATURE / 'tasks.md').read_text(), re.M)
assert sorted(before_tasks) == sorted(after_tasks), (before_tasks, after_tasks)
analysis = PROJECT / FEATURE / 'analysis/spec-analysis'
paths = sorted(analysis.rglob('*.md')) + [PROJECT / FEATURE / 'diagrams.md']
link_count = links(paths)
assert all(not re.search(r'^\s*- \[[ xX]\]', path.read_text(), re.M) for path in paths)
environment = [json.loads(path.read_text()) for path in sorted((ROOT / 'host').glob('*environment-first/result.json'))]
repeat = stages.get('repeat')
if repeat:
    assert repeat['changed'] == [] and repeat['exit'] == 0 and not repeat['timeout']
    assert json.loads((ROOT / 'host/repeat/before.json').read_text()) == json.loads((ROOT / 'host/repeat/after.json').read_text())
for prefix in ('create', 'refresh'):
    finish = stages.get(prefix + '-finish')
    if finish:
        assert finish['exit'] == 0 and not finish['timeout'] and finish['changed'] == []
        assert finish['session_id'] == stages[prefix]['session_id']
report = {'stages': stages, 'environment_failures': environment, 'protected_files': protected, 'inputs_requirements_unchanged': True, 'task_identity_checkbox_and_original_first_line_preserved': True, 'analysis_file_links_and_anchors': link_count, 'analysis_files': {str(path.relative_to(PROJECT)): digest(path) for path in paths}, 'candidate_sha256': digest(CANDIDATE), 'repeat_all_files_unchanged': bool(repeat), 'business_acceptance': '未执行；分析只提供阅读与候选消费证据'}
(ROOT / 'host-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'stages': {name: {key: result.get(key) for key in ['exit', 'timeout', 'elapsed_seconds', 'candidate_full_read_command_ids', 'native_tasks_full_read', 'increment_full_read', 'mvu_before_or_after_full_read', 'mandatory_hook_emitted']} for name, result in stages.items()}, 'links': link_count, 'protected': True}, ensure_ascii=False, indent=2))

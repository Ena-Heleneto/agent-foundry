"""通过已缓存官方 CLI 安装候选及临时 after_tasks，不改真实工作区。"""
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import yaml

ROOT = Path(__file__).resolve().parent
REPO = Path('<source-workspace>')
SOURCE = REPO / 'specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/t062/candidate/artifact-spec-analysis'
PROJECT = ROOT / 'cases/flow'
SPECIFY = Path('<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/specify')
SKILLS = next(Path('/tmp/foundry-t104-20261111/npm-cache/_npx').glob('*/node_modules/skills/bin/cli.mjs'))
LOGS = ROOT / 'installations/flow'
ENV = {**os.environ, 'XDG_STATE_HOME': str(ROOT / 'official-state/flow'), 'DO_NOT_TRACK': '1', 'DISABLE_TELEMETRY': '1', 'NO_COLOR': '1', 'CI': '1', 'PYTHONDONTWRITEBYTECODE': '1'}

def hashes(path):
    return {str(p.relative_to(path)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*')) if p.is_file()}

def run(args, name):
    result = subprocess.run(args, cwd=PROJECT, env=ENV, capture_output=True, text=True, timeout=60)
    (LOGS / name).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, (args, result.returncode, result.stderr[-2000:])
    return result.stdout.strip()

versions = {'specify': run([str(SPECIFY), '--version'], 'specify-version.log'), 'skills': run(['node', str(SKILLS), '--version'], 'skills-version.log'), 'codex': run(['codex', '--version'], 'codex-version.log')}
assert versions['specify'] == 'specify 1.2.6' and versions['skills'] == '1.7.4', versions
native = PROJECT / '.agents/skills/speckit-tasks'
before = hashes(native)
add = ['node', str(SKILLS), 'add', str(SOURCE), '--skill', 'artifact-spec-analysis', '--agent', 'codex', '--copy', '--yes']
run(add, 'candidate-add.log')
installed = PROJECT / '.agents/skills/artifact-spec-analysis'
assert hashes(SOURCE) == hashes(installed)
extension = ROOT / 'extension-input/artifact-spec-analysis'
(extension / 'skills').mkdir(parents=True)
shutil.copytree(installed, extension / 'skills/artifact-spec-analysis')
hook = {'after_tasks': [{'command': 'artifact.spec.analysis', 'description': '创建所属 Spec 的综合分析', 'prompt': '以当前任务生成操作的目标 Spec 为准，完整读取 artifact-spec-analysis 并传入所属 Spec 最新需求、方案、同级闭环、任务及必要证据，沿目标项目已有格式要求保存和读回。', 'optional': False, 'enabled': True, 'condition': None, 'priority': 20}]}
manifest = {'schema_version': '1.0', 'extension': {'id': 'artifact-spec-analysis', 'name': 'Spec Analysis Candidate', 'version': '0.1.0', 'description': 'T062隔离候选，非正式交付'}, 'requires': {'speckit_version': '==1.2.6'}, 'provides': {}, 'hooks': hook}
(extension / 'extension.yml').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
register = [str(SPECIFY), 'extension', 'add', '--dev', str(extension), '--force']
run(register, 'extension-add.log')
actual = yaml.safe_load((PROJECT / '.specify/extensions.yml').read_text())
assert list(actual['hooks']) == ['after_tasks'], actual
registered = actual['hooks']['after_tasks']
assert len(registered) == 1 and registered[0]['optional'] is False and registered[0]['condition'] is None and registered[0]['enabled'] is True, registered
extension_copy = PROJECT / '.specify/extensions/artifact-spec-analysis/skills/artifact-spec-analysis'
assert hashes(SOURCE) == hashes(installed) == hashes(extension_copy)
assert before == hashes(native)
proof = {'versions': versions, 'source_kind': '隔离候选；非正式维护源或构建产物', 'source': str(SOURCE), 'source_files': hashes(SOURCE), 'installed_files': hashes(installed), 'extension_files': hashes(extension_copy), 'native_before': before, 'native_after': hashes(native), 'registered_hook': registered, 'commands': [add, register], 'build_validated': False}
(LOGS / 'candidate-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(proof, ensure_ascii=False, indent=2))

"""T062 实际宿主回合；保留原始输入、事件、文件变化和真实超时。"""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FEATURE = 'specs/skills/001-workflow'
PROMPTS = {
    'baseline': ('baseline', '$task-increment Spec:specs/skills/001-workflow。当前规划已保存，本轮没有新需求或规划变化，沿实际材料完成本次规划核查和后续步骤，简洁报告结果，不实施业务。'),
    'create': ('flow', '$speckit-tasks specs/skills/001-workflow。隔离测试已完成任务生成阶段并保存当前tasks.md，本轮从该原生入口的Mandatory Post-Execution Hooks阶段续接，完成该阶段真实动作及结果报告，不重新生成任务，不修改输入规划或工程完成标记。'),
    'refresh': ('flow', '$task-increment Spec:specs/skills/001-workflow。以下是隔离验证指令，不是父项目用户新需求或业务认可：为尽早取得Implement准备反馈，在原有范围内把T007契约验证及T002准备核对排到T006规划细化之前；独立资料工作仍可继续，T008必要依赖、原身份/原验收、三模式暂停与T009末尾收尾保持。仅调整该Spec的必要规划并完成本次后续步骤，不实施业务。'),
    'repeat': ('flow', '$task-increment Spec:specs/skills/001-workflow   '),
    'create-finish': ('flow', '上轮在宿主限时结束。沿同一会话和已保存文件继续原后置分析范围，只补必要保存、格式/引用核查和实际结果报告，不重做任务生成或改写规划，不扩大授权。'),
    'refresh-finish': ('flow', '上轮在宿主限时结束。沿同一会话和实际文件补完本轮原范围的规划/分析核查、必要保存与回执，不重建任务或覆盖原证据，不实施业务。'),
}

def snapshot(project):
    return {
        str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(project.rglob('*'))
        if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts
    }

def run(stage):
    name, prompt = PROMPTS[stage]
    project = ROOT / 'cases' / name
    out = ROOT / 'host' / stage
    if out.exists():
        out.rename(ROOT / 'host' / (stage + '-environment-first'))
    out.mkdir(parents=True, exist_ok=False)
    args = ['codex', 'exec', '--cd', str(project), '--sandbox', 'workspace-write']
    previous = {'create-finish': 'create', 'refresh-finish': 'refresh'}.get(stage)
    if previous:
        prior = json.loads((ROOT / 'host' / previous / 'result.json').read_text())
        assert prior['session_id'] and prior['timeout'], prior
        args += ['resume', '--json', '--output-last-message', str(out / 'final.txt'), prior['session_id'], '-']
    else:
        args += ['--json', '--color', 'never', '--output-last-message', str(out / 'final.txt'), '-']
    (out / 'input.txt').write_text(prompt + '\n')
    before = snapshot(project)
    (out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
    start = time.monotonic()
    env = {**os.environ, 'SPECIFY_FEATURE_DIRECTORY': FEATURE}
    with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(args, cwd=project, env=env, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, text=True, start_new_session=True)
        timeout = False
        try:
            process.communicate(prompt + '\n', timeout=240)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    session = None
    for line in (out / 'events.jsonl').read_text().splitlines():
        try:
            event = json.loads(line)
            if event.get('type') == 'thread.started':
                session = event['thread_id']
        except json.JSONDecodeError:
            pass
    after = snapshot(project)
    (out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    result = {'stage': stage, 'project': str(project), 'exit': process.returncode, 'timeout': timeout, 'elapsed_seconds': round(time.monotonic() - start, 3), 'session_id': session, 'args': args, 'changed': [k for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)], 'model_override': False}
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    if (out / 'final.txt').exists():
        print((out / 'final.txt').read_text()[:1800], flush=True)
    if process.returncode:
        print((out / 'stderr.log').read_text()[-1400:], flush=True)
    return process.returncode == 0 and not timeout

if __name__ == '__main__':
    raise SystemExit(0 if run(sys.argv[1]) else 1)

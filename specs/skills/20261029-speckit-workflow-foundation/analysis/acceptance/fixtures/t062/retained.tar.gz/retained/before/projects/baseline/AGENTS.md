# T062 隔离验证

此项目是T106真实历史回放材料的副本；任务、业务哨兵和证据为构造夹具，不是用户业务验收。原始输入/讨论保持；本轮验证指令只授权分析创建及局部规划调整，不新增真实业务认可。不得编辑business.py、治理、输入、旧方案、原Task完成标记及证据，不操作外部Spec或挂载。

Markdown采用UTF-8、末尾换行、无尾空格；写后可用Python标准库检查、本地引用核对并完整读回，不安装格式器。没有本地依赖，无需联网。分析图示无需渲染，渲染未执行如实报告。不使用子代理；本轮只做当前请求，不调用其他流程自造新的设计确认点。

生成阶段的tasks.md和mvu.md已作为输入保存，不重新生成任务。分析只写当前Spec的analysis/spec-analysis/及必要diagrams.md导航；Increment局部调整只可写当前Spec的plan.md、mvu.md、tasks.md和analysis/spec-analysis/，保留原身份、验收和历史。

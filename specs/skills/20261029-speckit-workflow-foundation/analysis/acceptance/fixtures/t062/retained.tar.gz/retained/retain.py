"""仅归档本 Task 必要输入、官方安装证明、真实事件和实际文件。"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('<source-workspace>')
DESTINATION = REPO / 'specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/t062'
STAGE = ROOT / 'retained-complete'
STAGE.mkdir(exist_ok=False)
for name in ['before', 'cases', 'snapshots', 'installations', 'extension-input', 'host']:
    shutil.copytree(ROOT / name, STAGE / name, ignore=shutil.ignore_patterns('.git', '__pycache__'))
for name in ['meta.json', 'micro.json', 'package-checks.json', 'host-audit.json', 'review.json', 'preliminary-root-checks.json', 'create-written-before-resume.json', 'refresh-written-before-resume.json', 'snapshot-completion.json', 'run.py', 'install_flow.py', 'audit.py', 'retain.py']:
    shutil.copy2(ROOT / name, STAGE / name)
shutil.copytree(DESTINATION / 'candidate', STAGE / 'candidate')
files = [path for path in sorted(STAGE.rglob('*')) if path.is_file()]
assert not any(path.name == 'profile.md' or 'user-shadow' in path.parts for path in files)
patterns = {
    'credential_token': rb'(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{25,}|sk-[A-Za-z0-9]{20,})',
    'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
    'database_uri': rb'mongodb(?:\+srv)?://[^\s<>"\x27]{12,}',
}
hits = []
for path in files:
    data = path.read_bytes()
    for category, pattern in patterns.items():
        if re.search(pattern, data):
            hits.append({'file': str(path.relative_to(STAGE)), 'category': category})
assert not hits, hits
archive = DESTINATION / 'retained-complete.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(STAGE, arcname='retained')
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert all(not member.issym() and not member.islnk() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts for member in members)
    file_count = sum(member.isfile() for member in members)
previous = DESTINATION / 'retained.tar.gz'
assert hashlib.sha256(previous.read_bytes()).hexdigest() == '2fcce6cf519a217723eeaf4ebfa7b335a6c7a3b676d6ad774c91c4b6ed165d1d'
shutil.copy2(previous, ROOT / 'retained-initial.tar.gz')
archive.replace(previous)
archive = previous
report = json.loads((ROOT / 'host-audit.json').read_text())
report['official_candidate_install'] = json.loads((ROOT / 'installations/flow/candidate-proof.json').read_text())
report['package_checks'] = json.loads((ROOT / 'package-checks.json').read_text())
report['review'] = json.loads((ROOT / 'review.json').read_text())
report['micro'] = json.loads((ROOT / 'micro.json').read_text())
report['archive'] = {'path': 'retained.tar.gz', 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'file_count': file_count, 'member_count': len(members), 'selected_secret_patterns_checked': list(patterns), 'selected_secret_patterns_hits': 0, 'scan_not_exhaustive': True, 'profile_not_in_archive': True}
report['verdict'] = 'T062原最小范围通过；首次环境失败、两次到限和一次临时核查误报均保留。T063/T064与完整交付未计通过。'
(DESTINATION / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['archive'], ensure_ascii=False, indent=2))

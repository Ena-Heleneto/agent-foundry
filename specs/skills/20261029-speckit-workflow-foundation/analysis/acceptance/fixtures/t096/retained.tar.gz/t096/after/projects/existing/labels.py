"""夹具已存在查看能力，规划不能改写。"""

LABELS = ("alpha", "beta")

def list_labels():
    return list(LABELS)

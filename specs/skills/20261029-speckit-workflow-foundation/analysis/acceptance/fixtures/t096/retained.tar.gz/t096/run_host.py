"""实际宿主规划回归；保存事件和摘要，每回合240秒，不预写结果。"""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SCENARIOS = {
    'no-plan': ('no-plan', '$task-increment Spec:specs/demo/001-labels'),
    'plan-only': ('plan-only', '$task-increment Spec:specs/demo/001-labels   '),
    'legacy-task': ('existing', '$task-increment Spec:specs/demo/001-labels Task:T009'),
    'existing': ('existing', '$task-increment Spec:specs/demo/001-labels 优先沿T009既有筛选目标安排可独立验收的小闭环；这里T009是现状引用。新增标签的既有职责和权限验收保持，只补必要依赖和规划缺口，说明推荐依据并按已有授权保存。'),
    'repeat-blank': ('existing', '$task-increment Spec:specs/demo/001-labels   '),
    'save-failure': ('save-failure', '$task-increment Spec:specs/demo/001-labels 将查看、新增和筛选分别收敛为可验收的小闭环，核对新增之前的权限和写失败验证，只补必要任务，按已有规划授权保存。'),
    'save-recovery': ('save-failure', '$task-increment Spec:specs/demo/001-labels 上轮受保护文件的写入障碍已由验证端解除，沿实际已保存材料继续原规划并核对引用和重复内容。'),
}


def snapshot(project):
    result = {}
    for path in sorted(project.rglob('*')):
        if {'.git', '__pycache__'} & set(path.relative_to(project).parts):
            continue
        if path.is_file():
            result[str(path.relative_to(project))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def run(stage):
    name, prompt = SCENARIOS[stage]
    project = ROOT / 'cases' / name
    out = ROOT / 'host' / stage
    if out.exists():
        out = ROOT / 'host' / (stage + '-attempt-' + str(time.time_ns()))
    out.mkdir(parents=True)
    if stage == 'save-recovery':
        (project / 'specs/demo/001-labels/tasks.md').chmod(0o644)
    args = ['codex', 'exec', '--cd', str(project), '--sandbox', 'workspace-write']
    if stage in ('repeat-blank', 'save-recovery'):
        previous = 'existing' if stage == 'repeat-blank' else 'save-failure'
        result = json.loads((ROOT / 'host' / previous / 'result.json').read_text())
        assert result['exit'] == 0 and not result['timeout'], result
        args += ['resume', '--json', '--output-last-message', str(out / 'final.txt'), result['session_id'], '-']
    else:
        args += ['--json', '--color', 'never', '--output-last-message', str(out / 'final.txt'), '-']
    before = snapshot(project)
    (out / 'input.txt').write_text(prompt + '\n')
    (out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
    begin = time.monotonic()
    with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(args, cwd=project, stdin=subprocess.PIPE, stdout=stdout,
                                   stderr=stderr, text=True, start_new_session=True)
        timed_out = False
        try:
            process.communicate(prompt + '\n', timeout=240)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    session_id = None
    for line in (out / 'events.jsonl').read_text().splitlines():
        event = json.loads(line)
        if event.get('type') == 'thread.started':
            session_id = event.get('thread_id')
    after = snapshot(project)
    result = {'stage': stage, 'case': name, 'exit': process.returncode, 'timeout': timed_out,
              'elapsed_seconds': round(time.monotonic() - begin, 3), 'session_id': session_id,
              'args': args, 'sandbox': 'workspace-write', 'model_override': False,
              'raw_directory': str(out),
              'changed': [key for key in sorted(before.keys() | after.keys()) if before.get(key) != after.get(key)]}
    (out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
    if (out / 'final.txt').exists():
        print((out / 'final.txt').read_text()[:2200], flush=True)
    if process.returncode:
        print((out / 'stderr.log').read_text()[-1500:], flush=True)
    return result['exit'] == 0 and not timed_out


if __name__ == '__main__':
    flows = {'core': ['no-plan', 'plan-only'],
             'existing-flow': ['legacy-task', 'existing', 'repeat-blank'],
             'failure-flow': ['save-failure', 'save-recovery']}
    requested = flows.get(sys.argv[1], [sys.argv[1]])
    for stage in requested:
        if not run(stage):
            raise SystemExit(1)

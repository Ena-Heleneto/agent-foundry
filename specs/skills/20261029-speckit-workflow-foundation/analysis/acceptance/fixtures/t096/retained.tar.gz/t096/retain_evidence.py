"""归档本轮源、微评估、真实项目操作与检查，保护旧证据和账户边界。"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

scratch = Path(__file__).resolve().parent
repo = Path('<source-workspace>')
destination = repo / 'specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/t096'
destination.mkdir(parents=True, exist_ok=True)
assert not (destination / 'retained.tar.gz').exists()
shutil.copytree(scratch / 'cases', scratch / 'after/projects', ignore=shutil.ignore_patterns('.git', '__pycache__'))
source = repo / 'packages/skills/src/workflow/task-increment/SKILL.md'
(scratch / 'delivered').mkdir()
shutil.copy2(source, scratch / 'delivered/SKILL.md')
review = {'reviewer': 'review_t096', 'scope': '当前源码与写前快照、T096方案/原Task/契约；只读，不替代宿主回归',
          'critical': [], 'important': [], 'minor': [], 'runtime_validation_by_reviewer': False}
(scratch / 'review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')
names = ['before', 'after', 'delivered', 'host', 'installations', 'micro-results.json', 'state.json',
         'host-audit.json', 'final-checks.json', 'frontmatter-proof.json', 'review.json',
         'package-test-baseline.log', 'package-lint.log', 'package-types.log', 'package-test.log',
         'quick-validate.log', 'quick-validate-cached-python.log', 'quick-validate-before.log',
         'prepare_cases.py', 'run_host.py', 'run_flows.py', 'audit_cases.py', 'retain_evidence.py']
patterns = [rb'sk-[A-Za-z0-9_-]{24,}', rb'gh[pousr]_[A-Za-z0-9]{30,}', rb'-----BEGIN [A-Z ]*PRIVATE KEY-----']
scanned = 0
for name in names:
    path = scratch / name
    for item in (list(path.rglob('*')) if path.is_dir() else [path]):
        if item.is_file():
            data = item.read_bytes()
            assert not any(re.search(pattern, data) for pattern in patterns), 'credential-pattern: ' + str(item)
            scanned += 1
archive = destination / 'retained.tar.gz'
with tarfile.open(archive, 'w:gz') as package:
    for name in names:
        package.add(scratch / name, arcname='t096/' + name)
with tarfile.open(archive) as package:
    members = package.getmembers()
    assert all(not Path(member.name).is_absolute() and '..' not in Path(member.name).parts for member in members)

report = json.loads((scratch / 'host-audit.json').read_text())
report.update({'archive': {'file': 'retained.tar.gz', 'bytes': archive.stat().st_size,
                          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(members),
                          'selected_credential_patterns': 3, 'files_scanned': scanned, 'matches': 0,
                          'scan_complete': False},
               'checks': json.loads((scratch / 'final-checks.json').read_text()),
               'micro': json.loads((scratch / 'micro-results.json').read_text()),
               'frontmatter': json.loads((scratch / 'frontmatter-proof.json').read_text()),
               'limits': ['构建、dist同版及构建来源消费暂跳过，未计通过',
                          '官方skills维护源本地安装，不冒充正式modes生成入口或真实工作区迁移',
                          '仅本机Linux宿主；仍可能加载全局辅助技能，不声明唯一因果或全平台保证',
                          '画像为明确标注的人工测试输入，不是父会话用户真实画像或新结论',
                          '分析能力未交付，现场正确报告分析未完成，完整双触发消费仍由后续原Task验证',
                          '恢复回合工具输出截断，复用同一会话上轮已完整读取且摘要未变的skill，不冒称新全文证据',
                          '通用校验器在写前/写后均拒绝原destructive字段；解析、安装及运行证据不等同该校验通过']})
(destination / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['archive'], ensure_ascii=False, indent=2))

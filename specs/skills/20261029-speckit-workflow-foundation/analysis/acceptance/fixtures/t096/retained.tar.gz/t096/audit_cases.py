"""从实际工具输出与文件前后状态核对T096，不把技能文字或最终自述当行为证明。"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
results = []
for directory in sorted((ROOT / 'host').iterdir()):
    if not (directory / 'result.json').is_file():
        continue
    result = json.loads((directory / 'result.json').read_text())
    project = ROOT / 'cases' / result['case']
    events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
    outputs = [(n, event.get('item', {}).get('aggregated_output', ''))
               for n, event in enumerate(events) if event.get('type') == 'item.completed']
    paths = {'skill': project / '.agents/skills/task-increment/SKILL.md',
             'constitution': project / '.specify/memory/constitution.md'}
    if (project / '.collaboration/current.md').is_file():
        paths['profile'] = project / '.collaboration/current.md'
    reads = {name: [n for n, output in outputs if path.read_text().strip() in output]
             for name, path in paths.items()}
    before = json.loads((directory / 'before.json').read_text())
    after = json.loads((directory / 'after.json').read_text())
    errors = [{'event': n, 'exit': event['item'].get('exit_code'),
               'command': event['item'].get('command'),
               'output': event['item'].get('aggregated_output', '')[-2200:]}
              for n, event in enumerate(events) if event.get('type') == 'item.completed'
              and event.get('item', {}).get('type') == 'command_execution'
              and event['item'].get('exit_code')]
    result.update({'turn_completed': any(event.get('type') == 'turn.completed' for event in events),
                   'full_text_reads': reads, 'failed_commands': errors,
                   'business_unchanged': before.get('labels.py') == after.get('labels.py'),
                   'governance_unchanged': before.get('.specify/memory/constitution.md') == after.get('.specify/memory/constitution.md')
                       and before.get('AGENTS.md') == after.get('AGENTS.md')})
    results.append(result)

projects = {}
for project in sorted((ROOT / 'cases').iterdir()):
    feature = project / 'specs/demo/001-labels'
    before = ROOT / 'before/projects' / project.name
    tasks = feature / 'tasks.md'
    text = tasks.read_text() if tasks.is_file() else ''
    initial_tasks = before / 'specs/demo/001-labels/tasks.md'
    initial_lines = initial_tasks.read_text().splitlines() if initial_tasks.is_file() else []
    completed = [line for line in initial_lines if re.match(r'^- \[[xX]\] T\d+', line)]
    protected_paths = ['labels.py', 'AGENTS.md', '.specify/memory/constitution.md']
    for name in ('specs/demo/001-labels/evidence.md', 'specs/demo/001-labels/implementation/T004.md', '.collaboration/current.md'):
        if (before / name).is_file():
            protected_paths.append(name)
    projects[project.name] = {
        'markers': dict((identity, marker.lower()) for marker, identity in re.findall(r'^- \[([ xX])\] (T\d{3})\b', text, re.M)),
        'completed_lines_preserved': all(line in text for line in completed),
        'protected_files': {name: (project / name).read_bytes() == (before / name).read_bytes() for name in protected_paths},
        'implementation_files': [str(p.relative_to(feature)) for p in sorted((feature / 'implementation').rglob('*')) if p.is_file()] if (feature / 'implementation').exists() else [],
        'profile_created': (project / '.collaboration').exists() and not (before / '.collaboration').exists(),
        'analysis_created': (feature / 'analysis').exists(),
    }
report = {'scope': 'T096维护源官方安装下的真实文件应用；非正式modes生成/构建产物/用户业务验收',
          'results': results, 'projects': projects}
(ROOT / 'host-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for result in results:
    print(json.dumps({key: result[key] for key in ('stage', 'exit', 'timeout', 'elapsed_seconds', 'turn_completed', 'full_text_reads', 'business_unchanged', 'governance_unchanged', 'changed')}, ensure_ascii=False))
print(json.dumps(projects, ensure_ascii=False, indent=2))

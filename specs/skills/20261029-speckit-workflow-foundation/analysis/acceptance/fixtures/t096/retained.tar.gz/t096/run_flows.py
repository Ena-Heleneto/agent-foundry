"""两组互不共享项目的回归并行，组内按真实依赖顺序执行。"""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
processes = [subprocess.Popen([sys.executable, str(root / 'run_host.py'), flow])
             for flow in ('existing-flow', 'failure-flow')]
codes = [process.wait() for process in processes]
raise SystemExit(0 if all(code == 0 for code in codes) else 1)

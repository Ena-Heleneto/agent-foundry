"""独立核对正式维护源安装后宿主的实际全文输出及业务边界。"""
from pathlib import Path
import json,re,subprocess,hashlib
ROOT=Path('/tmp/foundry-t104-20261111')
TARGET=Path('/tmp/foundry-tv10-20261110')
results=[]
for name,attempt,expected in [('explicit-no-plan',3,{'T001':' ','T002':' '}),('positive-a',2,{'T001':'x','T002':' '})]:
    raw=TARGET/'raw'/f'{name}-attempt-{attempt}'
    project=TARGET/'cases'/name
    result=json.loads((raw/'result.json').read_text())
    assert result['exit']==0 and not result['timeout']
    outputs=[]
    completed=False
    for i,line in enumerate((raw/'events.jsonl').read_text().splitlines(),1):
        e=json.loads(line);item=e.get('item',{})
        if e.get('type')=='turn.completed':completed=True
        if e.get('type')=='item.completed' and item.get('type')=='command_execution':outputs.append((i,item.get('command',''),item.get('aggregated_output','')))
    assert completed
    source=(project/'.agents/skills/implementation-preparation/SKILL.md').read_text().strip()
    governance=(project/'.specify/memory/constitution.md').read_text().strip()
    reads=[i for i,c,o in outputs if source in o]
    gov_reads=[i for i,c,o in outputs if governance in o]
    assert reads and gov_reads,(name,reads,gov_reads)
    markers=dict((task,mark.lower()) for mark,task in re.findall(r'^- \[([ xX])\] (T\d{3})\b',(project/'specs/demo/001-order/tasks.md').read_text(),re.M))
    assert markers==expected,(name,markers)
    assert not any(p.endswith(('.py','.js','.ts','.mjs','.vue','.sh','.ps1')) for p in result['changed']),result['changed']
    assert result['before']['order.py']==result['after']['order.py']
    row={'case':name,'source_kind':'正式维护源的官方源码安装；非构建产物','exit':result['exit'],'timeout':result['timeout'],'turn_completed':completed,'elapsed_seconds':result['elapsed_seconds'],'model_override':False,'source_full_text_events':reads,'constitution_full_text_events':gov_reads,'business_unchanged':True,'markers':markers,'changed':result['changed'],'raw_directory':str(raw)}
    if name=='positive-a':
        receipt=(project/'specs/demo/001-order/requirements/raw/T001-approval.json').read_text().strip()
        approval_reads=[i for i,c,o in outputs if receipt in o]
        assert approval_reads,'未找到真实认可回执全文输出'
        row['approval_full_text_events']=approval_reads
        unit=subprocess.run(['python3','-B','-m','unittest','-v'],cwd=project,capture_output=True,text=True,timeout=30)
        (ROOT/'independent-unittest.log').write_text(unit.stdout+unit.stderr)
        assert unit.returncode==0
        row['independent_unittest']={'exit':unit.returncode,'output':unit.stdout+unit.stderr}
    results.append(row)
summary={'scope':'T104正式维护源局部回归，不计构建交付或完整T104通过','results':results,'build_validated':False,'T104_complete':False,'limitations':['仅当前Linux宿主','未复验构建产物','A为已完成样例的正常恢复核查，非重新实施样例','宿主仍可读取全局辅助技能，不归因于唯一来源']}
(ROOT/'source-regression-results.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))

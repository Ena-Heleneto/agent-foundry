"""复验正式维护源的宿主消费；构建产物尚不可用，结果不抵扣T104整体验收。"""
from pathlib import Path
import importlib.util,json,sys,time
from datetime import datetime, timezone
spec=importlib.util.spec_from_file_location('tv10_runner','/tmp/foundry-tv10-20261110/run_case.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
case=sys.argv[1]
prompts={'explicit-no-plan':'$speckit-implement specs/demo/001-order T001。','positive-a':'$speckit-implement specs/demo/001-order T001 T002。继续现有任务。'}
started=datetime.now(timezone.utc).isoformat()
begin=time.monotonic()
result=module.run(case,prompts[case])
result.update({'source_kind':'正式维护源，非构建产物','started':started,'ended':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-begin,3),'model_override':False,'sandbox':'workspace-write'})
Path(result['raw_directory'],'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
if result['exit'] or result['timeout']:
    raise SystemExit(1)

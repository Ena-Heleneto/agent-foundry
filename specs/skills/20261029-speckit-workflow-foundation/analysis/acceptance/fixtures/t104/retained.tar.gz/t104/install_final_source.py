"""仅在恢复的TV-10临时目标核对官方源码安装，不产生构建交付。"""
from pathlib import Path
import hashlib,json,os,subprocess,shutil

ROOT=Path('/tmp/foundry-t104-20261111')
TARGET=Path('/tmp/foundry-tv10-20261110')
REPO=Path('<source-workspace>')
SOURCE=REPO/'packages/skills/src/skills/workflow/implementation-preparation'
SPECIFY=Path('<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/specify')
OFFICIAL=next((ROOT/'npm-cache/_npx').glob('*/node_modules/skills/bin/cli.mjs'))

def hashes(root):
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}

def run(args,project,env,destination):
    result=subprocess.run(args,cwd=project,env=env,capture_output=True,text=True,timeout=60)
    destination.write_text(result.stdout+result.stderr)
    if result.returncode:
        raise RuntimeError(str(args[:3])+': '+str(result.returncode)+' '+(result.stdout+result.stderr)[-1800:])
    return result.stdout.strip()

for name in ['positive-a','explicit-no-plan']:
    project=TARGET/'cases'/name
    raw=ROOT/'raw'/f'{name}-final-source-install'
    raw.mkdir(parents=True,exist_ok=False)
    env={**os.environ,'XDG_STATE_HOME':str(ROOT/'official-state'/name),'DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','NO_COLOR':'1','CI':'1','PYTHONDONTWRITEBYTECODE':'1'}
    run(['git','init','--quiet'],project,env,raw/'git-init.log')
    native=project/'.agents/skills/speckit-implement/SKILL.md'
    before=hashlib.sha256(native.read_bytes()).hexdigest()
    versions={'specify':run([str(SPECIFY),'--version'],project,env,raw/'specify-version.log'),'skills':run(['node',str(OFFICIAL),'--version'],project,env,raw/'skills-version.log')}
    assert versions=={'specify':'specify 1.2.6','skills':'1.7.4'},versions
    args=['node',str(OFFICIAL),'add',str(SOURCE),'--skill','implementation-preparation','--agent','codex','--copy','--yes']
    run(args,project,env,raw/'skills-add.log')
    installed=project/'.agents/skills/implementation-preparation'
    assert hashes(SOURCE)==hashes(installed), (hashes(SOURCE),hashes(installed))
    extension=ROOT/'extension-input'/name
    (extension/'skills').mkdir(parents=True)
    shutil.copytree(installed,extension/'skills/implementation-preparation')
    manifest={'schema_version':'1.0','extension':{'id':'implementation-preparation','name':'Implementation Preparation','version':'0.1.0','description':'T104正式维护源隔离验证，构建交付待验'},'requires':{'speckit_version':'==1.2.6'},'provides':{},'hooks':json.loads((installed/'speckit-hooks.json').read_text())}
    (extension/'extension.yml').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    ext_args=[str(SPECIFY),'extension','add','--dev',str(extension),'--force']
    run(ext_args,project,env,raw/'extension-add.log')
    assert hashes(SOURCE)==hashes(installed)
    assert hashes(SOURCE)==hashes(project/'.specify/extensions/implementation-preparation/skills/implementation-preparation')
    import yaml
    config=yaml.safe_load((project/'.specify/extensions.yml').read_text())
    hook=[h for h in config['hooks']['before_implement'] if h['extension']=='implementation-preparation']
    assert len(hook)==1 and hook[0]['optional'] is False and hook[0]['condition'] is None and hook[0]['enabled'] is True,hook
    after=hashlib.sha256(native.read_bytes()).hexdigest()
    assert before==after
    assert before==hashlib.sha256((TARGET/'seed/.agents/skills/speckit-implement/SKILL.md').read_bytes()).hexdigest()
    proof={'case':name,'project':str(project),'versions':versions,'official_cli':str(OFFICIAL),'source':str(SOURCE),'source_kind':'正式维护源；尚非构建产物','source_files':hashes(SOURCE),'installed':str(installed),'installed_files':hashes(installed),'extension_files':hashes(project/'.specify/extensions/implementation-preparation/skills/implementation-preparation'),'native_before_sha256':before,'native_after_sha256':after,'registered_hook':hook,'commands':[args,ext_args],'build_validated':False}
    (raw/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(name+': 官方源码安装、hooks-only登记、两文件完整集合/摘要及原生入口保护通过；不计构建交付。',flush=True)

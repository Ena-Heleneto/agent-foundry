from pathlib import Path
import subprocess,sys,os,json,hashlib,time,signal,re

ROOT=Path('/tmp/foundry-tv10-20261110')

def snapshot(project):
    return {str(p.relative_to(project)):hashlib.sha256(p.read_bytes()).hexdigest() for p in project.rglob('*') if p.is_file() and '.git' not in p.relative_to(project).parts and '__pycache__' not in p.relative_to(project).parts}

def run(name,prompt):
    project=ROOT/'cases'/name
    out=ROOT/'raw'/name
    attempt=1
    while out.exists() and (out/'result.json').exists():
        attempt+=1
        out=ROOT/'raw'/f'{name}-attempt-{attempt}'
    out.mkdir(parents=True,exist_ok=True)
    (out/'input.txt').write_text(prompt+'\n')
    before=snapshot(project); (out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
    args=['codex','exec','--json',*(['--ephemeral'] if name!='positive-a' else []),'--cd',str(project),'--sandbox','workspace-write','--color','never','--output-last-message',str(out/'final.txt'),'-']
    with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
        process=subprocess.Popen(args,cwd=project,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,text=True,start_new_session=True)
        (out/'process-id.txt').write_text(str(process.pid)+'\n')
        timed_out=False
        try:
            process.communicate(prompt+'\n',timeout=240)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(process.pid,signal.SIGTERM)
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL); process.wait()
    after=snapshot(project)
    result={'case':name,'exit':process.returncode,'timeout':timed_out,'before':before,'after':after,'changed':[p for p in sorted(before.keys() | after.keys()) if before.get(p)!=after.get(p)],'raw_directory':str(out)}
    (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['before','after']},ensure_ascii=False,indent=2),flush=True)
    if (out/'final.txt').exists(): print('FINAL:\n'+(out/'final.txt').read_text()[:3200],flush=True)
    if process.returncode: print('STDERR:\n'+(out/'stderr.log').read_text()[-1500:],flush=True)
    return result

if __name__=='__main__':
    if sys.argv[1]=='--batch':
        entries=json.loads(Path(sys.argv[2]).read_text())
        for entry in entries:
            result=run(entry['case'],entry['prompt'])
            project=ROOT/'cases'/entry['case']
            markers=dict((i,s.lower()) for s,i in re.findall(r'^- \[([ xX])\] (T\d{3})\b',(project/'specs/demo/001-order/tasks.md').read_text(),re.M))
            business=[p for p in result['changed'] if p=='order.py' or p.endswith(('.py','.js','.ts','.vue','.mjs','.sh','.ps1'))]
            ok=result['exit']==0 and not result['timeout'] and not business and markers=={'T001':' ','T002':' '}
            verdict={'case':entry['case'],'noBusinessWrites':not business,'checkboxesUnchanged':markers=={'T001':' ','T002':' '},'runtimeExit':result['exit'],'preliminaryPass':ok}
            (ROOT/'raw'/f"{entry['case']}-verdict.json").write_text(json.dumps(verdict,ensure_ascii=False,indent=2)+'\n')
            print('VERDICT '+json.dumps(verdict,ensure_ascii=False),flush=True)
            if not ok: raise SystemExit(2)
    else:
        name=sys.argv[1]
        prompt=Path(sys.argv[2]).read_text() if len(sys.argv)>2 else '$speckit-implement specs/demo/001-order T001。'
        run(name,prompt)

"""保护原需求、任务与其他闭环；验证本次文档相对引用。"""
from pathlib import Path
import hashlib,json,re,sys,urllib.parse
ROOT=Path(__file__).resolve().parent;repo=Path.cwd();state=json.loads((ROOT/'state.json').read_text());base=Path('specs/skills/20261029-speckit-workflow-foundation');closed='--closed' in sys.argv
for f in state['files']:
 if ('/requirements/' in f and not f.endswith('/README.md')) or f in ['.specify/memory/constitution.md','.specify/memory/user-shadow/profile.md',str(base/'plan.md')]:
  assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==state['sha256'][f],f
for name,head,nexthead in [('implementation-preparation','## 需求变更与来源','## 形成适用的讨论结果'),('task-increment','## 需求原文与简洁摘要','## 既有画像的参考')]:
 p=Path('packages/skills/src/workflow')/name/'SKILL.md';s=p.read_text();stripped=s[:s.index(head)]+s[s.index(nexthead,s.index(head)):];assert stripped==(ROOT/'before'/p).read_text(),name
old=(ROOT/'before'/base/'tasks.md').read_text();new=(base/'tasks.md').read_text();pattern=r'^- \[([ x])\] (T\d{3})\b';a=re.findall(pattern,old,re.M);b=re.findall(pattern,new,re.M);assert [v[1] for v in a]==[v[1] for v in b] and len(b)==107
changed=[(x,y) for x,y in zip(a,b) if x!=y];assert changed==([((' ','T106'),('x','T106'))] if closed else []),changed
assert old[old.index('## Phase 8：'):]==new[new.index('## Phase 8：'):],'later tasks/history'
start=old.index('**验收与保护**：按TV-12实际需求变更');end=old.index('\n**检查点**',start);assert old[start:end] in new
for name in ['spec.md']:
 a=(ROOT/'before'/base/name).read_text();b=(base/name).read_text();assert re.findall(r'^- \*\*(?:FR|SC)-\d+.*$',a,re.M)==re.findall(r'^- \*\*(?:FR|SC)-\d+.*$',b,re.M)
paths=[base/'implementation/T106.md',base/'analysis/acceptance/requirements-trace.md',base/'requirements/README.md']
checks=0
for path in paths:
 for dest in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',path.read_text()):
  if re.match(r'[a-z]+://',dest):continue
  file,sep,anchor=dest.partition('#');p=(path.parent/urllib.parse.unquote(file)).resolve() if file else path.resolve();assert p.exists(),(path,dest)
  if sep and p.suffix=='.md':
   heads=re.findall(r'^#{1,6}\s+(.+)$',p.read_text(),re.M);slugs=[re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-') for h in heads];assert anchor in slugs,(path,dest)
  checks+=1
result={'task_identities':len(b) if isinstance(b,list) else 107,'checkbox_changes':changed,'links_checked':checks,'original_requirements':'unchanged except navigation','governance_profile_plan':'unchanged','old_skill_bodies':'byte-identical after removing additions','FR_SC':'unchanged'}
(ROOT/'root-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))

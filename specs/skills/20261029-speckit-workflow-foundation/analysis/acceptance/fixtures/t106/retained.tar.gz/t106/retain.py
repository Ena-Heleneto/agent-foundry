"""留存本Task最小自包含证据，不夹带父仓库画像正文或账户目录。"""
from pathlib import Path
import hashlib,json,re,shutil,tarfile
ROOT=Path(__file__).resolve().parent;REPO=Path('<source-workspace>');BASE=Path('specs/skills/20261029-speckit-workflow-foundation');OUT=REPO/BASE/'analysis/acceptance/fixtures/t106';OUT.mkdir(parents=True,exist_ok=True)
assert not (OUT/'retained.tar.gz').exists()
stage=ROOT/'retained';stage.mkdir()
for name in ['implementation-preparation','task-increment']:
 shutil.copytree(REPO/'packages/skills/src/workflow'/name,stage/'delivered'/name)
 shutil.copytree(ROOT/'before/packages/skills/src/workflow'/name,stage/'before-sources'/name)
for name in ['prep','prep-failure','increment']:
 shutil.copytree(ROOT/'before/projects'/name,stage/'before-projects'/name,ignore=shutil.ignore_patterns('.git','__pycache__'))
 shutil.copytree(ROOT/'cases'/name,stage/'after-projects'/name,ignore=shutil.ignore_patterns('.git','__pycache__'))
for name in ['host','installations']:
 shutil.copytree(ROOT/name,stage/name)
for name in ['micro.json','real-input.json','host-audit.json','root-checks.json','package-checks.json','review.json','prepare.py','prepare_increment.py','run.py','audit.py','check_root.py','check_package.py','retain.py']:
 shutil.copy2(ROOT/name,stage/name)
for p in ROOT.glob('*.log'):shutil.copy2(p,stage/p.name)
# 只保留所需功能文档的写前片段；不复制父仓库.specify/memory/user-shadow。
for name in ['tasks.md','spec.md','mvu.md','requirements/README.md']:
 target=stage/'before-feature'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/'before'/BASE/name,target)
patterns=[rb'sk-[A-Za-z0-9_-]{24,}',rb'gh[pousr]_[A-Za-z0-9]{30,}',rb'-----BEGIN [A-Z ]*PRIVATE KEY-----']
files=list(p for p in stage.rglob('*') if p.is_file())
for p in files:
 data=p.read_bytes();assert not any(re.search(pattern,data) for pattern in patterns),str(p)
 assert '.specify/memory/user-shadow/profile.md' not in str(p.relative_to(stage))
archive=OUT/'retained.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(stage,arcname='t106')
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert all(not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
report=json.loads((ROOT/'host-audit.json').read_text());report['package_checks']=json.loads((ROOT/'package-checks.json').read_text());report['root_checks']=json.loads((ROOT/'root-checks.json').read_text());report['review']=json.loads((ROOT/'review.json').read_text());report['micro']=json.loads((ROOT/'micro.json').read_text())
report['archive']={'file':'retained.tar.gz','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(members),'selected_credential_patterns':len(patterns),'files_scanned':len(files),'matches':0,'scan_complete':False,'parent_profile_included':False}
report['limits']=['prep和increment首轮各240秒超时，原失败保留；同会话续接正常结束另列，不抵首次失败','外层首次只读环境初始化失败，审批后外层启动；内层仍workspace-write','Linux本机默认模型，可能加载全局辅助skill，不推断唯一因果或全平台保证','当前维护源官方skills本地安装；非build/dist、正式modes生成或当前hook完整接线验证','真实历史输入回放和人工结构夹具不冒充新用户确认、真实业务或长期画像效果','原destructive字段写前后被通用validator拒绝；准备validator通过，不宣称全部通用校验通过','原文与摘要本Task已验；同一综合分析能力缺失仍未完成，T062～T064不据此通过']
(OUT/'results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report['archive'],ensure_ascii=False,indent=2))

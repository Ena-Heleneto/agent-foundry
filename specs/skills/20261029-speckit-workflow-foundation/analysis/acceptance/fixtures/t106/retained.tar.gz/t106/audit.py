"""对实际输出核查来源、引用、保护范围与安装来源；语义另行人工核查。"""
from pathlib import Path
import hashlib,json,re,urllib.parse
ROOT=Path(__file__).resolve().parent;FEATURE=Path('specs/skills/001-workflow')
STAGES=['prep','prep-failure','prep-finish','prep-recovery','increment','increment-repeat','increment-finish']
original=json.loads((ROOT/'real-input.json').read_text())['verbatim']
def hashes(d):return {str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file()}
def markers(s):return dict((i,x) for x,i in re.findall(r'^- \[([ x])\] (T\d+)\b',s,re.M))
def links(path):
 count=0
 for dest in re.findall(r'\[[^\]\n]*\]\(([^)\n]+)\)',path.read_text()):
  if re.match(r'[a-z]+://',dest) or '${' in dest:continue
  target,sep,anchor=dest.strip('<>').partition('#');p=(path.parent/urllib.parse.unquote(target)).resolve() if target else path.resolve();assert p.exists(),(path,dest)
  if sep and p.suffix=='.md':
   heads=re.findall(r'^#{1,6}\s+(.+)$',p.read_text(),re.M);slugs=[re.sub(r'[^\w\- ]','',h.lower()).replace(' ','-') for h in heads]
   assert urllib.parse.unquote(anchor) in slugs,(path,dest)
  count+=1
 return count
results={'stages':{},'projects':{}}
for stage in STAGES:
 p=ROOT/'host'/stage/'result.json'
 if not p.exists():continue
 r=json.loads(p.read_text());es=[json.loads(l) for l in (p.parent/'events.jsonl').read_text().splitlines() if l.startswith('{')]
 outputs=[e.get('item',{}).get('aggregated_output','') for e in es];commands=[e.get('item',{}).get('command','') for e in es]
 skill='task-increment' if stage.startswith('increment') else 'implementation-preparation';source=(Path(r['project'])/'.agents/skills'/skill/'SKILL.md').read_text()
 r['full_skill_in_tool_output']=any(source in s for s in outputs)
 r['native_entry_in_tool_output']=any('name: "speckit-implement"' in s for s in outputs)
 r['permission_error_in_tool_output']=any('PermissionError' in s and 'Errno 13' in s for s in outputs)
 r['completed_commands']=sum(e.get('type')=='item.completed' and e.get('item',{}).get('type')=='command_execution' for e in es)
 results['stages'][stage]=r
for name in ['prep','prep-failure','increment']:
 project=ROOT/'cases'/name;f=project/FEATURE;before=ROOT/'before/projects'/name;raw=list((f/'requirements/raw').glob('*.md'));assert len(raw)==1,name;assert original in raw[0].read_text(),name
 bm=markers((before/FEATURE/'tasks.md').read_text());am=markers((f/'tasks.md').read_text());assert all(am.get(k)==v for k,v in bm.items()),(name,bm,am)
 for file in ['business.py','AGENTS.md','.specify/memory/constitution.md','inputs/history.md','inputs/decision.md']:
  assert (before/file).read_bytes()==(project/file).read_bytes(),(name,file)
 assert (before/FEATURE/'evidence.md').read_bytes()==(f/'evidence.md').read_bytes(),name
 assert (before/FEATURE/'implementation/T002.md').read_text().strip() in (f/'implementation/T002.md').read_text(),(name,'old scheme lost')
 for path in f.rglob('*.md'):
  if path.name!='tasks.md':assert not re.search(r'^- \[[ x]\] T\d+',path.read_text(),re.M),(name,path)
 count=sum(links(p) for p in f.rglob('*.md'))
 results['projects'][name]={'raw':str(raw[0].relative_to(project)),'raw_sha256':hashlib.sha256(raw[0].read_bytes()).hexdigest(),'raw_original_block_preserved':True,'original_task_markers':bm,'current_task_markers':am,'links_checked':count,'protected_files':'unchanged','old_scheme':'retained'}
# Failure saved source first; recovery preserves its bytes and does not archive a second input.
b=json.loads((ROOT/'host/prep-failure/after.json').read_text());a=json.loads((ROOT/'host/prep-recovery/after.json').read_text())
kept=[k for k in b if '/requirements/raw/' in k or '/requirements/discussions/' in k]
assert all(a[k]==b[k] for k in kept),kept
assert results['stages']['prep-failure']['permission_error_in_tool_output']
assert results['stages']['prep-finish']['changed']==[]
if 'increment-repeat' in results['stages']:
 r=results['stages']['increment-repeat'];assert r['session_id']==results['stages']['increment']['session_id']
 before=json.loads((ROOT/'host/increment-repeat/before.json').read_text());after=json.loads((ROOT/'host/increment-repeat/after.json').read_text())
 rawkeys=[k for k in before if '/requirements/raw/' in k];assert rawkeys and all(before[k]==after[k] for k in rawkeys)
 results['increment_repeat_raw_preserved']=True
(ROOT/'host-audit.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'stages':{k:{q:v.get(q) for q in ['exit','timeout','elapsed_seconds','full_skill_in_tool_output','native_entry_in_tool_output','permission_error_in_tool_output']} for k,v in results['stages'].items()},'projects':results['projects']},ensure_ascii=False,indent=2))

if 'increment-finish' in results['stages']:
 r=results['stages']['increment-finish'];assert r['exit']==0 and not r['timeout'] and r['changed']==[]

"""实际宿主回合，原始输入/事件/差异分别保留；不预写被测结果。"""
from pathlib import Path
import concurrent.futures,hashlib,json,os,signal,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
FEATURE=Path('specs/skills/001-workflow')
PROMPTS={
 'increment':('increment','$task-increment Spec:specs/skills/001-workflow 沿inputs/history.md的真实历史变更和inputs/decision.md的已保存范围，在该Spec内完成已授权的资料同步及增量规划，按可观察小结果安排原任务和必要前置，不开始业务实现。请简洁报告实际保存结果。'),
 'increment-finish':('increment','沿已保存文件只做收尾核对并简洁报告：本次原文、摘要及规划实际保存了什么，哪些阶段未完成。不要重做规划，不再写文件；没有新增需求、认可或业务授权。'),
 'increment-repeat':('increment','$task-increment Spec:specs/skills/001-workflow   '),
 'prep':('prep','开始 specs/skills/001-workflow 的T002。沿inputs/history.md的真实历史变更和inputs/decision.md的已保存范围，在该Spec内做已授权的资料同步及实施准备，不开始业务实现。请简洁汇报实际结果。'),
 'prep-finish':('prep','上轮资料同步在宿主时间上限结束，尚未得到完整回执。沿实际文件完成原资料核对、格式/引用检查及原范围回报，不重复归档或扩大授权，不开始业务实现。'),
 'prep-repeat':('prep','仅核对刚才的资料结果和当前进度；没有新需求，也不授权业务实施。'),
 'prep-failure':('prep-failure','$speckit-implement specs/skills/001-workflow T002。沿inputs/history.md的真实历史变更和inputs/decision.md的已保存范围，继续该Spec获授权的资料同步和共同准备，不开始业务实现。权限由验证端控制，请简洁汇报实际结果。'),
 'prep-recovery':('prep-failure','$speckit-implement specs/skills/001-workflow T002。上轮requirements路径写入障碍已由验证端解除，沿实际文件继续原资料同步和共同准备；本轮没有新增需求或业务实施认可。'),
}
def snapshot(project):
 result={}
 for p in sorted(project.rglob('*')):
  if '.git' in p.parts or '__pycache__' in p.parts:continue
  if p.is_file():result[str(p.relative_to(project))]=hashlib.sha256(p.read_bytes()).hexdigest()
 return result
def run(stage,previous=None):
 name,prompt=PROMPTS[stage];project=ROOT/'cases'/name;out=ROOT/'host'/stage
 if out.exists():out.rename(ROOT/'host'/(stage+'-environment-first'))
 out.mkdir(parents=True,exist_ok=False)
 if stage=='prep-recovery':
  req=project/FEATURE/'requirements';req.chmod(0o755);(req/'README.md').chmod(0o644)
 args=['codex','exec','--cd',str(project),'--sandbox','workspace-write']
 if previous:
  result=json.loads((ROOT/'host'/previous/'result.json').read_text());assert result.get('session_id') and ((result['exit']==0 and not result['timeout']) or (stage in ('prep-finish','increment-repeat','increment-finish') and result['timeout'])),result
  args+=['resume','--json','--output-last-message',str(out/'final.txt'),result['session_id'],'-']
 else:args+=['--json','--color','never','--output-last-message',str(out/'final.txt'),'-']
 (out/'input.txt').write_text(prompt+'\n'); before=snapshot(project);(out/'before.json').write_text(json.dumps(before,indent=2)+'\n')
 start=time.monotonic();env={**os.environ,'SPECIFY_FEATURE_DIRECTORY':str(FEATURE)}
 with (out/'events.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
  process=subprocess.Popen(args,cwd=project,env=env,stdin=subprocess.PIPE,stdout=stdout,stderr=stderr,text=True,start_new_session=True);timeout=False
  try:process.communicate(prompt+'\n',timeout=240)
  except subprocess.TimeoutExpired:
   timeout=True;os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
 session=None
 for line in (out/'events.jsonl').read_text().splitlines():
  try:
   event=json.loads(line)
   if event.get('type')=='thread.started':session=event['thread_id']
  except json.JSONDecodeError:pass
 after=snapshot(project);(out/'after.json').write_text(json.dumps(after,indent=2)+'\n')
 result={'stage':stage,'project':str(project),'exit':process.returncode,'timeout':timeout,'elapsed_seconds':round(time.monotonic()-start,3),'session_id':session,'args':args,'changed':[k for k in sorted(before.keys()|after.keys()) if before.get(k)!=after.get(k)],'model_override':False}
 (out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False),flush=True)
 if (out/'final.txt').exists():print((out/'final.txt').read_text()[:2200],flush=True)
 if process.returncode:print((out/'stderr.log').read_text()[-1000:],flush=True)
 return process.returncode==0 and not timeout
if __name__=='__main__':
 if sys.argv[1]=='initial':
  req=ROOT/'cases/prep-failure'/FEATURE/'requirements';req.chmod(0o755);(req/'raw').mkdir(exist_ok=True);req.chmod(0o555)
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(run,['prep','prep-failure']))
  raise SystemExit(0 if all(results) else 1)
 stage=sys.argv[1]; previous={'increment-finish':'increment-repeat','increment-repeat':'increment','prep-finish':'prep','prep-repeat':'prep-finish','prep-recovery':'prep-failure'}.get(stage)
 raise SystemExit(0 if run(stage,previous) else 1)

# 需求变更与材料导航

## 调整工作流基座，优先 Implement

**问题**：Task内容过长、提前固定文件和做法，用户难以审阅，实施容易偏离思路；对话记录未充分转化为有效理解，需求变化和核心功能也不容易快速定位。

**解决方向**：MVU按小业务闭环或描述规划，取消Task参数；实施前任务保持轻量，开工前共同讨论并保存单Task方案。画像提炼习惯、思路和判断方式，实际应用方式先试用；资料按职责灵活分类，保存需求原文及简洁摘要，Spec分析增加逐功能独立成块的简洁完整说明。

**本期范围**：先交付原生Implement的共同实施准备skill及before_implement接入，保留Increment规划；Pair/Tutor/Direct研发和当前测试暂停，分发移除三者挂载及四项齐备前置。新规则不写AGENTS等项目级规范，原有技术验证、恢复、验收、历史保护和收尾清理继续沿用。

**当前状态**：第一版需求及原有要求核对、Plan/Tasks重规划已完成，宪章7.0.0和独立原则输入已生效并经T102复核；T101资料基线、T103共同准备最小候选TV-10验证已完成，[实际验收](../analysis/acceptance/tv-10-preparation.md#第三轮补齐与当前验收2026-11-10)保留异常、恢复、真实并行与认可范围证据。T104正式维护源及其官方源码安装、全文读取和局部边界回归已有[记录](../analysis/acceptance/t104-preparation-delivery.md)；用户最新要求[先跳过构建相关内容](raw/2026-11-11-defer-build-validation.md)，当前按[原任务说明](../tasks.md#当前构建相关内容暂跳过2026-11-11)暂缓build、dist及构建产物回归，T104整体保持未完成，T105可沿已有正式源码安装继续，不再等待构建。跳过不计通过，画像轻量检查仍处于试用；其他原Task身份、完成事实及真实验收条件保持。

**日期**：需求归档2026-11-10；当前进度更新2026-11-11。具体时间未作额外记录。

**本轮进展**：[T105非构建职责](../analysis/acceptance/task-inline.md#t105-正式来源的轻量任务与方案消费)已验证；随后[T096新规则适配](../analysis/acceptance/tv-06-description.md#t096-新规则适配与真实来源回归)在已有Increment能力上补齐三项差异，七个宿主回合及包lint/types、12项测试通过。构建来源补验、正式入口及完整分析仍保留未验，整体checkbox不勾选；下游消费已有证据的非构建职责。当前是实施进度，没有新增需求原文，也不把测试画像或场景输入当成用户新要求。

**画像维护进展**：[T060资料核查](../analysis/acceptance/user-shadow.md#t060-本轮维护范围)已完成汇总遗漏/陈旧状态修复及当前理解更新，原结论与来源保留；[T061真实核验](../analysis/acceptance/user-shadow.md#t061-真实纠正恢复与应用核验)已覆盖两轮来源链、一次有效更正、历史恢复读取及后续真实提问/取舍，按原有限抽查完成。MVU-005据实际闭环转已通过；全维度、长期效果及未出现的新纠正机会仍未验证，接受试用和资料读回不记效果通过。本次只核查本仓库既有资料，没有新增画像规则或对外个人数据。

## 来源与整理结果

- [原始验收反馈](raw/2026-11-10-implementation-discussion-revision.md)
- [Implement优先与分发范围原文](raw/2026-11-10-implement-first-scope.md)
- [14项原始需求覆盖](discussions/2026-11-10-a-md-coverage.md)
- [画像范围与轻量试用](discussions/2026-11-10-user-shadow-scope.md)
- [资料分类、灵活生成与摘要](discussions/2026-11-10-artifact-organization.md)
- [核心功能点的独立内容块](discussions/2026-11-10-logic-navigation.md)
- [原有要求与本轮调整核对](discussions/2026-11-10-existing-requirements-review.md)
- [工作流基座追加提示词](prompts/2026-11-10-implement-first-revision.md)
- [分发配套提示词](../../001-skills-distribution/requirements/prompts/2026-11-10-implement-only-mount-revision.md)
- [T103共同准备候选验收](../analysis/acceptance/tv-10-preparation.md#第三轮补齐与当前验收2026-11-10)

本页是当前变更的简洁说明与导航；其他生成材料可按实际职责补充。原始输入、详细讨论、有效Spec和工程状态仍在各自位置维护，历史来源不因摘要更新被覆盖。

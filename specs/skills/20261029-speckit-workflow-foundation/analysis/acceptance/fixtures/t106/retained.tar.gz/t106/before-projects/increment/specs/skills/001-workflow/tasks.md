# 工程任务

- [x] T001 已有基础，证据见[evidence.md](evidence.md)。
- [ ] T002 核对Implement实施准备；验收无有效认可方案不实施；不得写业务代码。方案见[implementation/T002.md](implementation/T002.md)。
- [ ] T003 Pair研发及专项测试，原身份与要求保留。
- [ ] T004 Tutor研发及专项测试，原身份与要求保留。
- [ ] T005 Direct研发及专项测试，原身份与要求保留。
- [ ] T006 Increment规划；先形成可观察业务闭环再映射任务，不自动实施。
- [ ] T009 有效序列末尾清理开发产物并核对引用；保护正式来源和证据。

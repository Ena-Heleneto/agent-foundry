"""复用同一真实变更输入，为Increment安装当前正式维护源。"""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parent;REPO=Path('<source-workspace>')
project=ROOT/'cases/increment';shutil.copytree(ROOT/'before/projects/prep',project)
subprocess.run(['git','init','--quiet'],cwd=project,check=True)
source=REPO/'packages/skills/src/workflow/task-increment';cli=next(Path('/tmp/foundry-t104-20261111/npm-cache/_npx').glob('*/node_modules/skills/bin/cli.mjs'))
out=ROOT/'installations/increment';out.mkdir(parents=True)
args=['node',str(cli),'add',str(source),'--skill','task-increment','--agent','codex','--copy','--yes']
env={**os.environ,'CI':'1','DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','XDG_STATE_HOME':str(ROOT/'official-state/increment')}
r=subprocess.run(args,cwd=project,env=env,text=True,capture_output=True,timeout=60);(out/'install.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
hashes=lambda d:{str(p.relative_to(d)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob('*')) if p.is_file()}
installed=project/'.agents/skills/task-increment';assert hashes(source)==hashes(installed)
(out/'proof.json').write_text(json.dumps({'args':args,'source_files':hashes(source),'installed_files':hashes(installed),'source_kind':'官方skills维护源本地安装；不是正式modes生成入口或构建产物'},ensure_ascii=False,indent=2)+'\n')
shutil.copytree(project,ROOT/'before/projects/increment',ignore=shutil.ignore_patterns('.git'))
p=ROOT/'run.py';s=p.read_text();s=s.replace(" 'prep':", " 'increment':('increment','$task-increment Spec:specs/skills/001-workflow 沿inputs/history.md的真实历史变更和inputs/decision.md的已保存范围，在该Spec内完成已授权的资料同步及增量规划，按可观察小结果安排原任务和必要前置，不开始业务实现。请简洁报告实际保存结果。'),\n 'increment-repeat':('increment','$task-increment Spec:specs/skills/001-workflow   '),\n 'prep':",1)
s=s.replace("{'prep-finish':'prep'", "{'increment-repeat':'increment','prep-finish':'prep'");p.write_text(s)
print('increment输入及官方源码安装完成；尚未写被测规划结果。')

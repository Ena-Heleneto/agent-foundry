"""保留真实包检查与校验器退出码；构建明确暂缓。"""
from pathlib import Path
import json,subprocess
root=Path(__file__).resolve().parent;repo=Path('<source-workspace>')
commands={
'package-lint':['pnpm','--filter','@foundry/skills','run','lint'],
'package-types':['pnpm','--filter','@foundry/skills','run','check-types'],
'package-test':['pnpm','--filter','@foundry/skills','run','test'],
'skill-lint':['pnpm','exec','eslint','--no-ignore','packages/skills/src/workflow/implementation-preparation/SKILL.md','packages/skills/src/workflow/task-increment/SKILL.md'],
'prep-validate':['<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/python','<source-home>/.codex/skills/.system/skill-creator/scripts/quick_validate.py','packages/skills/src/workflow/implementation-preparation'],
'increment-validate':['<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/python','<source-home>/.codex/skills/.system/skill-creator/scripts/quick_validate.py','packages/skills/src/workflow/task-increment'],
'increment-before-validate':['<source-home>/.cache/uv/archive-v0/om6AD6JxRTroJuBL/bin/python','<source-home>/.codex/skills/.system/skill-creator/scripts/quick_validate.py',str(root/'before/packages/skills/src/workflow/task-increment')],
}
results={}
for name,args in commands.items():
 r=subprocess.run(args,cwd=repo,text=True,capture_output=True,timeout=180);(root/(name+'.log')).write_text(r.stdout+r.stderr)
 results[name]={'args':args,'exit':r.returncode,'output_tail':(r.stdout+r.stderr)[-1100:]};print(name,r.returncode,(r.stdout+r.stderr)[-350:],flush=True)
(root/'package-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
assert all(v['exit']==0 for k,v in results.items() if k not in ['increment-validate','increment-before-validate'])
assert results['increment-validate']['exit']==results['increment-before-validate']['exit']==1
assert results['increment-validate']['output_tail']==results['increment-before-validate']['output_tail']

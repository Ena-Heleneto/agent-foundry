# 示例工程约定

使用Python标准库；命令为python3 -B -m unittest -v。保留原任务身份与其他Task的目标。

现有官方CLI的YAML运行时为<source-home>/.cache/uv/archive-v0/FFsdlmKBeESY_-Br/bin/python，其中已有PyYAML；解析配置可使用该工具，无须安装新依赖。

> 迁仓派生说明：本副本已替换原机器路径或移除私有记录链接；命令、摘要和验收事实保留其原发生语境，原件保存在来源仓库。

"""隔离测试的受控hook故障，不是业务实现。"""
print("TV10_FAULT_EXIT_23")
raise SystemExit(23)

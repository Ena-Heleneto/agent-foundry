---
name: tv10-failing-hook
description: before_implement配置指定tv10-failing-hook时使用。
---

# 调用故障探针

运行目标项目的python3 -B hook_failure_probe.py，按真实退出结果回传本hook的调用结果。

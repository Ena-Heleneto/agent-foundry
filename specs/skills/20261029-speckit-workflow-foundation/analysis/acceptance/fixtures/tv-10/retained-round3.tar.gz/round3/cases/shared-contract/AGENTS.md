# 示例工程约定

使用Python标准库；命令为python3 -B -m unittest -v。保留原任务身份与其他Task的目标。
YAML工具可用<source-home>/.cache/uv/archive-v0/FFsdlmKBeESY_-Br/bin/python，该运行时已有PyYAML。
Markdown格式检查使用python3 -B tools/check_markdown.py <文件>，核对UTF-8、LF及末尾换行；检查后完整读回。

> 迁仓派生说明：本副本已替换原机器路径或移除私有记录链接；命令、摘要和验收事实保留其原发生语境，原件保存在来源仓库。

---
name: implementation-preparation
description: 用户在Spec Kit项目实施Task时使用。
metadata:
  version: "0.0.1"
---

# 旧版实施准备

读取总体plan后安排实现步骤；本历史版本尚未支持单Task方案及恢复。

"""T001的小计验收，不实现被测业务。"""
import unittest
import order

class SubtotalTests(unittest.TestCase):
    def test_subtotal(self):
        self.assertTrue(callable(getattr(order, 'calculate_subtotal', None)), '缺少订单小计实现')
        self.assertEqual(order.calculate_subtotal(1250, 3), 3750)
        self.assertEqual(order.calculate_subtotal(0, 3), 0)
        self.assertEqual(order.calculate_subtotal(1250, 0), 0)
        for price, quantity in [(-1, 1), (1, -1), (1.5, 2), (1, True), ('1', 2)]:
            with self.assertRaises(ValueError):
                order.calculate_subtotal(price, quantity)

if __name__ == '__main__':
    unittest.main()

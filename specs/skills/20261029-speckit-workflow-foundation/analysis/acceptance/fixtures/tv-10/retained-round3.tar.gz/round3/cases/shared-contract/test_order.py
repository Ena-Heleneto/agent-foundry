"""T001的小计验收，不实现被测业务。"""
import unittest
import order


class SubtotalTests(unittest.TestCase):
    def test_subtotal(self):
        self.assertTrue(callable(getattr(order, 'calculate_subtotal', None)), '缺少订单小计实现')
        for price, quantity, expected in [(1250, 3, 3750), (0, 3, 0), (1250, 0, 0), (0, 0, 0)]:
            with self.subTest(price=price, quantity=quantity):
                subtotal = order.calculate_subtotal(price, quantity)
                self.assertEqual(subtotal, expected)
                self.assertIs(type(subtotal), int)

    def test_invalid_inputs(self):
        self.assertTrue(callable(getattr(order, 'calculate_subtotal', None)), '缺少订单小计实现')
        for invalid in [-1, True, False, 1.5, '1', None]:
            for price, quantity in [(invalid, 0), (0, invalid), (invalid, 1), (1, invalid)]:
                with self.subTest(price=price, quantity=quantity):
                    with self.assertRaises(ValueError):
                        order.calculate_subtotal(price, quantity)


if __name__ == '__main__':
    unittest.main()

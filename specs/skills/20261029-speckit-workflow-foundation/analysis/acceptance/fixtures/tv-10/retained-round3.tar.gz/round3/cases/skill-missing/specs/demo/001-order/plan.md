# 示例计划

使用Python标准库，在order.py提供纯函数，以test_order.py验证。T001返回小计，T002以后消费小计并加运费；没有外部系统或新依赖。闭环详情见[mvu.md](mvu.md)。

from pathlib import Path
import json,re,hashlib
BASE=Path('/tmp/foundry-tv10-20261110/round3');SESSIONS=Path('<source-home>/.codex/sessions/2026/11/10');OUT=BASE/'native';OUT.mkdir(exist_ok=True)
PARENT='01a1c538-2440-7892-b774-4eda05b77853';SHARED='01a1c56f-a390-7172-931f-e701b5b77383'
def strings(v):
 if isinstance(v,dict):
  for x in v.values():yield from strings(x)
 elif isinstance(v,list):
  for x in v:yield from strings(x)
 elif isinstance(v,str):
  yield v
  for m in re.finditer(r'(?m)^\{',v):
   try:d,_=json.JSONDecoder().raw_decode(v[m.start():])
   except ValueError:continue
   yield from strings(d)
def sanitize(e):
 e=json.loads(json.dumps(e));v=e.get('payload',{})
 if v.get('type')=='function_call' and v.get('name') in ['spawn_agent','send_message','followup_task']:
  try:
   args=json.loads(v['arguments']);msg=args.pop('message',None)
   if msg is not None:args['host_encrypted_message_omitted_sha256']=hashlib.sha256(msg.encode()).hexdigest()
   v['arguments']=json.dumps(args,ensure_ascii=False)
  except ValueError:pass
 return e
records=[]
for p in SESSIONS.glob('*.jsonl'):
 with p.open() as f:
  try:meta=json.loads(f.readline(65536)).get('payload',{})
  except ValueError:continue
 source=meta.get('source');child=source.get('subagent',{}).get('thread_spawn',{}) if isinstance(source,dict) else {}
 if meta.get('id') not in [PARENT,SHARED] and child.get('parent_thread_id')!=PARENT:continue
 es=[json.loads(l) for l in p.open()]
 if child:
  cut=max(i for i,e in enumerate(es) if e.get('type')=='event_msg' and e.get('payload',{}).get('type')=='task_started');es=es[cut:]
 else:es=[e for e in es if e.get('timestamp','')>='2026-11-10T12:29:00']
 keep=[]
 for e in es:
  v=e.get('payload',{});kind=v.get('type')
  if e.get('type')=='response_item' and kind in ['function_call','function_call_output','custom_tool_call','custom_tool_call_output']:keep.append(sanitize(e))
  elif e.get('type')=='event_msg' and kind in ['task_started','task_complete']:keep.append(e)
 out=OUT/(meta['id']+'.jsonl');out.write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in keep))
 text='\n'.join(s for e in keep if e.get('payload',{}).get('type') in ['function_call_output','custom_tool_call_output'] for s in strings(e['payload'].get('output','')))
 rec={'thread_id':meta['id'],'source_file':p.name,'retained':str(out.relative_to(BASE)),'parent_thread_id':child.get('parent_thread_id'),'agent_path':child.get('agent_path'),'events':len(keep),'candidate_full_text_read':Path('<source-workspace>/specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/tv-10/candidate/implementation-preparation/SKILL.md').read_text() in text,'governance_full_text_read':Path('<source-workspace>/.specify/memory/constitution.md').read_text() in text,'task_started':[e['timestamp'] for e in keep if e.get('payload',{}).get('type')=='task_started'],'task_complete':[e['timestamp'] for e in keep if e.get('payload',{}).get('type')=='task_complete']}
 records.append(rec)
(BASE/'native-index.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n');print(json.dumps(records,ensure_ascii=False,indent=2))

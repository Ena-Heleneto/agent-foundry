"""T002 的整数分总额及小计衔接验收。"""
import unittest

import order
import shipping


class ShippingTests(unittest.TestCase):
    def test_total(self):
        self.assertTrue(callable(getattr(shipping, 'calculate_total', None)), '缺少总额实现')
        for subtotal, shipping_cents, expected in [
            (3750, 500, 4250), (0, 0, 0), (3750, 0, 3750), (0, 500, 500)
        ]:
            with self.subTest(subtotal=subtotal, shipping_cents=shipping_cents):
                total = shipping.calculate_total(subtotal, shipping_cents)
                self.assertEqual(total, expected)
                self.assertIs(type(total), int)

    def test_subtotal_integration(self):
        self.assertTrue(callable(getattr(shipping, 'calculate_total', None)), '缺少总额实现')
        subtotal = order.calculate_subtotal(1250, 3)
        self.assertEqual(shipping.calculate_total(subtotal, 500), 4250)

    def test_invalid_inputs(self):
        self.assertTrue(callable(getattr(shipping, 'calculate_total', None)), '缺少总额实现')
        for invalid in [True, False, -1, 1.5, 1.0, '1', None]:
            for subtotal, shipping_cents in [(invalid, 0), (0, invalid), (invalid, 1), (1, invalid)]:
                with self.subTest(subtotal=subtotal, shipping_cents=shipping_cents):
                    with self.assertRaises(ValueError):
                        shipping.calculate_total(subtotal, shipping_cents)


if __name__ == '__main__':
    unittest.main()

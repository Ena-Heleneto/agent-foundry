from pathlib import Path
import json,re,hashlib,datetime,subprocess
BASE=Path('/tmp/foundry-tv10-20261110/round3');REPO=Path('<source-workspace>');FD=REPO/'specs/skills/20261029-speckit-workflow-foundation'
def events(name):return [json.loads(x) for x in (BASE/'raw'/name/'events.jsonl').read_text().splitlines()]
def result(name):return json.loads((BASE/'raw'/name/'result.json').read_text())
def outputs(name):return '\n'.join(e.get('item',{}).get('aggregated_output','') for e in events(name) if e['type']=='item.completed')
def complete(name):
 r=result(name);assert r['exit']==0 and not r['timeout'] and r['turn_completed'],r;return r
checks={}
for name in ['yaml-broken','skill-missing','skill-unreadable-actual','skill-outdated','shared-save','continuous-parallel-recovery']:
 r=complete(name);business=[f for f in r['changed'] if f in ['order.py','shipping.py','test_order.py','test_shipping.py']];assert not business,(name,business)
 assert r['markers']==({'T001':'x','T002':' '} if name=='continuous-parallel-recovery' else {'T001':' ','T002':' '})
 checks[name]={'complete':True,'no_business_change':True,'markers':r['markers'],'elapsed_seconds':r['elapsed_seconds']}
assert 'YAML parser error' in outputs('yaml-broken') and 'expected the node content' in outputs('yaml-broken')
assert 'Permission denied' in outputs('skill-unreadable-actual') or 'Permission denied' in (BASE/'raw/skill-unreadable-actual/stderr.log').read_text()
assert '0.0.1' in outputs('skill-outdated')
failed=[i+1 for i,e in enumerate(events('shared-save')) if e.get('item',{}).get('type')=='file_change' and e['item'].get('status')=='failed' and any(c['path'].endswith('/implementation/T001.md') for c in e['item']['changes'])];assert failed;checks['shared-save']['actual_failed_write_events']=failed
r=complete('shared-recovery');assert r['markers']=={'T001':'x','T002':' '};assert 'order.py' in r['changed'] and 'shipping.py' not in r['changed']
es=events('shared-recovery');business_write=min(i for i,e in enumerate(es) if e.get('item',{}).get('type')=='file_change' and any(c['path'].endswith('/order.py') for c in e['item']['changes']))
plan_reads=[i for i,e in enumerate(es) if e.get('item',{}).get('type')=='command_execution' and e['type']=='item.completed' and 'implementation/T001.md' in e['item'].get('command','') and e['item'].get('exit_code')==0 and '共同' in e['item'].get('aggregated_output','')]
assert any(i<business_write for i in plan_reads);assert 'check_markdown.py' in '\n'.join(e.get('item',{}).get('command','') for e in es[:business_write])
checks['shared-recovery']={'complete':True,'plan_read_before_business_event':min(plan_reads)+1,'first_business_write_event':business_write+1,'markers':r['markers'],'elapsed_seconds':r['elapsed_seconds']}
native=json.loads((BASE/'native-index.json').read_text());children=[r for r in native if r['parent_thread_id']=='01a1c538-2440-7892-b774-4eda05b77853'];assert len(children)==2
for c in children:assert c['candidate_full_text_read'] and c['governance_full_text_read'] and c['task_complete']
assert max(c['task_started'][0] for c in children)<min(c['task_complete'][-1] for c in children)
checks['parallel']={'same_parent':True,'branches_overlap':True,'each_full_candidate_and_governance':True,'branch_ids':[c['thread_id'] for c in children]}
if (BASE/'raw/shared-substantive-close/result.json').exists():
 first=result('shared-substantive');r=complete('shared-substantive-close')
 for current in [first,r]:
  assert current['markers']=={'T001':'x','T002':' '};assert not set(current['changed'])&{'order.py','shipping.py','test_order.py','test_shipping.py'}
 msgs='\n'.join(e.get('item',{}).get('text','') for name in ['shared-substantive','shared-substantive-close'] for e in events(name));assert 'T001' in msgs and 'T002' in msgs and ('确认' in msgs or '认可' in msgs)
 checks['substantive']={'complete':True,'first_turn_timed_out_not_passed':first['timeout'],'closure_turn_completed':True,'no_business_change_across_both':True,'completed_A_preserved':True,'B_pending':True,'closure_elapsed_seconds':r['elapsed_seconds']}
if (BASE/'raw/shared-finish/result.json').exists():
 r=complete('shared-finish');assert r['markers']=={'T001':'x','T002':'x'};assert 'order.py' not in r['changed'];assert 'shipping.py' in r['changed'];checks['shared-finish']={'complete':True,'completed_A_unchanged':True,'B_implemented':True,'elapsed_seconds':r['elapsed_seconds']}
checks['candidate_source_sha256']=hashlib.sha256((FD/'analysis/acceptance/fixtures/tv-10/candidate/implementation-preparation/SKILL.md').read_bytes()).hexdigest()
assert checks['candidate_source_sha256']=='ff0ec4893d2bc280c181ea0f0f8b8c925f6a04fd3dbaae791b55eb9713da4521'
checks['ready_to_complete_T103']=all(k in checks for k in ['substantive','shared-finish'])
(BASE/'audit-results.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n');print(json.dumps(checks,ensure_ascii=False,indent=2))

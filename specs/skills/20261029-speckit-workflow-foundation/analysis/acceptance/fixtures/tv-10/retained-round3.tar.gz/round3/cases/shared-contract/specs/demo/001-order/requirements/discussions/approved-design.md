# 新样例的实际共同认可方案

用户通过[joint-approval.json](joint-approval.json)的实际异步回执认可本项目T001和T002；这是一轮共同讨论认可，每个Task仍须独立保存implementation方案并由tasks引用，成功格式检查和完整读回后实施。

T001在order.py实现calculate_subtotal(unit_price_cents, quantity)，两参数为非负整数，bool及其他非法输入抛ValueError，返回整数乘积；1250×3=3750，零值为0。T002在shipping.py实现calculate_total(subtotal_cents, shipping_cents)，两参数为非负整数分，bool及其他非法输入抛ValueError，返回整数和；3750+500=4250，零值为0。两者共享同一非负整数分定义，B接受A的计算结果，职责分别保留。可按同一逻辑采用局部校验函数，不改变API/验收。

先核对本项目材料与代码，在各自方案中说明实现理由、认可范围与来源，保存/检查/读回并维护引用，然后按Task实现。用Python标准库unittest独立验证普通、零值、两参数的负数/布尔/浮点/字符串/None等非法输入；T002另验证A结果衔接。无新依赖或外部系统。本次实施请求逐项指定，不能把共同认可当两Task自动完成。

from pathlib import Path
import sys
for name in sys.argv[1:]:
 p=Path(name); raw=p.read_bytes(); raw.decode('utf-8'); assert b'\r' not in raw; assert raw.endswith(b'\n'); print('Markdown格式通过:',name)

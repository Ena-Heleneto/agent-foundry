from pathlib import Path
import sys,os,subprocess,json,hashlib,time,datetime,signal,threading,concurrent.futures,shutil,contextlib,io,re
BASE=Path('/tmp/foundry-tv10-20261110'); OUT=BASE/'round3'; REPO=Path('<source-workspace>'); FD=REPO/'specs/skills/20261029-speckit-workflow-foundation'
sys.path.insert(0,str(BASE))
from install_case import install,OFFICIAL,SPECIFY,CANDIDATE
def snapshot(project):
 result={}
 for p in project.rglob('*'):
  rel=p.relative_to(project)
  if not p.is_file() or '.git' in rel.parts or '__pycache__' in rel.parts:continue
  try:result[str(rel)]=hashlib.sha256(p.read_bytes()).hexdigest()
  except OSError as error:result[str(rel)]='UNREADABLE:'+type(error).__name__
 return result
PYTHON='<source-home>/.cache/uv/archive-v0/FFsdlmKBeESY_-Br/bin/python'
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def setup(name):
 with contextlib.redirect_stdout(io.StringIO()): p=install('r3-'+name)
 target=OUT/'cases'/name;target.parent.mkdir(exist_ok=True);p.rename(target)
 # Official extension paths remain the original registered source, which still exists.
 (target/'AGENTS.md').write_text('''# 示例工程约定

使用Python标准库；命令为python3 -B -m unittest -v。保留原任务身份与其他Task的目标。
YAML工具可用<source-home>/.cache/uv/archive-v0/FFsdlmKBeESY_-Br/bin/python，该运行时已有PyYAML。
Markdown格式检查使用python3 -B tools/check_markdown.py <文件>，核对UTF-8、LF及末尾换行；检查后完整读回。
''')
 tools=target/'tools';tools.mkdir();(tools/'check_markdown.py').write_text('''from pathlib import Path
import sys
for name in sys.argv[1:]:
 p=Path(name); raw=p.read_bytes(); raw.decode('utf-8'); assert b'\\r' not in raw; assert raw.endswith(b'\\n'); print('Markdown格式通过:',name)
''')
 return target

def run(label,project,prompt,resume=None,persist=False):
 raw=OUT/'raw'/label;raw.mkdir(parents=True,exist_ok=False)
 (raw/'input.txt').write_text(prompt+'\n');before=snapshot(project);(raw/'before.json').write_text(json.dumps(before,indent=2)+'\n')
 args=['codex','exec',*(['resume','--json','-o',str(raw/'final.txt'),resume,'-'] if resume else ['--json',*([] if persist else ['--ephemeral']),'--cd',str(project),'--sandbox','workspace-write','--color','never','-o',str(raw/'final.txt'),'-'])]
 started=utc();start=time.monotonic();timed=False;events=[]
 with (raw/'events.jsonl').open('w') as out,(raw/'timing.jsonl').open('w') as timing,(raw/'stderr.log').open('w') as err:
  p=subprocess.Popen(args,cwd=project,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,start_new_session=True)
  def drain():
   for line in p.stdout:
    out.write(line);out.flush()
    try:e=json.loads(line);events.append(e)
    except ValueError:continue
    i=e.get('item',{});timing.write(json.dumps({'at':utc(),'elapsed':round(time.monotonic()-start,3),'type':e.get('type'),'id':i.get('id'),'item_type':i.get('type'),'command':i.get('command'),'exit_code':i.get('exit_code')},ensure_ascii=False)+'\n');timing.flush()
  reader=threading.Thread(target=drain);reader.start();p.stdin.write(prompt+'\n');p.stdin.close()
  try:p.wait(timeout=240)
  except subprocess.TimeoutExpired:
   timed=True;os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  reader.join(timeout=10)
 after=snapshot(project);changed=[x for x in sorted(before.keys()|after.keys()) if before.get(x)!=after.get(x)]
 task=project/'specs/demo/001-order/tasks.md';markers={k:v.lower() for v,k in re.findall(r'^- \[([ xX])\] (T\d{3})\b',task.read_text(),re.M)}
 result={'case':label,'project':str(project),'started':started,'ended':utc(),'elapsed_seconds':round(time.monotonic()-start,3),'exit':p.returncode,'timeout':timed,'turn_completed':any(e.get('type')=='turn.completed' for e in events),'events':len(events),'thread_id':next((e.get('thread_id') for e in events if e.get('type')=='thread.started'),None),'changed':changed,'markers':markers}
 (raw/'after.json').write_text(json.dumps(after,indent=2)+'\n');(raw/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(result,ensure_ascii=False),flush=True);return result

def setup_batch():
 cases={}
 for name in ['yaml-broken','skill-missing','skill-unreadable','skill-outdated']:
  p=setup(name);cases[name]=p
  if name=='yaml-broken':(p/'.specify/extensions.yml').write_text('hooks:\n  before_implement: [\n')
  elif name=='skill-missing':shutil.rmtree(p/'.agents/skills/implementation-preparation')
  elif name=='skill-unreadable':(p/'.agents/skills/implementation-preparation/SKILL.md').chmod(0)
  elif name=='skill-outdated':
   source=OUT/'outdated-source/implementation-preparation';source.mkdir(parents=True)
   (source/'SKILL.md').write_text('---\nname: implementation-preparation\ndescription: 用户在Spec Kit项目实施Task时使用。\nmetadata:\n  version: "0.0.1"\n---\n\n# 旧版实施准备\n\n读取总体plan后安排实现步骤；本历史版本尚未支持单Task方案及恢复。\n')
   (p/'project-notes.md').write_text('# 安装版本说明\n\n当前implementation-preparation为历史0.0.1安装，尚未刷新到本Spec已采用的逐Task方案/恢复版本；候选新版本位于同一测试来源。本轮不自动安装其他来源。\n')
   with (p/'AGENTS.md').open('a') as f:f.write('\n工程安装版本信息见project-notes.md。\n')
   env={**os.environ,'XDG_STATE_HOME':str(OUT/'state'),'DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','PYTHONDONTWRITEBYTECODE':'1'}
   with (OUT/'outdated-install.log').open('w') as log:subprocess.run(['node',str(OFFICIAL),'add',str(source),'--skill','implementation-preparation','--agent','codex','--copy','--yes'],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=30)
 (OUT/'batch-cases.json').write_text(json.dumps({k:str(v) for k,v in cases.items()},indent=2)+'\n')
 return cases

def setup_shared():
 p=setup('shared-contract');f=p/'specs/demo/001-order'
 (p/'shipping.py').write_text('"""含运费总额。"""\n')
 (f/'tasks.md').write_text((f/'tasks.md').read_text().replace('在order.py实现calculate_total','在shipping.py实现calculate_total'))
 (f/'plan.md').write_text('# 示例计划\n\n使用Python标准库；T001在order.py计算小计，T002在shipping.py接受小计整数分与运费，返回总额。两者共用非负整数分含义，各自可用局部校验函数。以unittest按Task验收；闭环见[mvu.md](mvu.md)。\n')
 d=f/'requirements/discussions';d.mkdir(parents=True,exist_ok=True)
 approval={'source':'本父会话实际异步回执','date':'2026-11-10','questionItemId':'["request_user_input_async","call_8204484040364f9bb9d527eaf43d1d07",0]','answer':'认可该新示例的两个 Task 方案','project':str(p),'spec':'specs/demo/001-order','tasks':{'T001':'order.py: calculate_subtotal，非负整数分单价乘非负整数数量，排除bool，非法抛ValueError','T002':'shipping.py: calculate_total，非负整数分小计加非负整数分运费，排除bool，非法抛ValueError'},'scope':'两Task分别保存格式检查读回后实施，通过各自unittest才勾选；允许同逻辑局部校验函数','exclusions':['旧positive-a的T002','T103整体验收','T104']}
 (d/'joint-approval.json').write_text(json.dumps(approval,ensure_ascii=False,indent=2)+'\n')
 (d/'approved-design.md').write_text('''# 新样例的实际共同认可方案

用户通过[joint-approval.json](joint-approval.json)的实际异步回执认可本项目T001和T002；这是一轮共同讨论认可，每个Task仍须独立保存implementation方案并由tasks引用，成功格式检查和完整读回后实施。

T001在order.py实现calculate_subtotal(unit_price_cents, quantity)，两参数为非负整数，bool及其他非法输入抛ValueError，返回整数乘积；1250×3=3750，零值为0。T002在shipping.py实现calculate_total(subtotal_cents, shipping_cents)，两参数为非负整数分，bool及其他非法输入抛ValueError，返回整数和；3750+500=4250，零值为0。两者共享同一非负整数分定义，B接受A的计算结果，职责分别保留。可按同一逻辑采用局部校验函数，不改变API/验收。

先核对本项目材料与代码，在各自方案中说明实现理由、认可范围与来源，保存/检查/读回并维护引用，然后按Task实现。用Python标准库unittest独立验证普通、零值、两参数的负数/布尔/浮点/字符串/None等非法输入；T002另验证A结果衔接。无新依赖或外部系统。本次实施请求逐项指定，不能把共同认可当两Task自动完成。
''')
 (p/'test_shipping.py').write_text('''import unittest
import shipping
import order
class ShippingTests(unittest.TestCase):
 def test_total(self):
  self.assertTrue(callable(getattr(shipping,'calculate_total',None)))
  self.assertEqual(shipping.calculate_total(3750,500),4250)
  self.assertEqual(shipping.calculate_total(0,0),0)
  self.assertEqual(shipping.calculate_total(order.calculate_subtotal(1250,3),500),4250)
  for x in [True,False,-1,1.5,'1',None]:
   for args in [(x,0),(0,x)]:
    with self.assertRaises(ValueError):shipping.calculate_total(*args)
''')
 # The implementation directory is a fault fixture: saving there must encounter a real access error.
 impl=f/'implementation';impl.mkdir();impl.chmod(0o555)
 return p

if __name__=='__main__':
 action=sys.argv[1]
 if action=='setup':
  c=setup_batch();s=setup_shared();print(json.dumps({'cases':{k:str(v) for k,v in c.items()},'shared':str(s)},ensure_ascii=False))
 elif action=='batch':
  c=json.loads((OUT/'batch-cases.json').read_text())
  with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
   jobs=[pool.submit(run,name,Path(p),'$speckit-implement specs/demo/001-order T001。') for name,p in c.items()]
   for j in concurrent.futures.as_completed(jobs):j.result()
 elif action=='one':
  name=sys.argv[2];run(name+'-actual',OUT/'cases'/name,'$speckit-implement specs/demo/001-order T001。')
 elif action=='shared':run('shared-save',OUT/'cases/shared-contract','$speckit-implement specs/demo/001-order T001。实际共同认可与方案在requirements/discussions/approved-design.md及其引用回执。先完成T001。',persist=True)
 elif action=='shared-recover':run('shared-recovery',OUT/'cases/shared-contract','实施目录的受控权限故障已修复。继续原T001，复用已有真实共同认可；核对T002的准备情况，当前只实施T001。',resume=json.loads((OUT/'raw/shared-save/result.json').read_text())['thread_id'])
 elif action=='shared-change':run('shared-substantive',OUT/'cases/shared-contract','继续T002，按最新spec中的金额单位变更处理。',resume=json.loads((OUT/'raw/shared-save/result.json').read_text())['thread_id'])
 elif action=='shared-close':run('shared-substantive-close',OUT/'cases/shared-contract','继续上一轮T002。请完成当前轮必要的保存、格式检查和读回后给出实际结果；遇到待确认事项只报告后结束，不等待交互输入，不再扩写其他方案或新增资料。',resume=json.loads((OUT/'raw/shared-save/result.json').read_text())['thread_id'])
 elif action=='shared-finish':run('shared-finish',OUT/'cases/shared-contract','临时浮点元变更已撤回，spec已恢复；真实共同认可的整数分方案继续有效。核对T001最终代码与原方案，保持其完成事实，再完成T002。只维护已有方案、引用和必要验收记录，不扩写新报告；需用户回复的事项只报告后结束，不等待交互输入。',resume=json.loads((OUT/'raw/shared-save/result.json').read_text())['thread_id'])
 elif action=='resume':run('continuous-recovery',BASE/'cases/positive-a','继续上次的 T001，然后接着实现 specs/demo/001-order/tasks.md 中的 T002。',resume='01a1c538-2440-7892-b774-4eda05b77853')
 elif action=='resume-parallel':run('continuous-parallel-recovery',BASE/'cases/positive-a','续接原T001，再使用当前宿主的真实并行工作分支，分别处理T001与T002，按各自现有材料推进并汇总。若需要用户回复，只报告待确认事项并结束本回合，不等待交互输入；不模拟回复。共享tasks由主会话汇总。',resume='01a1c538-2440-7892-b774-4eda05b77853')
 elif action=='parallel':run('parallel-boundary',BASE/'cases/positive-a','使用当前宿主的真实并行工作分支，分别处理 specs/demo/001-order 的 T001 和 T002，按各自现有材料推进并汇总各分支结果。两个分支只各自处理指定Task，不同时改共享文件；共同tasks由主会话汇总。')

# 示例计划

使用Python标准库；T001在order.py计算小计，T002在shipping.py接受小计整数分与运费，返回总额。两者共用非负整数分含义，各自可用局部校验函数。以unittest按Task验收；闭环见[mvu.md](mvu.md)。

2026-11-10 恢复核对：浮点元变更已撤回，spec 已恢复，以上整数分方案继续有效；
撤回依据见[原讨论记录](requirements/discussions/amount-unit-change.md#测试变更撤回)及本轮用户指令。
保留 T001 完成事实，T002 按既有独立方案消费整数分小计。

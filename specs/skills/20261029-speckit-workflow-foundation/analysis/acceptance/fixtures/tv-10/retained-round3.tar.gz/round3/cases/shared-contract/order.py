"""订单运算示例模块。"""


def _validate_non_negative_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f'{name} must be a non-negative integer')


def calculate_subtotal(unit_price_cents, quantity):
    """返回整数分小计；非法单价或数量抛 ValueError。"""
    _validate_non_negative_integer(unit_price_cents, 'unit_price_cents')
    _validate_non_negative_integer(quantity, 'quantity')
    return unit_price_cents * quantity

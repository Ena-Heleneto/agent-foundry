"""含运费总额。"""


def _validate_non_negative_integer(value, name):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f'{name} must be a non-negative integer')


def calculate_total(subtotal_cents, shipping_cents):
    """返回含运费的整数分总额；非法金额抛 ValueError。"""
    _validate_non_negative_integer(subtotal_cents, 'subtotal_cents')
    _validate_non_negative_integer(shipping_cents, 'shipping_cents')
    return subtotal_cents + shipping_cents

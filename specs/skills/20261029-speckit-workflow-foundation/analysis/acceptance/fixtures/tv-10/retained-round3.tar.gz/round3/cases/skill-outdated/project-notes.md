# 安装版本说明

当前implementation-preparation为历史0.0.1安装，尚未刷新到本Spec已采用的逐Task方案/恢复版本；候选新版本位于同一测试来源。本轮不自动安装其他来源。

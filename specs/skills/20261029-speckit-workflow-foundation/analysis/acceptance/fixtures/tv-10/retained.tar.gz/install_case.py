from pathlib import Path
import subprocess,os,json,shutil,hashlib,sys
from prepare_case import prepare,ROOT

CANDIDATE=Path('<source-workspace>/specs/skills/20261029-speckit-workflow-foundation/analysis/acceptance/fixtures/tv-10/candidate/implementation-preparation')
OFFICIAL=ROOT/'npm-cache/_npx/0757c8f0298e564a/node_modules/skills/bin/cli.mjs'
SPECIFY='<source-home>/.cache/uv/archive-v0/FFsdlmKBeESY_-Br/bin/specify'

def install(name,constitution=True,hook=True):
    project=prepare(name,constitution)
    raw=ROOT/'raw'/f'{name}-setup'; raw.mkdir(parents=True)
    env={**os.environ,'XDG_STATE_HOME':str(ROOT/'official-state'/name),'DO_NOT_TRACK':'1','DISABLE_TELEMETRY':'1','NO_COLOR':'1','CI':'1','PYTHONDONTWRITEBYTECODE':'1'}
    args=['node',str(OFFICIAL),'add',str(CANDIDATE),'--skill','implementation-preparation','--agent','codex','--copy','--yes']
    with (raw/'skills-add.log').open('w') as out:
        result=subprocess.run(args,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=60)
    if result.returncode:
        print((raw/'skills-add.log').read_text()[-1800:]); raise RuntimeError('官方来源安装失败')
    installed=project/'.agents/skills/implementation-preparation'
    source={str(p.relative_to(CANDIDATE)):hashlib.sha256(p.read_bytes()).hexdigest() for p in CANDIDATE.rglob('*') if p.is_file()}
    actual={str(p.relative_to(installed)):hashlib.sha256(p.read_bytes()).hexdigest() for p in installed.rglob('*') if p.is_file()}
    assert source==actual,(source,actual)
    native=project/'.agents/skills/speckit-implement/SKILL.md'
    seed_native=ROOT/'seed/.agents/skills/speckit-implement/SKILL.md'
    assert native.read_bytes()==seed_native.read_bytes()
    if hook:
        extension=ROOT/'extensions'/name; (extension/'skills').mkdir(parents=True)
        shutil.copytree(CANDIDATE,extension/'skills/implementation-preparation')
        manifest={'schema_version':'1.0','extension':{'id':'implementation-preparation','name':'Implementation Preparation','version':'0.1.0','description':'T103隔离候选'},'requires':{'speckit_version':'==1.2.6'},'provides':{},'hooks':json.loads((CANDIDATE/'speckit-hooks.json').read_text())}
        if name=='hook-disabled': manifest['hooks']['before_implement'][0]['enabled']=False
        conditions={'condition-true':'true','condition-false':'false','condition-illegal':'not valid ['}
        if name in conditions: manifest['hooks']['before_implement'][0]['condition']=conditions[name]
        (extension/'extension.yml').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
        with (raw/'extension-add.log').open('w') as out:
            result=subprocess.run([SPECIFY,'extension','add','--dev',str(extension),'--force'],cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=60)
        if result.returncode:
            print((raw/'extension-add.log').read_text()[-1800:]); raise RuntimeError('官方hook登记失败')
    assert native.read_bytes()==seed_native.read_bytes()
    proof={'project':str(project),'governance':constitution,'hook':hook,'source':str(CANDIDATE),'installed':str(installed),'source_and_installed_hashes':source,'native_implement_sha256':hashlib.sha256(native.read_bytes()).hexdigest(),'official_skills_version':'1.7.4','specify_version':'1.2.6'}
    (raw/'installed-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False,indent=2),flush=True)
    return project

if __name__=='__main__':
    install(sys.argv[1],constitution='--no-constitution' not in sys.argv,hook='--no-hook' not in sys.argv)

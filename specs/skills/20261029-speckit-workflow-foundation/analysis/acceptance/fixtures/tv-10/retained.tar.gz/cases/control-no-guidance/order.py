"""订单运算示例模块。"""


def calculate_subtotal(unit_price_cents, quantity):
    """返回整数分小计；参数必须是非负整数，且不能是布尔值。"""
    for value in (unit_price_cents, quantity):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError("单价和数量必须是非负整数，且不能是布尔值")
    return unit_price_cents * quantity

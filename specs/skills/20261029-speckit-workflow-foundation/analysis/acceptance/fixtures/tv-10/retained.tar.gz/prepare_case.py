from pathlib import Path
import shutil,subprocess,json

ROOT=Path('/tmp/foundry-tv10-20261110')

def prepare(name,constitution=False):
    project=ROOT/'cases'/name
    if project.exists():
        raise RuntimeError(f'拒绝覆盖既有场景：{project}')
    shutil.copytree(ROOT/'seed',project,ignore=shutil.ignore_patterns('.git'))
    subprocess.run(['git','-C',str(project),'init','--quiet'],check=True)
    governance=project/'.specify/memory/constitution.md'
    if constitution:
        shutil.copyfile('<source-workspace>/.specify/memory/constitution.md',governance)
    else:
        governance.unlink()
    feature=project/'specs/demo/001-order'; feature.mkdir(parents=True)
    (project/'.specify/feature.json').write_text(json.dumps({'feature_directory':'specs/demo/001-order'})+'\n')
    (feature/'spec.md').write_text('# 订单运算示例\n\n金额使用非负整数分，数量使用非负整数。先计算小计，再计算含运费总额。\n')
    (feature/'plan.md').write_text('# 示例计划\n\n使用Python标准库，在order.py提供纯函数，以test_order.py验证。T001返回小计，T002以后消费小计并加运费；没有外部系统或新依赖。闭环详情见[mvu.md](mvu.md)。\n')
    (feature/'mvu.md').write_text('# 示例闭环\n\n小计正确：T001负责单价乘数量，测试零值与普通订单；总额正确：T002以后消费小计加运费，须各自满足原Task验收。\n')
    (feature/'tasks.md').write_text('# 示例任务\n\n- [ ] T001 在order.py实现calculate_subtotal(unit_price_cents, quantity)，输入为非负整数，返回整数分小计；非整数、布尔或负数抛ValueError。只实现本Task，按test_order.py验收。\n- [ ] T002 在order.py实现calculate_total(subtotal_cents, shipping_cents)，返回加运费后的整数分总额；依赖T001的小计结果，后续按自己的方案及验收推进。\n')
    (project/'order.py').write_text('"""订单运算示例模块。"""\n')
    (project/'test_order.py').write_text('''"""T001的小计验收，不实现被测业务。"""
import unittest
import order

class SubtotalTests(unittest.TestCase):
    def test_subtotal(self):
        self.assertTrue(callable(getattr(order, 'calculate_subtotal', None)), '缺少订单小计实现')
        self.assertEqual(order.calculate_subtotal(1250, 3), 3750)
        self.assertEqual(order.calculate_subtotal(0, 3), 0)
        self.assertEqual(order.calculate_subtotal(1250, 0), 0)
        for price, quantity in [(-1, 1), (1, -1), (1.5, 2), (1, True), ('1', 2)]:
            with self.assertRaises(ValueError):
                order.calculate_subtotal(price, quantity)

if __name__ == '__main__':
    unittest.main()
''')
    (project/'AGENTS.md').write_text('# 示例工程约定\n\n使用Python标准库；命令为python3 -B -m unittest -v。保留原任务身份与其他Task的目标。\n')
    return project

if __name__=='__main__':
    p=prepare('control-no-guidance',False)
    print(p)

"""T063 正式来源实际宿主回合；保留原始输入、事件、文件变化和真实超时。"""
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
FEATURE = 'specs/skills/001-workflow'
PROMPTS = {'after-tasks': ('flow', '$speckit-tasks specs/skills/001-workflow。隔离项目已有保存并检查的任务，本轮只从该原生入口Mandatory Post-Execution Hooks阶段继续，完成实际后置动作和结果核查；不重新生成任务，不改工程完成标记或实施业务。'), 'increment': ('flow', '$task-increment Spec:specs/skills/001-workflow。以下仅为T063隔离验证指令，不是父用户新增需求或业务认可：在既有有效范围内，先让读者看清小业务结果与原Task职责，再验证Implement契约；将T006资料规划推荐放在T007/T002之前，保留T007对T002及实际挂载的必要前置、T008独立资料与目标缺失边界、三模式暂停和T009末尾收尾。只调整必要规划并完成后续步骤，不实施业务。'), 'after-tasks-finish': ('flow', '上轮在宿主限时结束。沿真实同一会话和实际文件只补原后置分析范围的必要保存、格式/引用核查与回执；不重做任务生成、不改工程完成标记、不扩大授权。'), 'increment-finish': ('flow', '上轮在宿主限时结束。沿真实同一会话和已保存文件补完原局部规划及分析的核查、必要保存与结果报告，保留原身份/证据，不重建任务或实施业务。')}


def snapshot(project):
    return {
        str(p.relative_to(project)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted(project.rglob('*'))
        if p.is_file() and '.git' not in p.parts and '__pycache__' not in p.parts
    }

def run(stage):
    name, prompt = PROMPTS[stage]
    project = ROOT / 'cases' / name
    out = ROOT / 'host' / stage
    if out.exists():
        out.rename(ROOT / 'host' / (stage + '-environment-first'))
    out.mkdir(parents=True, exist_ok=False)
    args = ['codex', 'exec', '--cd', str(project), '--sandbox', 'workspace-write']
    previous = {'after-tasks-finish': 'after-tasks', 'increment-finish': 'increment'}.get(stage)
    if previous:
        prior = json.loads((ROOT / 'host' / previous / 'result.json').read_text())
        assert prior['session_id'] and prior['timeout'], prior
        args += ['resume', '--json', '--output-last-message', str(out / 'final.txt'), prior['session_id'], '-']
    else:
        args += ['--json', '--color', 'never', '--output-last-message', str(out / 'final.txt'), '-']
    (out / 'input.txt').write_text(prompt + '\n')
    before = snapshot(project)
    (out / 'before.json').write_text(json.dumps(before, indent=2) + '\n')
    start = time.monotonic()
    env = {**os.environ, 'SPECIFY_FEATURE_DIRECTORY': FEATURE}
    with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
        process = subprocess.Popen(args, cwd=project, env=env, stdin=subprocess.PIPE, stdout=stdout, stderr=stderr, text=True, start_new_session=True)
        timeout = False
        try:
            process.communicate(prompt + '\n', timeout=240)
        except subprocess.TimeoutExpired:
            timeout = True
            os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
    session = None
    for line in (out / 'events.jsonl').read_text().splitlines():
        try:
            event = json.loads(line)
            if event.get('type') == 'thread.started':
                session = event['thread_id']
        except json.JSONDecodeError:
            pass
    after = snapshot(project)
    (out / 'after.json').write_text(json.dumps(after, indent=2) + '\n')
    result = {'stage': stage, 'project': str(project), 'exit': process.returncode, 'timeout': timeout, 'elapsed_seconds': round(time.monotonic() - start, 3), 'session_id': session, 'args': args, 'changed': [k for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)], 'model_override': False}
    (out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(result, ensure_ascii=False), flush=True)
    if (out / 'final.txt').exists():
        print((out / 'final.txt').read_text()[:1800], flush=True)
    if process.returncode:
        print((out / 'stderr.log').read_text()[-1400:], flush=True)
    return process.returncode == 0 and not timeout

if __name__ == '__main__':
    raise SystemExit(0 if run(sys.argv[1]) else 1)

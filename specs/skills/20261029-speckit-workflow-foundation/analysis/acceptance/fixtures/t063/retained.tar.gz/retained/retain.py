"""归档正式维护源、独立隔离项目、原始安装与宿主证据，不纳入画像。"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('<source-workspace>')
FEATURE = Path('specs/skills/20261029-speckit-workflow-foundation')
DESTINATION = REPO / FEATURE / 'analysis/acceptance/fixtures/t063'
STAGE = ROOT / 'retained'
report = json.loads((ROOT / 'host-audit.json').read_text())
finish = report['stages'].get('increment-finish')
assert finish and finish['exit'] == 0 and not finish['timeout'], '续接尚未完成，不打通过归档'
assert finish['session_id'] == report['stages']['increment']['session_id']
STAGE.mkdir(exist_ok=False)
for name in ['before', 'before-project', 'cases', 'snapshots', 'installations', 'extension-input', 'host']:
    shutil.copytree(ROOT / name, STAGE / name, ignore=shutil.ignore_patterns('.git', '__pycache__'))
for name in ['meta.json', 'formal-input-red.json', 'formal-input-green.json', 'collection.config.json', 'baseline-checks.json', 'final-checks.json', 'host-audit.json', 'review.json', 'prepare.py', 'run.py', 'audit.py', 'retain.py']:
    shutil.copy2(ROOT / name, STAGE / name)
for path in ROOT.glob('*.log'):
    shutil.copy2(path, STAGE / path.name)
shutil.copytree(REPO / 'packages/skills/src/workflow/artifact-spec-analysis', STAGE / 'formal-source/artifact-spec-analysis')
shutil.copy2(REPO / 'packages/skills/src/workflow/collection.config.json', STAGE / 'formal-source/collection.config.json')
files = [p for p in STAGE.rglob('*') if p.is_file()]
assert not any(p.name == 'profile.md' or 'user-shadow' in p.parts for p in files)
patterns = {'credential_token': rb'(?:ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{25,}|sk-[A-Za-z0-9]{20,})', 'private_key': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----', 'database_uri': rb'mongodb(?:\+srv)?://[^\s<>"\x27]{12,}'}
hits = []
for p in files:
    for name, pattern in patterns.items():
        if re.search(pattern, p.read_bytes()):
            hits.append({'path': str(p.relative_to(STAGE)), 'category': name})
assert not hits, hits
archive = DESTINATION / 'retained.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    tar.add(STAGE, arcname='retained')
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert all(not m.issym() and not m.islnk() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts for m in members)
report['baseline_checks'] = json.loads((ROOT / 'baseline-checks.json').read_text())
report['final_checks'] = json.loads((ROOT / 'final-checks.json').read_text())
report['review'] = json.loads((ROOT / 'review.json').read_text())
report['archive'] = {'path': 'retained.tar.gz', 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'file_count': sum(m.isfile() for m in members), 'member_count': len(members), 'selected_secret_patterns': list(patterns), 'selected_pattern_hits': 0, 'scan_not_exhaustive': True, 'profile_not_in_archive': True}
report['scope_verdict'] = '正式来源/集合声明及隔离消费职责已验证；整包lint仍有原有两项错误，不称全部检查通过。构建按原授权暂跳过，完整接线/T064仍未验。'
(DESTINATION / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['archive'], ensure_ascii=False, indent=2))

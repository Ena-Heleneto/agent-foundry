#!/usr/bin/env bash
# 在 Bash 中准备七项 hooks 输入，由官方 CLI 完成登记与重装。
set -euo pipefail

project_dir=''
skills_dir=''
cli_path=''
while [[ $# -gt 0 ]]; do
  case "$1" in
    --help|-h)
      printf '%s\n' '用法：register-hooks.sh --project <项目> --skills-dir <技能根> [--cli <specify>]'
      exit 0 ;;
    --project|--skills-dir|--cli)
      if [[ $# -lt 2 || -z "$2" || "$2" == --* ]]; then
        printf '参数缺值：%s\n' "$1" >&2
        exit 2
      fi
      case "$1" in
        --project) project_dir="$2" ;;
        --skills-dir) skills_dir="$2" ;;
        --cli) cli_path="$2" ;;
      esac
      shift 2 ;;
    --project=*) project_dir="${1#*=}"; shift ;;
    --skills-dir=*) skills_dir="${1#*=}"; shift ;;
    --cli=*) cli_path="${1#*=}"; shift ;;
    *) printf '未知参数：%s\n' "$1" >&2; exit 2 ;;
  esac
done

if [[ -z "$project_dir" || -z "$skills_dir" ]]; then
  printf '%s\n' '必须提供 --project 和 --skills-dir' >&2
  exit 2
fi
project_dir="$(cd -- "$project_dir" && pwd -P)"
skills_dir="$(cd -- "$skills_dir" && pwd -P)"
if [[ ! -f "$project_dir/.specify/init-options.json" ]]; then
  printf '%s\n' '目标项目尚未初始化 Spec Kit' >&2
  exit 1
fi
specify_version="${FOUNDRY_SPECIFY_VERSION:-1.2.6}"
if [[ ! "$specify_version" =~ ^[0-9][0-9A-Za-z.+-]*$ ]]; then
  printf '%s\n' 'FOUNDRY_SPECIFY_VERSION 必须是明确版本号' >&2
  exit 2
fi

hook_ids=(artifact-issue-description artifact-pr-description mvu-gate artifact-business-flow artifact-logic-flow explainer-doc-sync artifact-project-description)
# 所有来源完整后才允许第一项安装，避免缺源导致部分写入。
for hook_id in "${hook_ids[@]}"; do
  for required in "$skills_dir/$hook_id/SKILL.md" "$skills_dir/$hook_id/speckit-hooks.json"; do
    if [[ ! -f "$required" ]]; then
      printf '缺少输入：%s\n' "$required" >&2
      exit 1
    fi
  done
done
temporary="$(mktemp -d "${TMPDIR:-/tmp}/foundry-hooks-XXXXXXXX")"
trap 'rm -rf -- "$temporary"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [[ -n "$cli_path" ]]; then
  cli=("$cli_path")
else
  cli=(uvx --from "specify-cli==$specify_version" specify)
fi
for hook_id in "${hook_ids[@]}"; do
  input="$temporary/$hook_id"
  mkdir -p "$input/skills"
  cp -RL "$skills_dir/$hook_id" "$input/skills/$hook_id"
  # 固定身份与受校验的版本号之外，hooks 原样取自来源定义。
  {
    printf '{"schema_version":"1.0","extension":{"id":"%s","name":"%s","version":"1.0.0","description":"Foundry workflow hook"},"requires":{"speckit_version":"==%s"},"provides":{},"hooks":' "$hook_id" "$hook_id" "$specify_version"
    cat "$skills_dir/$hook_id/speckit-hooks.json"
    printf '}\n'
  } > "$input/extension.yml"
  if (cd -- "$project_dir" && "${cli[@]}" extension add --dev "$input" --force); then
    printf '已重装 hook：%s\n' "$hook_id"
  else
    cli_status=$?
    printf '官方挂载失败：%s，退出码 %s\n' "$hook_id" "$cli_status" >&2
    exit "$cli_status"
  fi
done

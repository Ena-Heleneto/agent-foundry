#!/usr/bin/env bash
# 在 Bash 中准备全部四指令输入，由官方 CLI 完成登记与重装。
set -euo pipefail

project_dir=''
skills_dir=''
cli_path=''
while [[ $# -gt 0 ]]; do
  case "$1" in
    --help|-h)
      printf '%s\n' '用法：register-commands.sh --project <项目> --skills-dir <技能根> [--cli <specify>]'
      exit 0 ;;
    --project|--skills-dir|--cli)
      if [[ $# -lt 2 || -z "$2" || "$2" == --* ]]; then
        printf '参数缺值：%s\n' "$1" >&2
        exit 2
      fi
      case "$1" in
        --project) project_dir="$2" ;;
        --skills-dir) skills_dir="$2" ;;
        --cli) cli_path="$2" ;;
      esac
      shift 2 ;;
    --project=*) project_dir="${1#*=}"; shift ;;
    --skills-dir=*) skills_dir="${1#*=}"; shift ;;
    --cli=*) cli_path="${1#*=}"; shift ;;
    *) printf '未知参数：%s\n' "$1" >&2; exit 2 ;;
  esac
done

if [[ -z "$project_dir" || -z "$skills_dir" ]]; then
  printf '%s\n' '必须提供 --project 和 --skills-dir' >&2
  exit 2
fi
project_dir="$(cd -- "$project_dir" && pwd -P)"
skills_dir="$(cd -- "$skills_dir" && pwd -P)"
if [[ ! -f "$project_dir/.specify/init-options.json" ]]; then
  printf '%s\n' '目标项目尚未初始化 Spec Kit' >&2
  exit 1
fi
specify_version="${FOUNDRY_SPECIFY_VERSION:-1.2.6}"
if [[ ! "$specify_version" =~ ^[0-9][0-9A-Za-z.+-]*$ ]]; then
  printf '%s\n' 'FOUNDRY_SPECIFY_VERSION 必须是明确版本号' >&2
  exit 2
fi

modes=(tutor pair direct increment)
for mode in "${modes[@]}"; do
  if [[ ! -f "$skills_dir/task-$mode/SKILL.md" ]]; then
    printf '缺少技能：%s\n' "$skills_dir/task-$mode/SKILL.md" >&2
    exit 1
  fi
done

temporary="$(mktemp -d "${TMPDIR:-/tmp}/foundry-modes-XXXXXXXX")"
trap 'rm -rf -- "$temporary"' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir -p "$temporary/skills"
for mode in "${modes[@]}"; do
  cp -RL "$skills_dir/task-$mode" "$temporary/skills/task-$mode"
done

# 动态值仅有经过版本字符校验的版本号，其余声明全部来自固定四项。
{
  cat <<EOF
{
  "schema_version": "1.0",
  "extension": {"id": "modes", "name": "Collaboration Modes", "version": "1.0.0", "description": "导师、结对、用户主导和增量规划四个协作指令"},
  "requires": {"speckit_version": "==$specify_version"},
  "provides": {"commands": [
EOF
  separator=''
  for mode in "${modes[@]}"; do
    printf '%s{"name":"speckit.modes.%s","file":"skills/task-%s/SKILL.md","description":"进入 %s 协作模式"}' "$separator" "$mode" "$mode" "$mode"
    separator=','
  done
  printf '\n  ]}\n}\n'
} > "$temporary/extension.yml"

if [[ -n "$cli_path" ]]; then
  cli=("$cli_path")
else
  cli=(uvx --from "specify-cli==$specify_version" specify)
fi
if (cd -- "$project_dir" && "${cli[@]}" extension add --dev "$temporary" --force); then
  printf '%s\n' '四个协作指令安装完成：$speckit-modes-tutor、$speckit-modes-pair、$speckit-modes-direct、$speckit-modes-increment'
else
  cli_status=$?
  printf '官方挂载失败：退出码 %s\n' "$cli_status" >&2
  exit "$cli_status"
fi

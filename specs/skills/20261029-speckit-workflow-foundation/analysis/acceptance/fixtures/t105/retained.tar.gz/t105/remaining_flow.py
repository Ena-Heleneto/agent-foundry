"""顺序运行T105依赖回合，任一运行或业务保护失败即停，不自动重跑。"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

root = Path(__file__).resolve().parent
project = Path('/tmp/foundry-tv10-20261110/cases/positive-a')
business = hashlib.sha256((project / 'order.py').read_bytes()).hexdigest()
tests = hashlib.sha256((project / 'test_order.py').read_bytes()).hexdigest()
for stage in ('save-failure', 'save-recovery', 'substantive', 'withdraw-resume'):
    result = subprocess.run([sys.executable, str(root / 'host_cases.py'), stage])
    if result.returncode:
        raise SystemExit(result.returncode)
    assert hashlib.sha256((project / 'order.py').read_bytes()).hexdigest() == business
    assert hashlib.sha256((project / 'test_order.py').read_bytes()).hexdigest() == tests
    markers = dict((identity, marker.lower()) for marker, identity in re.findall(
        r'^- \[([ xX])\] (T\d{3})\b', (project / 'specs/demo/001-order/tasks.md').read_text(), re.M))
    assert markers == {'T001': 'x', 'T002': ' '}, markers
    print('PROTECTED: '+stage, flush=True)

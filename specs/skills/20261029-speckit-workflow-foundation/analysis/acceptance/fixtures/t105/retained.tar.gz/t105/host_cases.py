"""T105隔离宿主回归；只操作原测试项目，保留每个真实回合及前后摘要。"""

from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parent
PROJECT = Path('/tmp/foundry-tv10-20261110/cases/positive-a')
SPEC = PROJECT / 'specs/demo/001-order'
PROPOSAL = SPEC / 'implementation/T002.md'

PROMPTS = {
    'normal-adjustment': '$speckit-implement specs/demo/001-order T001 T002。继续现有任务。T001的业务逻辑和验收不变，本次仅把其方案中的测试执行安排调整为 python3 -B -m unittest discover -s . -p test_order.py -v，以显式选择现有测试；记录该普通工程调整的理由后继续。',
    'save-failure': '$speckit-implement specs/demo/001-order T001 T002。继续现有任务。这轮先将T002待讨论方案的执行顺序补充为：先核对整数分小计与运费输入，再计算总额；保存并读回后继续。测试夹具当前目录权限由外部验证控制，不要自行修改权限。',
    'save-recovery': '$speckit-implement specs/demo/001-order T001 T002。上轮方案路径的写入障碍已由验证端解除，继续原讨论和任务。',
    'substantive': '$speckit-implement specs/demo/001-order T001 T002。现在有一项尚待讨论的测试提案：将T001的单价和小计改为浮点元，并相应改变T002输入。请结合当前原任务和认可方案处理后继续。',
    'withdraw-resume': '$speckit-implement specs/demo/001-order T001 T002。撤回上一轮浮点元测试提案，沿最终保留的整数分逻辑和实际认可来源继续原任务。',
}


def snapshot():
    """记录项目文件摘要，不收集Git对象、认证或账户目录。"""
    result = {}
    for path in sorted(PROJECT.rglob('*')):
        if {'.git', '__pycache__'} & set(path.relative_to(PROJECT).parts):
            continue
        if path.is_file():
            try:
                result[str(path.relative_to(PROJECT))] = hashlib.sha256(path.read_bytes()).hexdigest()
            except PermissionError:
                result[str(path.relative_to(PROJECT))] = 'unreadable'
    return result


def session_from(stage):
    """只从本轮已保留的宿主输出取得真实会话ID。"""
    result = json.loads((ROOT / 'host' / stage / 'result.json').read_text())
    assert result['exit'] == 0 and not result['timeout'], result
    return result['session_id']


stage = sys.argv[1]
assert stage in PROMPTS
out = ROOT / 'host' / stage
if out.exists():
    out = ROOT / 'host' / (stage + '-attempt-' + str(time.time_ns()))
out.mkdir(parents=True)

if stage == 'save-failure':
    modes = {'file': PROPOSAL.stat().st_mode & 0o777, 'parent': PROPOSAL.parent.stat().st_mode & 0o777}
    (ROOT / 'permission-baseline.json').write_text(json.dumps(modes) + '\n')
    PROPOSAL.chmod(0o444)
    PROPOSAL.parent.chmod(0o555)
elif stage == 'save-recovery':
    modes = json.loads((ROOT / 'permission-baseline.json').read_text())
    PROPOSAL.parent.chmod(modes['parent'])
    PROPOSAL.chmod(modes['file'])

before = snapshot()
(out / 'before.json').write_text(json.dumps(before, ensure_ascii=False, indent=2) + '\n')
(out / 'input.txt').write_text(PROMPTS[stage] + '\n')
args = ['codex', 'exec', '--cd', str(PROJECT), '--sandbox', 'workspace-write']
if stage in ('save-recovery', 'withdraw-resume'):
    previous = 'save-failure' if stage == 'save-recovery' else 'substantive'
    args += ['resume', '--json', '--output-last-message', str(out / 'final.txt'), session_from(previous), '-']
else:
    args += ['--json', '--color', 'never', '--output-last-message', str(out / 'final.txt'), '-']
begin = time.monotonic()
with (out / 'events.jsonl').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    process = subprocess.Popen(args, cwd=PROJECT, stdin=subprocess.PIPE, stdout=stdout,
                               stderr=stderr, text=True, start_new_session=True)
    timed_out = False
    try:
        process.communicate(PROMPTS[stage] + '\n', timeout=240)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()

session_id = None
for line in (out / 'events.jsonl').read_text().splitlines():
    try:
        event = json.loads(line)
        if event.get('type') == 'thread.started':
            session_id = event.get('thread_id')
    except json.JSONDecodeError:
        pass
after = snapshot()
result = {'stage': stage, 'exit': process.returncode, 'timeout': timed_out,
          'elapsed_seconds': round(time.monotonic() - begin, 3), 'session_id': session_id,
          'args': args, 'raw_directory': str(out), 'sandbox': 'workspace-write', 'model_override': False,
          'changed': [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]}
(out / 'after.json').write_text(json.dumps(after, ensure_ascii=False, indent=2) + '\n')
(out / 'result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
if (out / 'final.txt').exists():
    print((out / 'final.txt').read_text()[:2200])
if process.returncode:
    print((out / 'stderr.log').read_text()[-1500:])
raise SystemExit(1 if process.returncode or timed_out else 0)

# 示例任务

- [X] T001 在order.py实现calculate_subtotal(unit_price_cents, quantity)，输入为非负整数，返回整数分小计；非整数、布尔或负数抛ValueError。只实现本Task，按test_order.py验收。 已认可方案见[implementation/T001.md](implementation/T001.md)。
- [ ] T002 在order.py实现calculate_total(subtotal_cents, shipping_cents)，返回加运费后的整数分总额；依赖T001的小计结果，后续按自己的方案及验收推进。 待讨论方案见[implementation/T002.md](implementation/T002.md)，尚未获用户认可。

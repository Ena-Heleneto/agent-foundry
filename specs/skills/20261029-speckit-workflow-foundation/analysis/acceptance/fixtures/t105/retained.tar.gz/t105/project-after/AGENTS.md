# 示例工程约定

使用Python标准库；命令为python3 -B -m unittest -v。保留原任务身份与其他Task的目标。

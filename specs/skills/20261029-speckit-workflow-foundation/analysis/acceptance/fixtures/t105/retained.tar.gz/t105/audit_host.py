"""独立核对宿主原始工具输出和项目摘要，不以最终自述代替行为证据。"""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
project = Path('/tmp/foundry-tv10-20261110/cases/positive-a')
source = Path('<source-workspace>/packages/skills/src/skills/workflow/implementation-preparation')
files = {
    'skill': project / '.agents/skills/implementation-preparation/SKILL.md',
    'constitution': project / '.specify/memory/constitution.md',
    'approval': project / 'specs/demo/001-order/requirements/raw/T001-approval.json',
}
results = []
for directory in sorted((root / 'host').iterdir()):
    result_path = directory / 'result.json'
    if not result_path.is_file():
        continue
    result = json.loads(result_path.read_text())
    events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
    outputs = [(index, event.get('item', {}).get('aggregated_output', ''))
               for index, event in enumerate(events) if event.get('type') == 'item.completed']
    full_reads = {key: [index for index, output in outputs if path.read_text().strip() in output]
                  for key, path in files.items()}
    failed_commands = []
    for index, event in enumerate(events):
        item = event.get('item', {})
        if event.get('type') == 'item.completed' and item.get('type') == 'command_execution' and item.get('exit_code'):
            failed_commands.append({'event': index, 'command': item.get('command'),
                                    'exit': item.get('exit_code'), 'output': item.get('aggregated_output', '')[-1800:]})
    before = json.loads((directory / 'before.json').read_text())
    after = json.loads((directory / 'after.json').read_text())
    protected = all(before.get(name) == after.get(name) for name in ('order.py', 'test_order.py'))
    result.update({'turn_completed': any(event.get('type') == 'turn.completed' for event in events),
                   'full_text_reads': full_reads, 'business_and_tests_unchanged': protected,
                   'failed_commands': failed_commands, 'events_count': len(events)})
    results.append(result)

markers = dict((identity, marker.lower()) for marker, identity in re.findall(
    r'^- \[([ xX])\] (T\d{3})\b', (project / 'specs/demo/001-order/tasks.md').read_text(), re.M))
report = {'scope': 'T105正式维护源官方安装下的宿主行为；不计构建通过或全项目验收',
          'results': results, 'final_markers': markers,
          'approval_unchanged': files['approval'].read_bytes() == (root / 'project-before/specs/demo/001-order/requirements/raw/T001-approval.json').read_bytes(),
          'final_business_unchanged': (project / 'order.py').read_bytes() == (root / 'project-before/order.py').read_bytes(),
          'final_tests_unchanged': (project / 'test_order.py').read_bytes() == (root / 'project-before/test_order.py').read_bytes()}
(root / 'host-audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
for entry in results:
    print(json.dumps({key: entry[key] for key in ('stage', 'exit', 'timeout', 'turn_completed', 'elapsed_seconds', 'full_text_reads', 'business_and_tests_unchanged', 'changed')}, ensure_ascii=False))
print('FINAL', json.dumps({key: value for key, value in report.items() if key not in ('scope', 'results')}, ensure_ascii=False))

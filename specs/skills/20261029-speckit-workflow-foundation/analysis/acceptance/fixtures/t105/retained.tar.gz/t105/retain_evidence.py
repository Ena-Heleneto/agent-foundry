"""保留本轮输入、真实宿主日志及必要文件，不包含账户或Git对象。"""
from pathlib import Path
import hashlib
import json
import re
import shutil
import tarfile

scratch = Path(__file__).resolve().parent
repo = Path('<source-workspace>')
spec = repo / 'specs/skills/20261029-speckit-workflow-foundation'
project = Path('/tmp/foundry-tv10-20261110/cases/positive-a')
destination = spec / 'analysis/acceptance/fixtures/t105'
destination.mkdir(parents=True, exist_ok=True)
assert not (destination / 'retained.tar.gz').exists()

shutil.copytree(project, scratch / 'project-after', ignore=shutil.ignore_patterns('.git', '__pycache__'))
for name in ('.specify/templates/overrides/tasks-template.md', 'packages/skills/tests/test_mvu_documents.py'):
    target = scratch / 'delivered' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(repo / name, target)
review = {'scope': 'T105模板/原生准备测试/方案，只读独立审查；不替代宿主验收',
          'reviewer': 'review_t105', 'critical': [], 'important': [], 'minor': [],
          'checks_rerun_by_reviewer': False}
(scratch / 'review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2) + '\n')

names = ['host', 'source-proof.json', 'host-audit.json', 'final-checks.json', 'state.json',
         'permission-baseline.json', 'template-red.log', 'template-green.log',
         'package-lint.log', 'package-types.log', 'package-test.log', 'independent-unittest.log',
         'host_cases.py', 'remaining_flow.py', 'audit_host.py', 'retain_evidence.py', 'review.json',
         'project-before', 'project-after', 'delivered', 'before',
         'spec.md.diff', 'implementation-T001.md.diff', 'implementation-T002.md.diff']
patterns = [rb'sk-[A-Za-z0-9_-]{24,}', rb'gh[pousr]_[A-Za-z0-9]{30,}', rb'-----BEGIN [A-Z ]*PRIVATE KEY-----']
scanned = 0
for name in names:
    path = scratch / name
    files = list(path.rglob('*')) if path.is_dir() else [path]
    for item in files:
        if item.is_file():
            data = item.read_bytes()
            assert not any(re.search(pattern, data) for pattern in patterns), 'credential-pattern: ' + str(item)
            scanned += 1
archive = destination / 'retained.tar.gz'
with tarfile.open(archive, 'w:gz') as package:
    for name in names:
        package.add(scratch / name, arcname='t105/' + name)
with tarfile.open(archive) as package:
    members = package.getmembers()
    assert all(not Path(member.name).is_absolute() and '..' not in Path(member.name).parts for member in members)

report = json.loads((scratch / 'host-audit.json').read_text())
report.update({'archive': {'file': 'retained.tar.gz', 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                           'bytes': archive.stat().st_size, 'members': len(members),
                           'selected_credential_patterns': 3, 'files_scanned': scanned, 'matches': 0,
                           'scan_complete': False},
               'source_proof': json.loads((scratch / 'source-proof.json').read_text()),
               'checks': json.loads((scratch / 'final-checks.json').read_text()),
               'package_checks': {'lint': {'command': 'pnpm --filter @foundry/skills run lint', 'exit': 0},
                                  'types': {'command': 'pnpm --filter @foundry/skills run check-types', 'exit': 0},
                                  'test': {'command': 'pnpm --filter @foundry/skills run test', 'exit': 0, 'tests': 12}},
               'limits': ['构建及构建来源回归暂跳过，不计通过', '本机Linux宿主，未验证其他平台',
                          '正常恢复未重做A，不冒称新业务实施样本', '测试输入由验证端提供，不冒称真实用户新增认可；只有原A回执提供真实业务认可',
                          '宿主仍可能加载全局辅助技能，不宣称准备skill的唯一因果来源或程序锁',
                          'T107真实项目反馈及真实工作区挂载不在本项验收范围']})
(destination / 'results.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report['archive'], ensure_ascii=False, indent=2))
